package com.example.avtozapchasti

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.appcompat.app.AlertDialog
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import android.media.MediaPlayer

class MainActivity : AppCompatActivity() {
    companion object {
        const val ACTION_CALL_ASSISTANT = "com.example.avtozapchasti.ACTION_CALL_ASSISTANT"
    }
    private val prefs by lazy { getSharedPreferences("orders", MODE_PRIVATE) }
    private val kb by lazy { KnowledgeBase(this) }
    private val api by lazy { OpenAiGateway(this) }
    private val offlineModels by lazy { OfflineModelManager(this) }
    private val offlineTranscriber by lazy { OfflineTranscriber(offlineModels) }
    private val offlineParser by lazy { OfflineOrderParser(this, kb) }
    private val rows = mutableListOf<OrderRow>()
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var container: LinearLayout
    private lateinit var status: TextView
    private val recorder by lazy { VoiceRecorder(this) }
    private var activeVoiceFile: File? = null
    private var voiceDialog: AlertDialog? = null
    private var pendingAutoStartConversation = false

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val crashFile = File(filesDir, "last_crash.txt")
                crashFile.writeText(
                    "Thread: ${thread.name}\\n" +
                    throwable.stackTraceToString(),
                    Charsets.UTF_8
                )
            } catch (_: Exception) {
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger()
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.tablesContainer)
        val crashFile = File(filesDir, "last_crash.txt")
        if (crashFile.exists()) {
            val crashText = try { crashFile.readText(Charsets.UTF_8).take(3500) } catch (_: Exception) { "" }
            crashFile.delete()
            main.postDelayed({
                AlertDialog.Builder(this)
                    .setTitle("Предыдущий сбой приложения")
                    .setMessage(crashText.ifBlank { "Подробности сбоя недоступны." })
                    .setPositiveButton("Закрыть", null)
                    .show()
            }, 500)
        }
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.voiceButton).setOnClickListener { startVoiceFlow() }
        findViewById<Button>(R.id.conversationButton).setOnClickListener { showConversationRecorder() }
        findViewById<Button>(R.id.noteButton).setOnClickListener { showVoiceNoteRecorder() }
        findViewById<Button>(R.id.historyButton).setOnClickListener { showConversationHistory() }
        findViewById<Button>(R.id.manualButton).setOnClickListener { showEditor(null) }
        findViewById<Button>(R.id.newButton).setOnClickListener { newOrder() }
        findViewById<Button>(R.id.baseButton).setOnClickListener { showBase() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.exportButton).setOnClickListener { exportCsv() }
        findViewById<Button>(R.id.pdfButton).setOnClickListener { printPdf() }
        load(); render()
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: android.content.Intent?) {
        if (intent?.action == ACTION_CALL_ASSISTANT) {
            intent.action = null
            main.postDelayed({
                showConversationRecorder(autoStartRecording = true)
            }, 250)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 || requestCode == 1002) {
            val granted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (granted) {
                if (requestCode == 1001 && pendingAutoStartConversation) {
                    pendingAutoStartConversation = false
                    main.postDelayed({ showConversationRecorder(autoStartRecording = true) }, 150)
                } else if (requestCode == 1001) {
                    startVoiceFlow()
                } else {
                    showVoiceNoteRecorder()
                }
            } else {
                Toast.makeText(this, "Доступ к микрофону не разрешён", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() { recorder.stop(); offlineModels.shutdown(); executor.shutdownNow(); super.onDestroy() }

    private fun newOrder() { rows.clear(); save(); render(); Toast.makeText(this, "Новая заявка", Toast.LENGTH_SHORT).show() }

    private fun startVoiceFlow() {
        if (!hasMic()) {
            pendingAutoStartConversation = false
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val info = TextView(this).apply { text = "Говорите заявку обычным голосом.\nАудио → локальная офлайн-расшифровка → локальный разбор заявки → таблица."; setPadding(0,0,0,10) }
        val start = Button(this).apply { text = "🎙 Начать" }
        val stop = Button(this).apply { text = "■ Остановить"; isEnabled = false }
        val transcript = EditText(this).apply { hint = "Здесь появится расшифровка"; minLines = 6; gravity = Gravity.TOP }
        box.addView(info); box.addView(start); box.addView(stop); box.addView(transcript)
        val dialog = AlertDialog.Builder(this).setTitle("Голосовая заявка").setView(box)
            .setPositiveButton("Добавить в заявку", null).setNegativeButton("Закрыть", null).create()
        dialog.setOnShowListener { shown ->
            val alert = shown as AlertDialog
            alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val t = transcript.text.toString().trim()
                if (t.isBlank()) { Toast.makeText(this, "Нет текста для разбора", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                status.text = "Офлайн формирует позиции…"
                parseTranscript(t) { alert.dismiss() }
            }
        }
        start.setOnClickListener {
            try {
                activeVoiceFile = recorder.start(); start.isEnabled = false; stop.isEnabled = true
                status.text = "Идёт запись…"
            } catch (e: Exception) { status.text = "Ошибка записи: ${e.message}" }
        }
        stop.setOnClickListener {
            val f = recorder.stop(); activeVoiceFile = null; start.isEnabled = true; stop.isEnabled = false
            if (f != null) {
                saveVoiceNoteRecord(f)
                transcribeFile(f, transcript, f.absolutePath)
            } else status.text = "Запись отсутствует"
        }
        voiceDialog = dialog
        dialog.show()
    }

    private fun transcribeFile(file: File, target: EditText, voiceNotePath: String? = null) {
        status.text = "Офлайн-расшифровка…"
        executor.execute {
            try {
                val text = offlineTranscriber.transcribe(file)
                if (!voiceNotePath.isNullOrBlank()) updateVoiceNoteText(voiceNotePath, text)
                main.post {
                    target.setText(text)
                    target.setSelection(target.text.length)
                    status.text = "Расшифровка готова без интернета. Голосовая заметка сохранена"
                }
            } catch (e: Exception) {
                if (!voiceNotePath.isNullOrBlank()) updateVoiceNoteText(voiceNotePath, "[Офлайн-расшифровка не выполнена: ${e.message ?: "ошибка"}]")
                main.post {
                    status.text = "Ошибка офлайн-расшифровки: ${e.message}"
                    if (!offlineModels.isInstalled()) {
                        showOfflineModelDialog()
                    }
                }
            }
        }
    }

    private fun showConversationRecorder(autoStartRecording: Boolean = false) {
        if (!hasMic()) {
            pendingAutoStartConversation = autoStartRecording
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 10, 24, 0)
        }
        val info = TextView(this).apply {
            text = "Запишите весь разговор с клиентом. После остановки аудио сохраняется на телефоне и расшифровывается локально, без интернета."
            setPadding(0, 0, 0, 10)
        }
        val start = Button(this).apply { text = "🎙 Начать разговор" }
        val stop = Button(this).apply { text = "■ Остановить"; isEnabled = false }
        val transcript = EditText(this).apply {
            hint = "Здесь появится полная расшифровка разговора"
            minLines = 10
            gravity = Gravity.TOP
        }
        val saveHistory = CheckBox(this).apply {
            text = "Сохранить расшифровку в историю"
            isChecked = true
        }
        box.addView(info)
        box.addView(start)
        box.addView(stop)
        box.addView(transcript)
        box.addView(saveHistory)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Запись разговора с клиентом")
            .setView(box)
            .setPositiveButton("Сформировать заявку", null)
            .setNeutralButton("Только сохранить", null)
            .setNegativeButton("Закрыть", null)
            .create()

        dialog.setOnShowListener { shown ->
            val alert = shown as AlertDialog
            alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val t = transcript.text.toString().trim()
                if (t.isBlank()) {
                    Toast.makeText(this, "Сначала запишите или вставьте расшифровку", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (saveHistory.isChecked) saveConversation(t)
                status.text = "Офлайн формирует заявку из разговора…"
                parseTranscript(t) { alert.dismiss() }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val t = transcript.text.toString().trim()
                if (t.isBlank()) {
                    Toast.makeText(this, "Нет текста для сохранения", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                saveConversation(t)
                status.text = "Расшифровка разговора сохранена"
                alert.dismiss()
            }
        }

        start.setOnClickListener {
            try {
                activeVoiceFile = recorder.start()
                start.isEnabled = false
                stop.isEnabled = true
                status.text = "Идёт запись разговора…"
            } catch (e: Exception) {
                status.text = "Ошибка записи: ${e.message}"
            }
        }
        stop.setOnClickListener {
            val f = recorder.stop()
            activeVoiceFile = null
            start.isEnabled = true
            stop.isEnabled = false
            if (f != null) {
                saveVoiceNoteRecord(f)
                transcribeFile(f, transcript, f.absolutePath)
            } else {
                status.text = "Запись отсутствует"
            }
        }
        dialog.show()
        if (autoStartRecording) {
            main.postDelayed({
                if (hasMic()) {
                    start.performClick()
                } else {
                    Toast.makeText(this, "Разрешите доступ к микрофону, чтобы начать запись.", Toast.LENGTH_LONG).show()
                }
            }, 350)
        }
    }

    private fun saveConversation(text: String, audioPath: String? = null) {
        val prefsHistory = getSharedPreferences("conversation_history", MODE_PRIVATE)
        val current = JSONArray(prefsHistory.getString("items", "[]"))
        val item = JSONObject().apply {
            put("time", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()))
            put("text", text)
            if (!audioPath.isNullOrBlank()) put("audioPath", audioPath)
        }
        current.put(item)
        val trimmed = JSONArray()
        val start = maxOf(0, current.length() - 50)
        for (i in start until current.length()) trimmed.put(current.getJSONObject(i))
        prefsHistory.edit().putString("items", trimmed.toString()).apply()
    }

    private fun saveVoiceNoteRecord(file: File) {
        val prefs = getSharedPreferences("voice_notes", MODE_PRIVATE)
        val current = JSONArray(prefs.getString("items", "[]"))
        val item = JSONObject().apply {
            put("time", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()))
            put("audioPath", file.absolutePath)
            put("text", "")
        }
        current.put(item)
        val trimmed = JSONArray()
        val start = maxOf(0, current.length() - 100)
        for (i in start until current.length()) trimmed.put(current.getJSONObject(i))
        prefs.edit().putString("items", trimmed.toString()).apply()
        Toast.makeText(this, "Голосовая заметка сохранена", Toast.LENGTH_SHORT).show()
    }

    private fun updateVoiceNoteText(audioPath: String, text: String) {
        val prefs = getSharedPreferences("voice_notes", MODE_PRIVATE)
        val current = JSONArray(prefs.getString("items", "[]"))
        for (i in 0 until current.length()) {
            val o = current.optJSONObject(i) ?: continue
            if (o.optString("audioPath") == audioPath) {
                o.put("text", text)
                break
            }
        }
        prefs.edit().putString("items", current.toString()).apply()
    }

    private fun showVoiceNoteRecorder() {
        if (!hasMic()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1002)
            return
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val info = TextView(this).apply { text = "Голосовая заметка сохраняется на телефоне сразу после остановки записи. Затем она расшифровывается локально, без интернета."; setPadding(0,0,0,10) }
        val start = Button(this).apply { text = "🎙 Начать заметку" }
        val stop = Button(this).apply { text = "■ Остановить"; isEnabled = false }
        val transcript = EditText(this).apply { hint = "Расшифровка заметки"; minLines = 5; gravity = Gravity.TOP }
        box.addView(info); box.addView(start); box.addView(stop); box.addView(transcript)
        val dialog = AlertDialog.Builder(this).setTitle("Голосовая заметка").setView(box)
            .setPositiveButton("Закрыть", null).create()
        dialog.setOnShowListener {
            start.setOnClickListener {
                try {
                    activeVoiceFile = recorder.start()
                    start.isEnabled = false; stop.isEnabled = true
                    status.text = "Идёт запись заметки…"
                } catch (e: Exception) {
                    status.text = e.message ?: "Ошибка записи"
                    Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
                }
            }
            stop.setOnClickListener {
                val f = recorder.stop()
                activeVoiceFile = null
                start.isEnabled = true; stop.isEnabled = false
                if (f != null) {
                    saveVoiceNoteRecord(f)
                    transcribeFile(f, transcript, f.absolutePath)
                } else {
                    status.text = "Запись не получена. Проверьте разрешение микрофона и не используйте одновременно другое приложение записи."
                }
            }
        }
        dialog.show()
    }

    private fun showConversationHistory() {
        val prefsHistory = getSharedPreferences("conversation_history", MODE_PRIVATE)
        val arr = JSONArray(prefsHistory.getString("items", "[]"))
        val notesPrefs = getSharedPreferences("voice_notes", MODE_PRIVATE)
        val notes = JSONArray(notesPrefs.getString("items", "[]"))

        if (arr.length() == 0 && notes.length() == 0) {
            AlertDialog.Builder(this).setTitle("Разговоры и заметки").setMessage("Сохранённых разговоров и голосовых заметок пока нет.").setPositiveButton("Закрыть", null).show()
            return
        }

        val allTitles = mutableListOf<String>()
        val kinds = mutableListOf<Int>()
        for (i in 0 until arr.length()) {
            allTitles.add("Разговор • ${arr.getJSONObject(i).optString("time")}")
            kinds.add(i)
        }
        val noteMarker = -1000000
        for (i in 0 until notes.length()) {
            allTitles.add("Голосовая заметка • ${notes.getJSONObject(i).optString("time")}")
            kinds.add(noteMarker - i)
        }

        AlertDialog.Builder(this)
            .setTitle("Разговоры и заметки")
            .setItems(allTitles.toTypedArray()) { _, which ->
                val kind = kinds[which]
                if (kind >= 0) {
                    val o = arr.getJSONObject(kind)
                    val text = o.optString("text")
                    val audioPath = o.optString("audioPath")
                    val b = AlertDialog.Builder(this).setTitle(o.optString("time")).setMessage(text.ifBlank { "Расшифровка отсутствует." })
                        .setNeutralButton("В заявку") { _, _ ->
                            if (text.isNotBlank()) {
                                status.text = "Офлайн формирует заявку из сохранённой расшифровки…"
                                parseTranscript(text)
                            }
                        }.setPositiveButton("Закрыть", null)
                    if (audioPath.isNotBlank() && File(audioPath).exists()) {
                        b.setNegativeButton("▶ Воспроизвести") { _, _ -> playAudio(audioPath) }
                    }
                    b.show()
                } else {
                    val idx = -kind - 1000000
                    val o = notes.getJSONObject(idx)
                    val path = o.optString("audioPath")
                    val text = o.optString("text")
                    val b = AlertDialog.Builder(this).setTitle(o.optString("time"))
                        .setMessage(text.ifBlank { "Заметка сохранена без расшифровки." })
                        .setPositiveButton("Закрыть", null)
                    if (path.isNotBlank() && File(path).exists()) b.setNegativeButton("▶ Воспроизвести") { _, _ -> playAudio(path) }
                    b.show()
                }
            }
            .setNeutralButton("Очистить историю") { _, _ ->
                prefsHistory.edit().remove("items").apply()
                notesPrefs.edit().remove("items").apply()
                status.text = "История разговоров и заметок очищена"
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun playAudio(path: String) {
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(this, "Аудиофайл не найден", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val player = MediaPlayer()
            player.setDataSource(file.absolutePath)
            player.setOnCompletionListener { it.release() }
            player.setOnErrorListener { mp, _, _ -> mp.release(); true }
            player.prepare()
            player.start()
            Toast.makeText(this, "Воспроизведение заметки…", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось воспроизвести: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun parseTranscript(text: String, after: () -> Unit = {}) {
        executor.execute {
            try {
                val parsed = offlineParser.parse(text)
                main.post {
                    rows.addAll(parsed.rows)
                    normalizeAndSave()
                    render()
                    val q = parsed.questions
                    status.text = if (q.isEmpty()) "Заявка сформирована офлайн" else "Нужно уточнить: ${q.size} поз."
                    if (q.isNotEmpty()) {
                        AlertDialog.Builder(this)
                            .setTitle("Нужно уточнить")
                            .setMessage(q.joinToString("

"))
                            .setPositiveButton("Понятно", null)
                            .show()
                    }
                    after()
                }
            } catch (e: Exception) {
                main.post {
                    status.text = "Ошибка офлайн-разбора: ${e.message}"
                    Toast.makeText(this, "Не удалось обработать заявку", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showEditor(index: Int?) {
        val old = index?.let { rows[it] }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,0,20,0) }
        val names = listOf("Модель", "Деталь", "Производитель", "Цвет", "Количество")
        val fields = names.map { EditText(this).apply { hint = it } }
        old?.let { r -> fields[0].setText(r.model); fields[1].setText(r.detail); fields[2].setText(r.manufacturer); fields[3].setText(r.color); fields[4].setText(r.quantity.toString()) }
        fields.forEach { layout.addView(it) }
        val saveBase = CheckBox(this).apply { text = "Сохранить эту расшифровку в базу"; isChecked = old?.unknown == true }
        if (old?.sourcePhrase?.isBlank() != false) saveBase.isEnabled = false
        layout.addView(saveBase)
        AlertDialog.Builder(this).setTitle(if (old == null) "Новая позиция" else "Исправление позиции")
            .setView(layout).setPositiveButton("Сохранить") { _, _ ->
                val r = OrderRow(fields[0].text.toString().trim().ifBlank { "?" }, fields[1].text.toString().trim().ifBlank { "?" }, fields[2].text.toString().trim(), fields[3].text.toString().trim(), fields[4].text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1, old?.done ?: false, false, old?.sourcePhrase.orEmpty(), "")
                if (saveBase.isChecked) kb.add(r.sourcePhrase, r, section(r))
                if (index == null) rows.add(r) else rows[index] = r
                normalizeAndSave(); render()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showBase() {
        val entries = kb.entries()
        val text = if (entries.isEmpty()) "База пока пустая." else entries.takeLast(100).joinToString("\n\n") { "${it.phrase}\n→ ${it.model} | ${it.detail} | ${it.manufacturer.ifBlank { "—" }} | ${it.color.ifBlank { "—" }}" }
        AlertDialog.Builder(this).setTitle("База расшифровок (${entries.size})").setMessage(text).setPositiveButton("Закрыть", null)
            .setNeutralButton("Очистить", null).show().apply { getButton(AlertDialog.BUTTON_NEUTRAL)?.setOnClickListener { kb.clear(); dismiss(); showBase() } }
    }

    private fun showSettings() {
        val info = TextView(this).apply {
            text = "Режим полностью офлайн. После установки русской модели интернет не нужен для записи, расшифровки и формирования заявки. Первый раз модель нужно скачать на телефон (около 258 МБ)."
            setPadding(0, 0, 0, 12)
        }
        val modelStatus = TextView(this).apply {
            text = if (offlineModels.isInstalled()) "Статус модели: установлена" else "Статус модели: не установлена"
            setPadding(0, 0, 0, 12)
        }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        val download = Button(this).apply { text = if (offlineModels.isInstalled()) "Переустановить модель" else "Скачать офлайн-модель" }
        val delete = Button(this).apply { text = "Удалить офлайн-модель"; isEnabled = offlineModels.isInstalled() }
        val test = Button(this).apply { text = "Проверить готовность офлайн-режима" }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(info)
            addView(modelStatus)
            addView(progress)
            addView(download)
            addView(delete)
            addView(test)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Настройки — полностью офлайн")
            .setView(box)
            .setPositiveButton("Закрыть", null)
            .create()

        download.setOnClickListener {
            progress.progress = 0
            download.isEnabled = false
            delete.isEnabled = false
            modelStatus.text = "Загрузка модели… 0%"
            offlineModels.downloadAsync(
                onProgress = { p -> main.post { progress.progress = p; modelStatus.text = "Загрузка модели… $p%" } },
                onDone = { result ->
                    main.post {
                        download.isEnabled = true
                        delete.isEnabled = result.isSuccess
                        modelStatus.text = result.fold(
                            { "Статус модели: установлена" },
                            { "Ошибка загрузки: ${it.message ?: "неизвестная ошибка"}" }
                        )
                        progress.progress = if (result.isSuccess) 100 else progress.progress
                    }
                }
            )
        }

        delete.setOnClickListener {
            offlineModels.deleteModel()
            modelStatus.text = "Статус модели: не установлена"
            progress.progress = 0
            delete.isEnabled = false
            download.text = "Скачать офлайн-модель"
            Toast.makeText(this, "Офлайн-модель удалена", Toast.LENGTH_SHORT).show()
        }

        test.setOnClickListener {
            val ready = offlineModels.isInstalled()
            val text = if (ready) {
                "Офлайн-режим готов. Интернет и API-ключ не требуются."
            } else {
                "Офлайн-модель ещё не установлена."
            }
            Toast.makeText(this, text, Toast.LENGTH_LONG).show()
        }

        dialog.show()
    }

    private fun showOfflineModelDialog() {
        AlertDialog.Builder(this)
            .setTitle("Нужна офлайн-модель")
            .setMessage("Для расшифровки без интернета сначала скачайте русскую офлайн-модель в Настройки. Размер около 258 МБ.")
            .setPositiveButton("Настройки") { _, _ -> showSettings() }
            .setNegativeButton("Закрыть", null)
            .show()
    }


    private fun normalizeAndSave() { rows.sortWith(compareBy({ section(it).ordinal }, { it.model }, { it.detail }, { it.color })); save() }
    private fun section(row: OrderRow): Section {
        val c = row.color.trim().lowercase()
        if (c.isBlank() || c == "неокрашенный" || c == "неокрашенная" || c == "без цвета") return Section.UNPAINTED
        if (row.model == "14" && row.detail.equals("Пороги", true)) return Section.PLASTIC
        if (row.manufacturer.contains("ABS", true)) return Section.PLASTIC
        val d = row.detail.lowercase()
        return if (listOf("капот", "крыло переднее", "крышка багажника").any { d.contains(it) }) Section.METAL else Section.PLASTIC
    }

    private fun render() {
        container.removeAllViews()
        for (section in Section.values()) {
            val sectionRows = rows.filter { section(it) == section }
            val qty = sectionRows.sumOf { it.quantity }
            val title = TextView(this).apply { text = "${section.title}   $qty"; textSize = 19f; setTypeface(typeface, Typeface.BOLD); setPadding(4,18,4,8) }
            container.addView(title)
            if (sectionRows.isEmpty()) container.addView(TextView(this).apply { text = "Нет позиций"; setPadding(8,6,8,12) })
            else sectionRows.forEach { container.addView(rowView(it)) }
        }
        val total = rows.sumOf { it.quantity }
        status.text = "Общее количество деталей: $total"
    }

    private fun rowView(row: OrderRow): View {
        val idx = rows.indexOf(row)
        val outer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,8,8,8); setBackgroundColor(if (row.unknown) 0xFFFFF3CD.toInt() else 0xFFFFFFFF.toInt()) }
        val text = TextView(this).apply {
            val prefix = if (row.unknown) "? " else ""
            text = prefix + "${row.model} | ${row.detail} | ${row.manufacturer.ifBlank { "—" }} | ${row.color.ifBlank { "—" }} | ${row.quantity}"
            textSize = 15f; setPadding(4,2,4,2)
            if (row.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        }
        val edit = Button(this).apply { setText("✎"); setOnClickListener { showEditor(idx) } }
        val check = CheckBox(this).apply { isChecked = row.done; setOnCheckedChangeListener { _, b -> row.done = b; save(); render() } }
        outer.addView(check, LinearLayout.LayoutParams(48,-2)); outer.addView(text, LinearLayout.LayoutParams(0,-2,1f)); outer.addView(edit, LinearLayout.LayoutParams(52,-2))
        return outer
    }

    private fun save() { val a=JSONArray(); rows.forEach { a.put(it.toJson()) }; prefs.edit().putString("rows", a.toString()).apply() }
    private fun load() {
        rows.clear()
        val saved = JSONArray(prefs.getString("rows", "[]"))
        if (saved.length() > 0) {
            for (i in 0 until saved.length()) saved.optJSONObject(i)?.let { rows.add(OrderRow.fromJson(it)) }
        } else {
            try {
                assets.open("initial_rows.json").bufferedReader().use { reader ->
                    val a = JSONArray(reader.readText())
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { rows.add(OrderRow.fromJson(it)) }
                }
            } catch (_: Exception) { }
        }
        normalizeAndSave()
    }

    private fun exportCsv() {
        val csv = buildString { append("Модель;Деталь;Производитель;Цвет;Количество\n"); rows.forEach { append("${it.model};${it.detail};${it.manufacturer};${it.color};${it.quantity}\n") } }
        val file = File(getExternalFilesDir(null), "Заявка.csv"); file.writeText(csv, Charsets.UTF_8)
        Toast.makeText(this, "CSV сохранён: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    private fun printPdf() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("Заявка", object : PrintDocumentAdapter() {
            override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes, cancellationSignal: android.os.CancellationSignal?, callback: LayoutResultCallback, extras: Bundle?) { callback.onLayoutFinished(PrintDocumentInfo.Builder("Заявка.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true) }
            override fun onWrite(pages: Array<android.print.PageRange>, destination: android.os.ParcelFileDescriptor, cancellationSignal: android.os.CancellationSignal, callback: WriteResultCallback) {
                val doc=PdfDocument(); val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val c=page.canvas; val p=android.graphics.Paint().apply { textSize=10f }
                var y=30f; c.drawText("Заявка",24f,y,p); y+=22f
                for (s in Section.values()) {
                    val rs = rows.filter { section(it) == s }
                    c.drawText("${s.title} — ${rs.sumOf { it.quantity }}", 24f, y, p)
                    y += 16f
                    for (r in rs) {
                        val manufacturer = r.manufacturer.ifBlank { "—" }
                        val color = r.color.ifBlank { "—" }
                        c.drawText(
                            "${r.model} | ${r.detail} | $manufacturer | $color | ${r.quantity}",
                            24f,
                            y,
                            p
                        )
                        y += 13f
                        if (y > 810f) break
                    }
                    y += 8f
                }
                doc.finishPage(page); FileOutputStream(destination.fileDescriptor).use { doc.writeTo(it) }; doc.close(); callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            }
        }, null)
    }

    private fun requestCallAssistantPermissions() {
        val permissions = mutableListOf(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 2007)
        }
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
}
