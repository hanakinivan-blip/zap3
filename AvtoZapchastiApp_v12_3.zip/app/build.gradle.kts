plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}


import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest

val sherpaAar = layout.projectDirectory.file("libs/sherpa-onnx-1.13.8.aar").asFile
val sherpaAarUrl = "https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.13.8/sherpa-onnx-1.13.8.aar"
val sherpaAarSha256 = "633c24321e06b1fe79feafa03ea16cbc0f8a286641e2da3559bac91bdb13bd96"

val downloadSherpaAar by tasks.registering {
    outputs.file(sherpaAar)
    doLast {
        if (sherpaAar.exists()) {
            val digest = MessageDigest.getInstance("SHA-256")
            sherpaAar.inputStream().use { input ->
                val buffer = ByteArray(64 * 1024)
                var read = input.read(buffer)
                while (read >= 0) {
                    if (read > 0) digest.update(buffer, 0, read)
                    read = input.read(buffer)
                }
            }
            val existingHash = digest.digest().joinToString("") { "%02x".format(it) }
            if (existingHash == sherpaAarSha256) return@doLast
            sherpaAar.delete()
        }

        sherpaAar.parentFile.mkdirs()

        val connection = URI(sherpaAarUrl).toURL().openConnection() as HttpURLConnection
        connection.connectTimeout = 30_000
        connection.readTimeout = 120_000
        connection.instanceFollowRedirects = true
        connection.requestMethod = "GET"
        connection.connect()

        require(connection.responseCode in 200..299) {
            "Не удалось скачать sherpa-onnx AAR: HTTP ${connection.responseCode}"
        }

        connection.inputStream.use { input ->
            sherpaAar.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var read = input.read(buffer)
                while (read >= 0) {
                    if (read > 0) output.write(buffer, 0, read)
                    read = input.read(buffer)
                }
            }
        }
        connection.disconnect()

        val digest = MessageDigest.getInstance("SHA-256")
        sherpaAar.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            var read = input.read(buffer)
            while (read >= 0) {
                if (read > 0) digest.update(buffer, 0, read)
                read = input.read(buffer)
            }
        }
        val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
        require(actualHash == sherpaAarSha256) {
            "Неверная SHA-256 у sherpa-onnx AAR: $actualHash"
        }
    }
}

android {
    namespace = "com.example.avtozapchasti"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.avtozapchasti"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "1.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation(files(sherpaAar))
    implementation("org.apache.commons:commons-compress:1.27.1")
}


tasks.matching {
    it.name == "preBuild" ||
    it.name == "checkDebugAarMetadata" ||
    it.name == "checkReleaseAarMetadata"
}.configureEach {
    dependsOn(downloadSherpaAar)
}
