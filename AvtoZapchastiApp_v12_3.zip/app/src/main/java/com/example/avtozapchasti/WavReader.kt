package com.example.avtozapchasti

import java.io.File
import java.io.RandomAccessFile

data class WavData(val sampleRate: Int, val samples: FloatArray)

object WavReader {
    fun readMonoPcm16(file: File): WavData {
        RandomAccessFile(file, "r").use { raf ->
            val riff = ByteArray(4)
            raf.readFully(riff)
            require(String(riff, Charsets.US_ASCII) == "RIFF") { "Не WAV файл" }
            raf.skipBytes(4)
            raf.readFully(riff)
            require(String(riff, Charsets.US_ASCII) == "WAVE") { "Неверный WAV формат" }

            var sampleRate = 0
            var channels = 1
            var bits = 16
            var dataPos = -1L
            var dataSize = 0

            while (raf.filePointer < raf.length()) {
                if (raf.length() - raf.filePointer < 8) break
                raf.readFully(riff)
                val chunkSize = readLEInt(raf)
                val id = String(riff, Charsets.US_ASCII)
                when (id) {
                    "fmt " -> {
                        val audioFormat = readLEShort(raf)
                        channels = readLEShort(raf).toInt()
                        sampleRate = readLEInt(raf)
                        raf.skipBytes(6)
                        bits = readLEShort(raf).toInt()
                        if (chunkSize > 16) raf.skipBytes(chunkSize - 16)
                        require(audioFormat.toInt() == 1) { "Нужен PCM WAV" }
                        require(bits == 16) { "Поддерживается только PCM 16-bit" }
                    }
                    "data" -> {
                        dataPos = raf.filePointer
                        dataSize = chunkSize
                        raf.seek((dataPos + chunkSize).coerceAtMost(raf.length()))
                    }
                    else -> {
                        raf.seek((raf.filePointer + chunkSize).coerceAtMost(raf.length()))
                    }
                }
                if ((chunkSize and 1) == 1 && raf.filePointer < raf.length()) raf.skipBytes(1)
            }

            require(dataPos >= 0 && sampleRate > 0) { "WAV не содержит аудиоданные" }
            require(channels == 1) { "Поддерживается только моно WAV" }

            val count = dataSize / 2
            val samples = FloatArray(count)
            raf.seek(dataPos)
            for (i in 0 until count) {
                val s = readLEShort(raf).toInt()
                samples[i] = s / 32768.0f
            }
            return WavData(sampleRate, samples)
        }
    }

    private fun readLEInt(raf: RandomAccessFile): Int {
        val a = raf.read(); val b = raf.read(); val c = raf.read(); val d = raf.read()
        return a or (b shl 8) or (c shl 16) or (d shl 24)
    }

    private fun readLEShort(raf: RandomAccessFile): Short {
        val a = raf.read(); val b = raf.read()
        return ((a and 0xff) or ((b and 0xff) shl 8)).toShort()
    }
}
