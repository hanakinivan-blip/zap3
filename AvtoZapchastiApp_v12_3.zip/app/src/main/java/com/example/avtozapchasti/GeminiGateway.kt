package com.example.avtozapchasti

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class GeminiGateway(private val context: android.content.Context) {
    companion object {
        const val MODEL = "gemini-3.1-flash-lite"
        private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"
        private const val MAX_INLINE_AUDIO = 19L * 1024L * 1024L
    }

    private val secretStore = GeminiSecretStore(context)
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .build()

    fun saveApiKey(key: String) = secretStore.save(key)
    fun readApiKey(): String = secretStore.read()
    fun hasApiKey(): Boolean = readApiKey().isNotBlank()

    fun healthCheck(apiKeyOverride: String? = null): String {
        val key = (apiKeyOverride?.trim().takeUnless { it.isNullOrBlank() } ?: readApiKey().trim())
        if (key.isBlank()) return "Не задан Gemini API-ключ"
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL")
            .header("x-goog-api-key", key)
            .get()
            .build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(geminiError(body, r.code))
            return "Gemini доступен. Модель: $MODEL"
        }
    }

    fun transcribeAudio(file: File, apiKeyOverride: String? = null): String {
        val key = (apiKeyOverride?.trim().takeUnless { it.isNullOrBlank() } ?: readApiKey().trim())
        if (key.isBlank()) error("Не задан Gemini API-ключ")
        if (!file.exists()) error("Аудиофайл не найден")
        if (file.length() > MAX_INLINE_AUDIO) {
            error("Аудиозапись больше 19 МБ. Для длинных разговоров используйте офлайн-режим или увеличьте обработку через Files API.")
        }
        val base64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", TRANSCRIPTION_INSTRUCTION)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", "Расшифруй эту русскоязычную запись разговора. Верни только расшифрованный текст без комментариев."))
                    put(JSONObject().put("inline_data", JSONObject().apply {
                        put("mime_type", "audio/wav")
                        put("data", base64)
                    }))
                })
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.0)
                put("maxOutputTokens", 8192)
            })
        }
        return generate(payload, key).trim().ifBlank { error("Gemini не вернул расшифровку") }
    }

    fun parseOrder(transcript: String, knowledge: JSONArray, apiKeyOverride: String? = null): ParsedOrder {
        val key = (apiKeyOverride?.trim().takeUnless { it.isNullOrBlank() } ?: readApiKey().trim())
        if (key.isBlank()) error("Не задан Gemini API-ключ")
        val schema = orderSchema()
        val knowledgeJson = knowledge.toString()
        val system = """
Ты — модуль расшифровки и разбора заказов приложения «Автозапчасти».
Никогда не придумывай отсутствующие данные. Любое неясное, нерасшифрованное или неоднозначное значение помечай символом ? и добавляй в unknown_fields.
Правила:
1) «Крылья передние, комплект» всегда разворачивай в две строки: «Крыло переднее левое» и «Крыло переднее правое». Количество каждой стороны равно количеству комплектов.
2) Если явно сказано «неокрашенный», «неокрашенная», «без цвета» или цвет отсутствует — раздел НЕОКРАШЕННЫЕ.
3) Если модель 14 и деталь «Пороги» — ПЛАСТИК.
4) Если производитель ABS — ПЛАСТИК. Если позиция явно неокрашенная, раздел НЕОКРАШЕННЫЕ, но производитель ABS сохраняй.
5) Для цветных позиций «Капот», «Крыло переднее левое», «Крыло переднее правое», «Крышка багажника» — МЕТАЛЛ. Остальное — ПЛАСТИК.
6) Используй базу подтверждённых исправлений как дополнительный контекст.
7) Если сказано только «крыло переднее» без стороны и без комплекта — сторона = ?.
8) Количество — целое >= 1.
9) Если непонятна только часть позиции, ставь ? только в этом поле.
10) source_phrase — исходный фрагмент речи.
11) questions — короткие вопросы по позициям с ?.
""".trimIndent()

        val payload = JSONObject().apply {
            put("system_instruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", system)))
            })
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put(
                    "text",
                    "База подтверждённых исправлений:\n$knowledgeJson\n\nНовая заявка:\n$transcript"
                )))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.0)
                put("response_mime_type", "application/json")
                put("response_schema", schema)
                put("maxOutputTokens", 16384)
            })
        }
        val responseText = generate(payload, key)
        return parseResponse(JSONObject(responseText), transcript)
    }

    private fun orderSchema(): JSONObject = JSONObject().apply {
        put("type", "OBJECT")
        put("properties", JSONObject().apply {
            put("rows", JSONObject().apply {
                put("type", "ARRAY")
                put("items", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject().apply {
                        put("model", JSONObject().put("type", "STRING"))
                        put("detail", JSONObject().put("type", "STRING"))
                        put("manufacturer", JSONObject().put("type", "STRING"))
                        put("color", JSONObject().put("type", "STRING"))
                        put("quantity", JSONObject().put("type", "INTEGER"))
                        put("unknown_fields", JSONObject().apply { put("type", "ARRAY"); put("items", JSONObject().put("type", "STRING")) })
                        put("source_phrase", JSONObject().put("type", "STRING"))
                        put("clarification_question", JSONObject().put("type", "STRING"))
                    })
                    put("required", JSONArray(listOf("model", "detail", "manufacturer", "color", "quantity", "unknown_fields", "source_phrase", "clarification_question")))
                })
            })
            put("questions", JSONObject().apply { put("type", "ARRAY"); put("items", JSONObject().put("type", "STRING")) })
        })
        put("required", JSONArray(listOf("rows", "questions")))
    }

    private fun parseResponse(o: JSONObject, transcript: String): ParsedOrder {
        val rowsArray = o.optJSONArray("rows") ?: JSONArray()
        val rows = (0 until rowsArray.length()).mapNotNull { i ->
            val x = rowsArray.optJSONObject(i) ?: return@mapNotNull null
            val model = x.optString("model", "?").ifBlank { "?" }
            val detail = x.optString("detail", "?").ifBlank { "?" }
            val manufacturer = x.optString("manufacturer", "")
            val color = x.optString("color", "")
            val qty = x.optInt("quantity", 1).coerceAtLeast(1)
            val uf = x.optJSONArray("unknown_fields") ?: JSONArray()
            val unknown = uf.length() > 0 || listOf(model, detail, manufacturer, color).any { it == "?" }
            OrderRow(model, detail, manufacturer, color, qty, false, unknown,
                x.optString("source_phrase", transcript), x.optString("clarification_question"))
        }
        val qa = o.optJSONArray("questions") ?: JSONArray()
        val questions = (0 until qa.length()).map { qa.optString(it) }.filter { it.isNotBlank() }
        return ParsedOrder(transcript, rows, questions)
    }

    private fun generate(payload: JSONObject, key: String): String {
        val req = Request.Builder()
            .url(ENDPOINT)
            .header("x-goog-api-key", key)
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(geminiError(body, r.code))
            val root = JSONObject(body)
            val candidates = root.optJSONArray("candidates") ?: JSONArray()
            val pieces = StringBuilder()
            for (i in 0 until candidates.length()) {
                val content = candidates.optJSONObject(i)?.optJSONObject("content") ?: continue
                val parts = content.optJSONArray("parts") ?: continue
                for (j in 0 until parts.length()) {
                    val txt = parts.optJSONObject(j)?.optString("text").orEmpty()
                    if (txt.isNotBlank()) pieces.append(txt)
                }
            }
            if (pieces.isEmpty()) error("Gemini не вернул текст")
            return pieces.toString()
        }
    }

    private fun geminiError(body: String, code: Int): String {
        return try {
            val o = JSONObject(body)
            o.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() } ?: "HTTP $code"
        } catch (_: Exception) { "HTTP $code: ${body.take(300)}" }
    }

    private val TRANSCRIPTION_INSTRUCTION = """
Расшифровывай русскую речь максимально близко к сказанному.
Сохраняй названия моделей, цветов, производителей и деталей.
Не угадывай неизвестные слова.
Используй контекст предметной области: автомобильные кузовные детали, решетки, крылья, капоты, ПТФ, реснички, цвета и заводские обозначения.
""".trimIndent()
}
