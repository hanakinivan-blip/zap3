package com.example.avtozapchasti

import android.content.Context
import org.json.JSONObject

class OfflineOrderParser(private val context: Context, private val kb: KnowledgeBase) {
    private data class Catalog(
        val models: List<String>,
        val details: List<String>,
        val manufacturers: List<String>,
        val colors: List<String>
    )

    private val catalog: Catalog by lazy { loadCatalog() }

    fun parse(text: String): ParsedOrder {
        val normalized = normalize(text)
        val chunks = normalized
            .split(Regex("[.;\\n]+|\\s+и\\s+(?=решет|реснич|крыл|капот|перед|зад|порог|крыш|птф)"))
            .map { it.trim(' ', ',', ';', ':') }
            .filter { it.isNotBlank() }

        val rows = mutableListOf<OrderRow>()
        val questions = mutableListOf<String>()

        for (chunk in chunks) {
            val learned = kb.entries()
                .firstOrNull { chunk.contains(it.phrase.lowercase(LocaleHack.ru), ignoreCase = true) }

            if (learned != null) {
                rows += OrderRow(
                    learned.model, learned.detail, learned.manufacturer, learned.color,
                    quantity = quantity(chunk),
                    sourcePhrase = chunk
                )
                continue
            }

            val model = findLongest(chunk, catalog.models)
            val detail = findDetail(chunk)
            val manufacturer = findLongest(chunk, catalog.manufacturers)
            val color = findColor(chunk)
            val qty = quantity(chunk)

            if (model == null && detail == null) continue

            if (detail?.contains("комплект", true) == true || (chunk.contains("комплект") && (detail?.contains("крыл", true) == true || chunk.contains("крыл")))) {
                val baseDetail = "Крыло переднее"
                rows += OrderRow(model ?: "?", "$baseDetail левое", manufacturer.orEmpty(), color ?: "Неокрашенный", qty, sourcePhrase = chunk)
                rows += OrderRow(model ?: "?", "$baseDetail правое", manufacturer.orEmpty(), color ?: "Неокрашенный", qty, sourcePhrase = chunk)
                continue
            }

            val finalDetail = when {
                detail != null -> detail
                chunk.contains("крыл") -> "Крыло переднее"
                else -> "?"
            }

            val finalModel = model ?: "?"
            val finalColor = color ?: "Неокрашенный"
            val unknown = finalModel == "?" || finalDetail == "?" ||
                    (manufacturer == null && chunk.contains("завод", true)) ||
                    chunk.contains("непонят", true)

            val row = OrderRow(
                model = finalModel,
                detail = finalDetail,
                manufacturer = manufacturer.orEmpty(),
                color = finalColor,
                quantity = qty,
                unknown = unknown,
                sourcePhrase = chunk,
                clarificationQuestion = if (unknown) "Уточните: $chunk" else ""
            )
            rows += row
            if (unknown) questions += row.clarificationQuestion
        }

        return ParsedOrder(normalized, rows, questions)
    }

    private fun normalize(src: String): String {
        var s = src.lowercase()
        val replacements = mapOf(
            "снег" to "снежная королева 690",
            "барнео" to "борнео 633",
            "золотынков" to "золото инков 347",
            "techno" to "техно 618",
            "техно" to "техно 618",
            "riesling" to "рислинг 610",
            "panthera" to "пантера 672",
            "боровница" to "боровница 451",
            "221-й" to "ледниковый 221",
            "633-й" to "борнео 633",
            "портвейн" to "портвейн 192",
            "одиссей" to "одиссей 497",
            "691-й" to "платина 691",
            "булат" to "булат 619",
            "белое облако" to "белое облако 240",
            "млечка" to "млечка 606",
            "космос" to "космос 665",
            "ницца" to "ницца 328",
            "790-й" to "кориандр 790",
            "672" to "пантера 672",
            "665-й" to "космос 665",
            "кварц" to "кварц 630",
            "610-й" to "рислинг 610",
            "птф" to "птф"
        )
        replacements.forEach { (a, b) -> s = s.replace(a, b) }
        s = s.replace(Regex("\\bтри\\b"), "3")
        s = s.replace(Regex("\\bдве\\b|\\bдва\\b"), "2")
        s = s.replace(Regex("\\bодна\\b|\\bодин\\b"), "1")
        s = s.replace(Regex("\\bчетыре\\b"), "4")
        s = s.replace("4-й", "724")
        return s
    }

    private fun findDetail(chunk: String): String? {
        val d = listOf(
            "крылья передние комплект" to "Крылья передние комплект",
            "крыло переднее левое" to "Крыло переднее левое",
            "крыло переднее правое" to "Крыло переднее правое",
            "крылья передние" to "Крылья передние комплект",
            "крышка багажника" to "Крышка багажника",
            "решетка нижняя" to "Решетка нижняя",
            "решетка верхняя" to "Решетка верхняя",
            "реснички" to "Реснички",
            "пороги" to "Пороги",
            "решетка" to "Решетка",
            "капот" to "Капот",
            "зад птф" to "Зад ПТФ",
            "птф" to "ПТФ",
            "перед" to "Перед",
            "вперед" to "Перед",
            "зад" to "Зад"
        )
        return d.firstOrNull { chunk.contains(it.first) }?.second
    }

    private fun findColor(chunk: String): String? =
        catalog.colors.sortedByDescending { it.length }.firstOrNull { chunk.contains(it.lowercase()) }?.let { canonicalColor(it) }

    private fun canonicalColor(c: String): String {
        return when (c.lowercase()) {
            "снежная королева 690" -> "Снежная королева 690"
            else -> c
        }
    }

    private fun findLongest(chunk: String, items: List<String>): String? =
        items.sortedByDescending { it.length }.firstOrNull { chunk.contains(it.lowercase()) }

    private fun quantity(chunk: String): Int {
        val m = Regex("""(?<!\\d)(\\d+)\\s*(?:штук|штуки|шт|комплект(?:а|ов)?)?""").find(chunk)
        if (m != null) return m.groupValues[1].toIntOrNull()?.coerceAtLeast(1) ?: 1
        return 1
    }

    private fun loadCatalog(): Catalog {
        val raw = context.assets.open("reference_catalog.json").bufferedReader().use { it.readText() }
        val o = JSONObject(raw)
        fun list(name: String) = buildList {
            val a = o.getJSONArray(name)
            for (i in 0 until a.length()) add(a.getString(i))
        }
        return Catalog(
            list("known_models"),
            list("known_details"),
            list("known_manufacturers"),
            list("known_colors")
        )
    }

    private object LocaleHack {
        val ru = java.util.Locale("ru")
    }
}
