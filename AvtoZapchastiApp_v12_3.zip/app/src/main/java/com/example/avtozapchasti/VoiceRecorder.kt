package com.example.avtozapchasti

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean

class VoiceRecorder(private val context: Context) {
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var output: File? = null
    private val recording = AtomicBoolean(false)

    companion object {
        const val SAMPLE_RATE = 16_000
        const val CHANNELS = 1
        const val BITS = 16
    }

    fun start(): File {
        stop(deleteIncomplete = true)
        val dir = File(context.filesDir, "voice_notes").apply { mkdirs() }
        val file = File(dir, "note_${System.currentTimeMillis()}.wav")

        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        require(minBuffer > 0) { "Микрофон недоступен" }
        val bufferSize = (minBuffer * 2).coerceAtLeast(SAMPLE_RATE)

        val r = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            throw IllegalStateException("Не удалось инициализировать микрофон")
        }

        writeWavHeader(file, 0)

        try {
            r.startRecording()
        } catch (e: Exception) {
            r.release()
            file.delete()
            throw IllegalStateException("Не удалось начать запись: ${e.message}", e)
        }

        recorder = r
        output = file
        recording.set(true)

        worker = Thread {
            try {
                FileOutputStream(file, true).use { out ->
                    val pcm = ByteArray(bufferSize)
                    while (recording.get()) {
                        val read = r.read(pcm, 0, pcm.size)
                        if (read > 0) out.write(pcm, 0, read)
                    }
                    out.flush()
                }
            } finally {
                try { r.stop() } catch (_: Exception) {}
                r.release()
            }
            updateWavHeader(file)
        }.also { it.start() }

        return file
    }

    fun stop(deleteIncomplete: Boolean = false): File? {
        if (!recording.getAndSet(false)) {
            return output
        }
        try { worker?.join(2_000) } catch (_: InterruptedException) {}
        worker = null
        recorder = null
        val file = output
        output = null

        if (deleteIncomplete && file != null) {
            file.delete()
            return null
        }
        if (file != null && (!file.exists() || file.length() <= 44L)) {
            file.delete()
            return null
        }
        return file
    }

    fun isRecording(): Boolean = recording.get()

    private fun writeWavHeader(file: File, dataSize: Long) {
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            raf.writeBytes("RIFF")
            writeLEInt(raf, (36 + dataSize).toInt())
            raf.writeBytes("WAVE")
            raf.writeBytes("fmt ")
            writeLEInt(raf, 16)
            writeLEShort(raf, 1)
            writeLEShort(raf, CHANNELS.toShort())
            writeLEInt(raf, SAMPLE_RATE)
            writeLEInt(raf, SAMPLE_RATE * CHANNELS * BITS / 8)
            writeLEShort(raf, (CHANNELS * BITS / 8).toShort())
            writeLEShort(raf, BITS.toShort())
            raf.writeBytes("data")
            writeLEInt(raf, dataSize.toInt())
        }
    }

    private fun updateWavHeader(file: File) {
        if (!file.exists()) return
        val dataSize = (file.length() - 44L).coerceAtLeast(0L)
        writeWavHeader(file, dataSize)
    }

    private fun writeLEInt(raf: RandomAccessFile, value: Int) {
        raf.write(value and 0xff)
        raf.write((value shr 8) and 0xff)
        raf.write((value shr 16) and 0xff)
        raf.write((value shr 24) and 0xff)
    }

    private fun writeLEShort(raf: RandomAccessFile, value: Short) {
        val v = value.toInt()
        raf.write(v and 0xff)
        raf.write((v shr 8) and 0xff)
    }
}
