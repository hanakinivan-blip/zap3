package com.example.avtozapchasti

import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTransducerModelConfig
import java.io.File

class OfflineTranscriber(private val modelManager: OfflineModelManager) {
    fun isReady(): Boolean = modelManager.isInstalled()

    fun transcribe(wav: File): String {
        require(isReady()) { "Офлайн-модель речи ещё не установлена" }
        val dir = modelManager.modelDir()

        val modelConfig = OfflineModelConfig(
            transducer = OfflineTransducerModelConfig(
                encoder = File(dir, "encoder.int8.onnx").absolutePath,
                decoder = File(dir, "decoder.onnx").absolutePath,
                joiner = File(dir, "joiner.int8.onnx").absolutePath
            ),
            tokens = File(dir, "tokens.txt").absolutePath,
            numThreads = maxOf(2, Runtime.getRuntime().availableProcessors().coerceAtMost(4)),
            provider = "cpu",
            modelType = "transducer"
        )

        val config = OfflineRecognizerConfig(
            featConfig = FeatureConfig(),
            modelConfig = modelConfig,
            decodingMethod = "greedy_search",
            maxActivePaths = 4
        )

        val recognizer = OfflineRecognizer(config = config)
        return try {
            val wav = WavReader.readMonoPcm16(wav)
            val stream = recognizer.createStream()
            try {
                stream.acceptWaveform(wav.samples, wav.sampleRate)
                recognizer.decode(stream)
                recognizer.getResult(stream).text.trim()
            } finally {
                stream.release()
            }
        } finally {
            recognizer.release()
        }
    }
}
