package com.example.avtozapchasti

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream

class OfflineModelManager(private val context: Context) {
    companion object {
        const val MODEL_DIR_NAME = "sherpa-onnx-small-zipformer-ru-2024-09-18"
        const val MODEL_ARCHIVE_NAME = "sherpa-onnx-small-zipformer-ru-2024-09-18.tar.bz2"
        const val MODEL_URL =
            "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/$MODEL_ARCHIVE_NAME"
    }

    private val root = File(context.filesDir, "offline_asr")
    private val modelDir = File(root, MODEL_DIR_NAME)
    private val executor = Executors.newSingleThreadExecutor()

    init {
        root.mkdirs()
    }

    fun isInstalled(): Boolean {
        return File(modelDir, "encoder.int8.onnx").exists() &&
            File(modelDir, "decoder.onnx").exists() &&
            File(modelDir, "joiner.int8.onnx").exists() &&
            File(modelDir, "tokens.txt").exists()
    }

    fun modelDir(): File = modelDir

    fun downloadAsync(onProgress: (Int) -> Unit, onDone: (Result<File>) -> Unit) {
        executor.execute {
            try {
                root.mkdirs()
                val tmp = File(root, MODEL_ARCHIVE_NAME + ".part")
                val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    requestMethod = "GET"
                    doInput = true
                }
                connection.connect()
                val code = connection.responseCode
                if (code !in 200..299) {
                    throw IllegalStateException("HTTP $code")
                }
                val total = connection.contentLengthLong
                connection.inputStream.use { input ->
                    FileOutputStream(tmp).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var readTotal = 0L
                        var read = input.read(buffer)
                        while (read >= 0) {
                            output.write(buffer, 0, read)
                            readTotal += read
                            if (total > 0) {
                                onProgress(((readTotal * 100L) / total).toInt().coerceIn(0, 100))
                            }
                            read = input.read(buffer)
                        }
                        output.flush()
                    }
                }
                connection.disconnect()

                if (modelDir.exists()) modelDir.deleteRecursively()
                extractTarBz2(tmp, root)
                tmp.delete()

                if (!isInstalled()) {
                    throw IllegalStateException("Архив скачан, но файлы модели не найдены")
                }
                onDone(Result.success(modelDir))
            } catch (t: Throwable) {
                onDone(Result.failure(t))
            }
        }
    }

    private fun extractTarBz2(archive: File, destination: File) {
        BZip2CompressorInputStream(archive.inputStream().buffered()).use { bz2 ->
            TarArchiveInputStream(bz2).use { tar ->
                var entry = tar.nextTarEntry
                val buffer = ByteArray(64 * 1024)
                while (entry != null) {
                    val out = File(destination, entry.name)
                    val canonicalDest = destination.canonicalPath + File.separator
                    if (!out.canonicalPath.startsWith(canonicalDest)) {
                        throw SecurityException("Недопустимый путь в архиве")
                    }
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { output ->
                            var read = tar.read(buffer)
                            while (read >= 0) {
                                output.write(buffer, 0, read)
                                read = tar.read(buffer)
                            }
                        }
                    }
                    entry = tar.nextTarEntry
                }
            }
        }
    }

    fun deleteModel() {
        if (root.exists()) root.deleteRecursively()
        root.mkdirs()
    }

    fun shutdown() = executor.shutdownNow()
}
