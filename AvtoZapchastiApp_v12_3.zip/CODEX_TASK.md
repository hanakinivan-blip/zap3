# Задача для Codex — v11

Сделай основной рабочий режим приложения полностью офлайн после одноразовой загрузки модели.

1. Собери проект: ./gradlew assembleDebug.
2. Исправь все ошибки сборки.
3. Проверь интеграцию sherpa-onnx v1.13.8.
4. Проверь WAV-запись и локальное сохранение.
5. Проверь загрузку и распаковку русской модели small Zipformer.
6. Проверь офлайн-расшифровку.
7. Проверь локальный разбор заявки.
8. Не использовать OpenAI/Gemini в основном сценарии.
9. После установки модели приложение должно работать без интернета.
10. Проверить неизвестные позиции `?`, комплект крыльев, ABS, 14-е пороги и разделы.
11. Повторно выполнить ./gradlew assembleDebug.


### v12 Gemini Free
- Добавлен режим Gemini Free с моделью `gemini-3.1-flash-lite`.
- Gemini 3.1 Flash-Lite поддерживает аудио-вход и Structured Outputs.
- Если Gemini недоступен и офлайн-модель установлена, приложение автоматически переключает конкретную операцию в офлайн-режим.
- API-ключ хранится в Android Keystore/SharedPreferences в зашифрованном виде; для production Google рекомендует backend proxy вместо клиентского хранения ключа.


## Исправление зависимости sherpa-onnx
Если GitHub Actions пишет `Could not find com.github.k2-fsa.sherpa-onnx:sherpa-onnx:v1.13.8`,
не возвращайся к JitPack. Используй официальный Android AAR из релиза sherpa-onnx v1.13.8.
Проверь workflow `.github/workflows/build-apk.yml` и `app/build.gradle.kts`.


## v12.2
Используй автоматическую загрузку sherpa-onnx AAR из `app/build.gradle.kts`.
Не рассчитывай на ручное добавление 47.8 MB файла в GitHub через web upload.
Перед `checkDebugAarMetadata` должен существовать и проходить SHA-256 файл `app/libs/sherpa-onnx-1.13.8.aar`.
