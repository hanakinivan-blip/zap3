package com.example.avtozapchasti

import android.content.Context
import android.media.MediaRecorder
import java.io.File

class VoiceRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var output: File? = null
    private var startedAt = 0L

    fun start(): File {
        stop(deleteIncomplete = true)
        val dir = File(context.filesDir, "voice_notes").apply { mkdirs() }
        val file = File(dir, "note_${System.currentTimeMillis()}.m4a")
        val r = if (android.os.Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(16_000)
            r.setAudioEncodingBitRate(64_000)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
        } catch (e: Exception) {
            try { r.reset() } catch (_: Exception) {}
            try { r.release() } catch (_: Exception) {}
            file.delete()
            throw IllegalStateException("Не удалось начать запись: ${e.message ?: "доступ к микрофону занят"}", e)
        }
        recorder = r
        output = file
        startedAt = System.currentTimeMillis()
        return file
    }

    fun stop(deleteIncomplete: Boolean = false): File? {
        val r = recorder ?: return output
        val file = output
        try {
            // MediaRecorder.stop() can fail when recording is too short.
            r.stop()
        } catch (_: Exception) {
            if (deleteIncomplete) file?.delete()
            try { r.reset() } catch (_: Exception) {}
            try { r.release() } catch (_: Exception) {}
            recorder = null
            output = null
            return null
        }
        try { r.release() } catch (_: Exception) {}
        recorder = null
        output = null
        return file
    }

    fun isRecording(): Boolean = recorder != null
    fun recordingDurationMs(): Long = if (startedAt == 0L) 0L else System.currentTimeMillis() - startedAt
}
