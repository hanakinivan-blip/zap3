package com.example.avtozapchasti

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class KnowledgeBase(private val context: Context) {
    private val prefs = context.getSharedPreferences("knowledge_base", Context.MODE_PRIVATE)

    data class Entry(
        val phrase: String,
        val model: String,
        val detail: String,
        val manufacturer: String,
        val color: String,
        val section: String
    ) {
        fun toJson() = JSONObject().apply {
            put("phrase", phrase); put("model", model); put("detail", detail)
            put("manufacturer", manufacturer); put("color", color); put("section", section)
        }
    }

    fun entries(): List<Entry> {
        val a = JSONArray(prefs.getString("entries", "[]"))
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            Entry(o.optString("phrase"), o.optString("model"), o.optString("detail"),
                o.optString("manufacturer"), o.optString("color"), o.optString("section"))
        }
    }

    fun add(sourcePhrase: String, row: OrderRow, section: Section) {
        val clean = sourcePhrase.trim()
        if (clean.isBlank() || row.unknown) return
        val list = entries().toMutableList()
        list.removeAll { it.phrase.equals(clean, ignoreCase = true) }
        list.add(Entry(clean, row.model, row.detail, row.manufacturer, row.color, section.title))
        val out = JSONArray(); list.takeLast(500).forEach { out.put(it.toJson()) }
        prefs.edit().putString("entries", out.toString()).apply()
    }

    fun toJsonArray(): JSONArray {
        val a = JSONArray(); entries().forEach { a.put(it.toJson()) }; return a
    }

    fun clear() = prefs.edit().remove("entries").apply()
}
