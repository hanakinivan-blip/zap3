package com.example.avtozapchasti

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class CallAssistantReceiver : BroadcastReceiver() {
    companion object {
        private const val CHANNEL_ID = "call_assistant"
        private const val NOTIFICATION_ID = 4707
        private const val PREFS = "orders"
        private const val ENABLED_KEY = "call_assistant_enabled"

        fun isEnabled(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(ENABLED_KEY, true)
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (!isEnabled(context)) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        ensureChannel(context)

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                show(context, "Входящий звонок", "Откройте «Автозапчасти», чтобы записать разговор и сформировать заявку.")
            }

            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                show(context, "Разговор идёт", "Нажмите уведомление, чтобы открыть помощник заявки.")
            }

            TelephonyManager.EXTRA_STATE_IDLE -> {
                NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
            }
        }
    }

    private fun show(context: Context, title: String, text: String) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            action = MainActivity.ACTION_CALL_ASSISTANT
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            4707,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Notification permission may not yet be granted.
        }
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Помощник при звонках",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Уведомление для быстрого открытия записи разговора и заявки."
                }
            )
        }
    }
}
