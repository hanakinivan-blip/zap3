package com.example.avtozapchasti

import org.json.JSONArray
import org.json.JSONObject

data class OrderRow(
    var model: String,
    var detail: String,
    var manufacturer: String,
    var color: String,
    var quantity: Int = 1,
    var done: Boolean = false,
    var unknown: Boolean = false,
    var sourcePhrase: String = "",
    var clarificationQuestion: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("model", model); put("detail", detail); put("manufacturer", manufacturer)
        put("color", color); put("quantity", quantity); put("done", done)
        put("unknown", unknown); put("sourcePhrase", sourcePhrase)
        put("clarificationQuestion", clarificationQuestion)
    }

    companion object {
        fun fromJson(o: JSONObject) = OrderRow(
            model = o.optString("model"),
            detail = o.optString("detail"),
            manufacturer = o.optString("manufacturer"),
            color = o.optString("color"),
            quantity = o.optInt("quantity", 1),
            done = o.optBoolean("done", false),
            unknown = o.optBoolean("unknown", false),
            sourcePhrase = o.optString("sourcePhrase"),
            clarificationQuestion = o.optString("clarificationQuestion")
        )
    }
}

enum class Section(val title: String) {
    UNPAINTED("НЕОКРАШЕННЫЕ"),
    METAL("МЕТАЛЛ"),
    PLASTIC("ПЛАСТИК")
}

data class ParsedOrder(
    val transcript: String,
    val rows: List<OrderRow>,
    val questions: List<String>
)
