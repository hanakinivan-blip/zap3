#!/usr/bin/env bash
set -euo pipefail
python3 -m venv .venv 2>/dev/null || true
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY="${OPENAI_API_KEY:?Set OPENAI_API_KEY}"
export OPENAI_ORDER_MODEL="${OPENAI_ORDER_MODEL:-gpt-5.6-luna}"
export OPENAI_TRANSCRIBE_MODEL="${OPENAI_TRANSCRIBE_MODEL:-gpt-4o-transcribe}"
uvicorn main:app --host 0.0.0.0 --port 8787
