package com.example.avtozapchasti

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors

/**
 * Unified AI gateway:
 * AUTO -> Gemini -> ChatGPT -> local parser
 * GEMINI -> Gemini -> ChatGPT -> local parser
 * CHATGPT -> ChatGPT -> Gemini -> local parser
 *
 * API keys stay on the device. One provider failing (quota, region, network)
 * never stops the order workflow.
 */
object AiProviderManager {
    private const val PREFS = "ai_settings"
    private const val KEY_PROVIDER = "ai_provider"
    private const val OPENAI_KEY = "api_key"
    private const val GEMINI_KEY = "gemini_api_key"
    private const val KEY_WEB = "web_search"
    private const val KEY_CLOUD = "cloud_transcription"
    private val executor = Executors.newCachedThreadPool()

    enum class Provider { AUTO, GEMINI, CHATGPT }

    data class Result(
        val rows: List<OrderRow>,
        val source: String,
        val raw: String = "",
        val warning: String? = null
    )

    data class TextResult(
        val text: String,
        val source: String,
        val warning: String? = null
    )

    fun getProvider(context: Context): Provider =
        runCatching { Provider.valueOf(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PROVIDER, "AUTO") ?: "AUTO") }
            .getOrDefault(Provider.AUTO)

    fun setProvider(context: Context, p: Provider) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PROVIDER, p.name).apply()

    fun getOpenAiKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(OPENAI_KEY, "").orEmpty()

    fun setOpenAiKey(context: Context, key: String) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(OPENAI_KEY, key.trim()).apply()

    fun getGeminiKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(GEMINI_KEY, "").orEmpty()

    fun setGeminiKey(context: Context, key: String) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(GEMINI_KEY, key.trim()).apply()

    fun hasAnyKey(context: Context) = getOpenAiKey(context).isNotBlank() || getGeminiKey(context).isNotBlank()

    fun webSearchEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_WEB, true)

    fun setWebSearch(context: Context, value: Boolean) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_WEB, value).apply()

    fun cloudEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_CLOUD, true)

    fun setCloudEnabled(context: Context, value: Boolean) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_CLOUD, value).apply()

    fun providerTitle(p: Provider) = when (p) {
        Provider.AUTO -> "Авто: Gemini → ChatGPT → локально"
        Provider.GEMINI -> "Gemini → ChatGPT → локально"
        Provider.CHATGPT -> "ChatGPT → Gemini → локально"
    }

    fun analyzeAsync(context: Context, transcript: String, callback: (Result) -> Unit) {
        executor.execute {
            val provider = getProvider(context)
            val attempts = when (provider) {
                Provider.GEMINI -> listOf("Gemini", "ChatGPT")
                Provider.CHATGPT -> listOf("ChatGPT", "Gemini")
                Provider.AUTO -> listOf("Gemini", "ChatGPT")
            }
            val errors = mutableListOf<String>()

            for (name in attempts) {
                try {
                    if (name == "Gemini" && getGeminiKey(context).isNotBlank()) {
                        val r = GeminiOrderAnalyzer.requestSync(context, transcript)
                        if (r.rows.isNotEmpty()) return@execute post(callback, Result(r.rows, "Gemini", r.raw, errors.joinToString(" " ).ifBlank { null }))
                    }
                    if (name == "ChatGPT" && getOpenAiKey(context).isNotBlank()) {
                        val r = OpenAiCompat.requestSync(context, transcript)
                        if (r.rows.isNotEmpty()) return@execute post(callback, Result(r.rows, "ChatGPT", r.raw, errors.joinToString(" ").ifBlank { null }))
                    }
                } catch (e: Exception) {
                    errors += "$name: ${friendlyError(e.message)}"
                }
            }

            val local = OrderParser.parse(transcript)
            val warning = if (errors.isEmpty()) "AI не настроен — использован локальный анализ." else
                "AI недоступен, использован локальный анализ. ${errors.joinToString(" ")}"
            post(callback, Result(local, "Локально", warning = warning))
        }
    }

    fun transcribeAsync(context: Context, file: File, callback: (TextResult) -> Unit) {
        executor.execute {
            val provider = getProvider(context)
            val attempts = when (provider) {
                Provider.GEMINI -> listOf("Gemini", "ChatGPT")
                Provider.CHATGPT -> listOf("ChatGPT", "Gemini")
                Provider.AUTO -> listOf("Gemini", "ChatGPT")
            }
            val errors = mutableListOf<String>()
            for (name in attempts) {
                try {
                    if (name == "Gemini" && getGeminiKey(context).isNotBlank()) {
                        val text = GeminiTranscriber.requestSync(context, file)
                        if (text.isNotBlank()) return@execute post(callback, TextResult(text, "Gemini", errors.joinToString(" ").ifBlank { null }))
                    }
                    if (name == "ChatGPT" && getOpenAiKey(context).isNotBlank()) {
                        val text = CloudTranscriber.requestSync(context, file)
                        if (text.isNotBlank()) return@execute post(callback, TextResult(text, "ChatGPT", errors.joinToString(" ").ifBlank { null }))
                    }
                } catch (e: Exception) {
                    errors += "$name: ${friendlyError(e.message)}"
                }
            }
            post(callback, TextResult("", "Локально", if (errors.isEmpty()) "Онлайн-ключи не настроены." else "Онлайн-расшифровка недоступна. Продолжаем с локальной расшифровкой."))
        }
    }

    private fun <T> post(callback: (T) -> Unit, value: T) =
        Handler(Looper.getMainLooper()).post { callback(value) }

    private fun friendlyError(raw: String?): String {
        val s = raw.orEmpty()
        return when {
            s.contains("credit_balance_exhausted", true) || s.contains("insufficient_quota", true) || s.contains("HTTP 429", true) ->
                "закончилась квота/кредиты"
            s.contains("unsupported_country_region_territory", true) || s.contains("HTTP 403", true) ->
                "провайдер недоступен в текущем регионе"
            s.contains("401", true) || s.contains("invalid_api_key", true) ->
                "неверный API-ключ"
            s.contains("RESOURCE_EXHAUSTED", true) ->
                "достигнута квота Gemini"
            else -> "временная ошибка сети/API"
        }
    }

    /**
     * Small adapter around the existing OpenAI analyzer so it can be used
     * synchronously by the fallback gateway.
     */
    private object OpenAiCompat {
        fun requestSync(context: Context, transcript: String): AiOrderAnalyzer.Result {
            return AiOrderAnalyzer.requestSync(context, transcript)
        }
    }
}
