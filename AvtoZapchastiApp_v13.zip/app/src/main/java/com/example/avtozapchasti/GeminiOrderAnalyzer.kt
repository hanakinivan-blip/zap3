package com.example.avtozapchasti

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object GeminiOrderAnalyzer {
    private const val PREFS = "ai_settings"
    private const val KEY_API = "gemini_api_key"
    private const val KEY_WEB = "web_search"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"
    private val executor = Executors.newCachedThreadPool()
    data class Result(val rows: List<OrderRow>, val raw: String = "")

    fun hasKey(context: Context): Boolean = getKey(context).isNotBlank()
    fun getKey(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_API, "").orEmpty()
    fun setKey(context: Context, key: String) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_API, key.trim()).apply()
    fun webSearchEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_WEB, true)
    fun setWebSearch(context: Context, enabled: Boolean) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_WEB, enabled).apply()

    fun analyzeAsync(context: Context, transcript: String, callback: (Result?, String?) -> Unit) {
        val key = getKey(context)
        if (key.isBlank()) { callback(null, "AI не настроен: добавьте API-ключ Gemini"); return }
        executor.execute {
            try { val r = request(context, key, transcript); Handler(Looper.getMainLooper()).post { callback(r, null) } }
            catch (e: Exception) { Handler(Looper.getMainLooper()).post { callback(null, e.message ?: "Ошибка Gemini AI") } }
        }
    }

    fun requestSync(context: Context, transcript: String): Result {
        val key = getKey(context)
        if (key.isBlank()) throw IllegalStateException("Gemini API-ключ не задан")
        return request(context, key, transcript)
    }

    private fun request(context: Context, key: String, transcript: String): Result {
        val prompt = """
Ты профессиональный диспетчер заявок по кузовным автозапчастям. Проанализируй ВЕСЬ русский разговор, даже если автоматическая расшифровка содержит фонетические ошибки, пропуски, перестановки или неверно услышанные слова. Восстанови смысл по контексту. Если модель/деталь звучит похоже на известный автомобильный термин, проверь себя. Если включён поиск, используй Google Search для проверки сомнительных названий.

Верни ТОЛЬКО JSON:
{"items":[{"model":"","detail":"","manufacturer":"","color":"","quantity":1}]}

Правила:
Количество по умолчанию 1. «комплект передних крыльев» = две строки КПЛ и КПП; количество комплектов умножает обе стороны.
Модели: Датсун/Дадсун/Datsun -> 95; Ларгус/Largus/ларгу -> Largus; Веста/Веста седан -> Vesta; Урбан ПТФ -> Урбан ПТФ; 2113/2114/2115 -> 2114 и ВАЗ; Калина 118 -> 118; X-Ray; 720/4-й -> 724 без производителя 4-й.
Детали: ДПЛ, ДПП, ДЗЛ, ДЗП, КПЛ, КПП, Решётка нижняя, Капот, Лючок бензобака, Петля капота, Дверь задка, Дверь задка левая глухая, ПТФ. «без поворотника», «с поворотником», «дешёвый» сохраняй в detail.
Производители: Тайвань, Китай, ВАЗ, Челны, ABS, NG, Sport. Завод/заводской -> ВАЗ. ABS в manufacturer, не в detail. ABS + Тайвань -> ABS, Тайвань.
Цвета: Снежная королева 690, Млечка 606, Ледяной 413, Техно 618, Белое облако 240, Плутон 608, Рислинг 610, Космос 665, Баклажан 107, Золото инков 347, Боровница 451, Портвейн 192, Кварц 630, Ницца 328, Пантера 672, Борнео 633, Кориандр 790, Платина 691, Одиссей 497, Булат 619, Ледниковый 221, Мускари 426, Персей 429, Калифорнийский мак 190, Черника 482, Чёрная жемчужина 676, B66, 693. «снег», «снежка» -> Снежная королева 690.
Если не уверен в позиции — не выдумывай её. Но не требуй, чтобы все поля были произнесены в одной фразе: используй контекст разговора.

РАСШИФРОВКА:
${transcript.takeLast(30000)}
        """.trimIndent()
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply { put("parts", JSONArray().put(JSONObject().put("text", prompt))) }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.1)
                put("responseMimeType", "application/json")
            })
            if (webSearchEnabled(context)) put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 90000; doOutput = true
            setRequestProperty("x-goog-api-key", key); setRequestProperty("Content-Type", "application/json")
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw IllegalStateException("Gemini AI HTTP $code: ${responseText.take(600)}")
        val response = JSONObject(responseText)
        val text = extractText(response).trim()
        val json = extractJson(text)
        val arr = json.optJSONArray("items") ?: JSONArray()
        val rows = mutableListOf<OrderRow>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val detail = o.optString("detail").trim(); if (detail.isBlank()) continue
            rows += OrderRow(o.optString("model").trim(), detail, o.optString("manufacturer").trim(), o.optString("color").trim(), o.optInt("quantity", 1).coerceAtLeast(1))
        }
        return Result(rows.distinctBy { "${it.model}|${it.detail}|${it.manufacturer}|${it.color}|${it.quantity}" }, text)
    }

    private fun extractText(response: JSONObject): String {
        val candidates = response.optJSONArray("candidates") ?: return ""
        val b = StringBuilder()
        for (i in 0 until candidates.length()) {
            val content = candidates.optJSONObject(i)?.optJSONObject("content") ?: continue
            val parts = content.optJSONArray("parts") ?: continue
            for (j in 0 until parts.length()) b.append(parts.optJSONObject(j)?.optString("text").orEmpty())
        }
        return b.toString()
    }

    private fun extractJson(text: String): JSONObject {
        val cleaned = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val s = cleaned.indexOf('{'); val e = cleaned.lastIndexOf('}')
        if (s < 0 || e <= s) throw IllegalStateException("Gemini не вернул JSON заявки")
        return JSONObject(cleaned.substring(s, e + 1))
    }
}
