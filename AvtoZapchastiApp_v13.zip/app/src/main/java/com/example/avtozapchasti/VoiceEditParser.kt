package com.example.avtozapchasti

/** Parses short Russian voice commands used to edit the current order. */
object VoiceEditParser {
    data class Command(val action: Action, val rowIndex: Int = -1, val field: Field? = null, val value: String = "")
    enum class Action { EDIT, DELETE, ADD, UNKNOWN }
    enum class Field { MODEL, DETAIL, MANUFACTURER, COLOR, QUANTITY }

    fun parse(text: String, rows: List<OrderRow>): Command {
        val s = text.lowercase().replace('ё', 'е').trim()
        if (s.isBlank()) return Command(Action.UNKNOWN)
        if (s.contains("удали") || s.contains("удалить")) return Command(Action.DELETE, findRow(s, rows))
        if (s.contains("добавь") || s.contains("добавить")) return Command(Action.ADD)
        val field = when {
            s.contains("колич") || s.contains("штук") || s.contains("штуки") -> Field.QUANTITY
            s.contains("производител") -> Field.MANUFACTURER
            s.contains("цвет") -> Field.COLOR
            s.contains("детал") -> Field.DETAIL
            s.contains("модел") || s.contains("машин") -> Field.MODEL
            else -> null
        }
        if (field == null) return Command(Action.UNKNOWN)
        val idx = findRow(s, rows)
        val value = valueAfterField(s, field)
        return if (value.isBlank()) Command(Action.UNKNOWN) else Command(Action.EDIT, idx, field, value)
    }

    private fun findRow(s: String, rows: List<OrderRow>): Int {
        Regex("(?:позици(?:я|и)|строк(?:а|у)|номер)\\s*(?:номер\\s*)?(\\d+)").find(s)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { n -> if (n in 1..rows.size) return n - 1 }
        if (s.contains("последн")) return rows.lastIndex
        if (s.contains("перв")) return if (rows.isNotEmpty()) 0 else -1
        rows.indexOfLast { r -> r.detail != "???" && (s.contains(r.detail.lowercase()) || (r.model.isNotBlank() && s.contains(r.model.lowercase()))) }
            .takeIf { it >= 0 }?.let { return it }
        return if (rows.size == 1) 0 else -1
    }

    private fun valueAfterField(s: String, field: Field): String {
        val markers = when (field) {
            Field.MODEL -> listOf("модель", "машину")
            Field.DETAIL -> listOf("деталь")
            Field.MANUFACTURER -> listOf("производитель")
            Field.COLOR -> listOf("цвет")
            Field.QUANTITY -> listOf("количество", "штук", "штуки")
        }
        for (m in markers) {
            val i = s.indexOf(m)
            if (i >= 0) {
                val v = s.substring(i + m.length).replace(Regex("^(?:поставить|поставь|сделать|сделай|заменить|замени|на)\\s+"), "").trim()
                if (v.isNotBlank()) return v
            }
        }
        return ""
    }
}
