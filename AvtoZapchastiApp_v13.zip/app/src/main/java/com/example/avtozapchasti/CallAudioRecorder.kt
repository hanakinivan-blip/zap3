package com.example.avtozapchasti

import android.media.MediaRecorder
import android.os.Environment
import java.io.File

class CallAudioRecorder(private val filesDir: File) {
    private var recorder: MediaRecorder? = null
    var currentFile: File? = null
        private set

    fun start(): Boolean {
        stop()
        val dir = File(filesDir, "call_audio").apply { mkdirs() }
        currentFile = File(dir, "call_${System.currentTimeMillis()}.m4a")
        return try {
            recorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(16000)
                setAudioEncodingBitRate(64000)
                setOutputFile(currentFile!!.absolutePath)
                prepare()
                start()
            }
            true
        } catch (_: Exception) {
            recorder?.release(); recorder = null
            currentFile?.delete(); currentFile = null
            false
        }
    }

    fun stop(): File? {
        val file = currentFile
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        currentFile = null
        return file?.takeIf { it.exists() && it.length() > 1000L }
    }
}
