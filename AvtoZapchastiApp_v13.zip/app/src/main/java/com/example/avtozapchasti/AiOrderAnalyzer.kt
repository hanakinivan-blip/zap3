package com.example.avtozapchasti

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object AiOrderAnalyzer {
    private const val PREFS = "ai_settings"
    private const val KEY_API = "api_key"
    private const val KEY_WEB = "web_search"
    private const val ENDPOINT = "https://api.openai.com/v1/responses"
    private val executor = Executors.newCachedThreadPool()

    data class Result(val rows: List<OrderRow>, val raw: String = "")

    fun hasKey(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_API, "").orEmpty().isNotBlank()
    fun getKey(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_API, "").orEmpty()
    fun setKey(context: Context, key: String) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_API, key.trim()).apply()
    fun webSearchEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_WEB, true)
    fun setWebSearch(context: Context, enabled: Boolean) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_WEB, enabled).apply()

    fun analyzeAsync(context: Context, transcript: String, callback: (Result?, String?) -> Unit) {
        val key = getKey(context)
        if (key.isBlank()) { callback(null, "AI не настроен: добавьте API-ключ в настройках AI."); return }
        executor.execute {
            try {
                val result = request(context, key, transcript)
                android.os.Handler(android.os.Looper.getMainLooper()).post { callback(result, null) }
            } catch (e: Exception) {
                android.os.Handler(android.os.Looper.getMainLooper()).post { callback(null, e.message ?: "Ошибка AI") }
            }
        }
    }

    fun requestSync(context: Context, transcript: String): Result {
        val key = getKey(context)
        if (key.isBlank()) throw IllegalStateException("OpenAI API-ключ не задан")
        return request(context, key, transcript)
    }

    private fun request(context: Context, key: String, transcript: String): Result {
        val system = """
Ты анализируешь русскую телефонную заявку на автозапчасти. Распознанная речь может содержать сильные ошибки ASR, пропуски, перестановки слов и фонетические искажения. Восстанавливай смысл по всему разговору, а не по одной фразе.

Верни ТОЛЬКО JSON без markdown:
{"items":[{"model":"","detail":"","manufacturer":"","color":"","quantity":1}]}

Правила:
- Количество по умолчанию 1. Комплект передних крыльев разделяй на КПЛ и КПП.
- Модели: Датсун/Дадсун/Datsun -> 95; Ларгус/Largus/ларгу -> Largus; Веста -> Vesta; Веста седан -> Vesta; Урбан ПТФ -> Урбан ПТФ; 2113/2114/2115 -> 2114 и производитель ВАЗ; Калина 118 -> 118; X-Ray; 720/4-й -> 724 без производителя 4-й.
- Детали: ДПЛ, ДПП, ДЗЛ, ДЗП, КПЛ, КПП, Решётка нижняя, Капот, Лючок бензобака, Петля капота, Дверь задка, Дверь задка левая глухая, ПТФ. Сохраняй «без поворотника», «с поворотником», «дешёвый» в поле detail, если они сказаны.
- Производители: Тайвань, Китай, ВАЗ, Челны, ABS, NG, Sport. Если не сказан -> пустая строка.
- ABS также означает пластик; в поле detail ABS не писать. Если ABS и Тайвань -> manufacturer = "ABS, Тайвань".
- Завод/заводской -> ВАЗ.
- Цвета: Снежная королева 690, Млечка 606, Ледяной 413, Техно 618, Белое облако 240, Плутон 608, Рислинг 610, Космос 665, Баклажан 107, Золото инков 347, Боровница 451, Портвейн 192, Кварц 630, Ницца 328, Пантера 672, Борнео 633, Кориандр 790, Платина 691, Одиссей 497, Булат 619, Ледниковый 221, Мускари 426, Персей 429, Калифорнийский мак 190, Черника 482, Чёрная жемчужина 676, B66, 693. «снег», «снежка» -> Снежная королева 690.
- Если модель, деталь, производитель или цвет искажены распознаванием, используй контекст разговора и, при включённом web search, проверяй автомобильные каталоги и сайты производителей/магазинов. Не выдумывай совпадение без достаточных оснований.
- Если значение нельзя уверенно определить, ОБЯЗАТЕЛЬНО верни позицию с "???" именно в неизвестном поле. Не удаляй такую позицию и продолжай разбирать остальные позиции заявки.
- Если неизвестна сама деталь, верни detail = "???", но сохрани известные модель, производителя, цвет и количество.
- Возвращай позиции заявки, даже если одна из них частично неясна. Не останавливай разбор из-за одной ошибки ASR.
""".trimIndent()
        val prompt = system + "\n\nРАСШИФРОВКА РАЗГОВОРА:\n" + transcript.takeLast(24000)
        val body = JSONObject().apply {
            put("model", "gpt-5")
            put("input", prompt)
            put("store", false)
            if (webSearchEnabled(context)) put("tools", JSONArray().put(JSONObject().put("type", "web_search")))
        }
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000
            doOutput = true; setRequestProperty("Authorization", "Bearer $key"); setRequestProperty("Content-Type", "application/json")
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val responseText = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
        if (code !in 200..299) throw IllegalStateException("AI HTTP $code: ${responseText.take(500)}")
        val response = JSONObject(responseText)
        val outputText = response.optString("output_text").takeIf { it.isNotBlank() } ?: extractOutputText(response)
        val json = extractJson(outputText)
        val arr = json.optJSONArray("items") ?: JSONArray()
        val rows = mutableListOf<OrderRow>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val detail = o.optString("detail").trim()
            if (detail.isBlank()) continue
            rows += OrderRow(o.optString("model").trim(), detail, o.optString("manufacturer").trim(), o.optString("color").trim(), o.optInt("quantity", 1).coerceAtLeast(1))
        }
        return Result(rows.distinctBy { "${it.model}|${it.detail}|${it.manufacturer}|${it.color}|${it.quantity}" }, outputText)
    }

    private fun extractOutputText(response: JSONObject): String {
        val output = response.optJSONArray("output") ?: return ""
        val b = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                val t = c.optString("text")
                if (t.isNotBlank()) b.append(t)
            }
        }
        return b.toString()
    }

    private fun extractJson(text: String): JSONObject {
        val cleaned = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val start = cleaned.indexOf('{'); val end = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) throw IllegalStateException("AI вернул не JSON")
        return JSONObject(cleaned.substring(start, end + 1))
    }
}
