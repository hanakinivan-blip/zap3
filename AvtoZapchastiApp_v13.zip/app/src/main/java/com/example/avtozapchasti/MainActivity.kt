package com.example.avtozapchasti

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("orders", MODE_PRIVATE) }
    private val rows = mutableListOf<OrderRow>()
    private lateinit var container: LinearLayout
    private lateinit var status: TextView
    private var speechRecognizer: SpeechRecognizer? = null
    private val recordRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        container = findViewById(R.id.tablesContainer)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.conversationButton).setOnClickListener {
            startActivity(Intent(this@MainActivity, ConversationActivity::class.java))
        }
        findViewById<Button>(R.id.voiceButton).setOnClickListener { startVoiceFlow() }
        findViewById<Button>(R.id.manualButton).setOnClickListener { showEditor(null) }
        findViewById<Button>(R.id.newButton).setOnClickListener { newOrder() }
        findViewById<Button>(R.id.exportButton).setOnClickListener { exportCsv() }
        findViewById<Button>(R.id.pdfButton).setOnClickListener { saveThreePdfs() }
        findViewById<Button>(R.id.aiSettingsButton).setOnClickListener { showAiSettings() }
        styleButtons()

        load()
        render()
    }

    private fun styleButtons() {
        val ids = intArrayOf(
            R.id.newButton, R.id.voiceButton, R.id.conversationButton, R.id.manualButton,
            R.id.exportButton, R.id.pdfButton, R.id.aiSettingsButton
        )
        ids.forEach { id ->
            findViewById<Button>(id).apply {
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 28f
                    setColor(Color.rgb(35, 35, 35))
                    setStroke(1, Color.rgb(80, 80, 80))
                }
                minHeight = 52
                elevation = 3f
            }
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }

    private fun newOrder() {
        rows.clear()
        save()
        render()
        Toast.makeText(this@MainActivity, "Новая заявка", Toast.LENGTH_SHORT).show()
    }

    private fun startVoiceFlow() {
        if (!SpeechRecognizer.isRecognitionAvailable(this@MainActivity)) {
            Toast.makeText(this@MainActivity, "Распознавание речи недоступно на этом устройстве", Toast.LENGTH_LONG).show()
            return
        }

        if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), recordRequest)
            return
        }

        val input = EditText(this@MainActivity).apply {
            hint = "Распознанный текст"
            minLines = 5
            gravity = Gravity.TOP
        }

        val box = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 0)
        }

        val start = Button(this@MainActivity).apply {
            text = "🎙 Начать диктовку"
        }

        box.addView(start)
        box.addView(input, LinearLayout.LayoutParams(-1, -2))

        val dialog = AlertDialog.Builder(this@MainActivity)
            .setTitle("Голосовая заявка")
            .setView(box)
            .setPositiveButton("Добавить позиции", null)
            .setNegativeButton("Закрыть", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val transcript = input.text.toString().trim()
                if (transcript.isBlank()) {
                    Toast.makeText(this@MainActivity, "Сначала надиктуйте заявку", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (AiProviderManager.hasAnyKey(this@MainActivity)) {
                    status.text = "🤖 AI анализирует заявку…"
                    AiProviderManager.analyzeAsync(this@MainActivity, transcript) { result ->
                        if (result.rows.isEmpty()) {
                            val parsed = OrderParser.parse(transcript)
                            if (parsed.isEmpty()) {
                                Toast.makeText(this@MainActivity, "Позиции не найдены. Проверьте расшифровку или добавьте вручную.", Toast.LENGTH_SHORT).show()
                            } else {
                                rows.addAll(parsed); save(); render(); dialog.dismiss()
                            }
                        } else {
                            rows.addAll(result.rows); save(); render(); dialog.dismiss()
                            status.text = "${result.source}: позиций ${result.rows.size}"
                        }
                    }
                } else {
                    val parsed = OrderParser.parse(transcript)
                    if (parsed.isEmpty()) Toast.makeText(this@MainActivity, "Позиции не найдены. Настройте AI или проверьте расшифровку.", Toast.LENGTH_SHORT).show()
                    else { rows.addAll(parsed); save(); render(); dialog.dismiss() }
                }
            }
        }
        start.setOnClickListener { recognizeInto(input) }
        dialog.show()
    }

    private fun recognizeInto(target: EditText) {
        speechRecognizer?.destroy()
        speechRecognizer = if (android.os.Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this@MainActivity)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this@MainActivity)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                status.text = "Слушаю… Нажмите кнопку диктовки только когда готовы говорить."
            }

            override fun onBeginningOfSpeech() {
                status.text = "Речь распознаётся…"
            }

            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit

            override fun onEndOfSpeech() {
                status.text = "Распознавание завершено"
            }

            override fun onError(error: Int) {
                status.text = "Ошибка распознавания: $error"
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                target.setText(text)
                target.setSelection(target.text.length)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) {
                    target.setText(text)
                    target.setSelection(target.text.length)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        speechRecognizer?.startListening(intent)
    }

    private fun showEditor(index: Int?) {
        val old = index?.let { rows[it] }

        val layout = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(25, 4, 25, 0)
        }

        val labels = listOf("Модель", "Деталь", "Производитель", "Цвет", "Количество")
        val fields = labels.map { hint ->
            EditText(this@MainActivity).apply {
                this.hint = hint
                setSingleLine(false)
            }
        }

        old?.let { row ->
            fields[0].setText(row.model)
            fields[1].setText(row.detail)
            fields[2].setText(row.manufacturer)
            fields[3].setText(row.color)
            fields[4].setText(row.quantity.toString())
        } ?: fields[4].setText("1")

        fields.forEach { field ->
            layout.addView(field, LinearLayout.LayoutParams(-1, -2))
        }

        val title = if (old == null) "Новая позиция" else "Редактирование"

        AlertDialog.Builder(this@MainActivity)
            .setTitle(title)
            .setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                val row = OrderRow(
                    model = fields[0].text.toString().trim(),
                    detail = fields[1].text.toString().trim(),
                    manufacturer = fields[2].text.toString().trim(),
                    color = fields[3].text.toString().trim(),
                    quantity = fields[4].text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1,
                    done = old?.done ?: false
                )

                if (index == null) rows.add(row) else rows[index] = row
                save()
                render()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun render() {
        val sorted = OrderParser.sortRows(rows)
        rows.clear()
        rows.addAll(sorted)

        container.removeAllViews()

        for (section in Section.values()) {
            val titleView = TextView(this@MainActivity).apply {
                text = section.title
                textSize = 19f
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                setPadding(4, 20, 4, 8)
            }
            container.addView(titleView)

            val sectionRows = rows.filter { OrderParser.section(it) == section }

            if (sectionRows.isEmpty()) {
                val emptyView = TextView(this@MainActivity).apply {
                    text = "Нет позиций"
                    setPadding(8, 6, 8, 12)
                    setTextColor(0xFF777777.toInt())
                }
                container.addView(emptyView)
            } else {
                sectionRows.forEach { row ->
                    container.addView(rowView(row))
                }
            }
        }

        status.text = "Позиций: ${rows.size}"
    }

    private fun rowView(row: OrderRow): View {
        val idx = rows.indexOf(row)

        val outer = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        val top = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val check = CheckBox(this@MainActivity).apply {
            isChecked = row.done
        }

        check.setOnCheckedChangeListener { _, checked ->
            row.done = checked
            save()
            render()
        }

        val rowText = TextView(this@MainActivity).apply {
            text = "${row.model} • ${row.detail}\n${row.manufacturer.ifBlank { "—" }} • ${row.color.ifBlank { "—" }} • Кол-во: ${row.quantity}"
            textSize = 15f
            setPadding(4, 0, 4, 0)
            setTextColor(if (row.done) 0xFF999999.toInt() else 0xFF111111.toInt())
            if (row.done) {
                paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            }
        }

        top.addView(check, LinearLayout.LayoutParams(48, -2))
        top.addView(rowText, LinearLayout.LayoutParams(0, -2, 1f))

        val edit = Button(this@MainActivity).apply {
            text = "✎"
            setOnClickListener { showEditor(idx) }
        }

        val del = Button(this@MainActivity).apply {
            text = "🗑"
            setOnClickListener {
                rows.remove(row)
                save()
                render()
            }
        }

        top.addView(edit)
        top.addView(del)
        outer.addView(top)

        return outer
    }

    private fun save() {
        val array = JSONArray()
        rows.forEach { row ->
            array.put(JSONObject().apply {
                put("model", row.model)
                put("detail", row.detail)
                put("manufacturer", row.manufacturer)
                put("color", row.color)
                put("quantity", row.quantity)
                put("done", row.done)
            })
        }
        prefs.edit().putString("rows", array.toString()).apply()
    }

    private fun load() {
        rows.clear()
        val raw = prefs.getString("rows", null) ?: return

        runCatching {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                rows.add(
                    OrderRow(
                        model = obj.optString("model"),
                        detail = obj.optString("detail"),
                        manufacturer = obj.optString("manufacturer"),
                        color = obj.optString("color"),
                        quantity = obj.optInt("quantity", 1),
                        done = obj.optBoolean("done")
                    )
                )
            }
        }
    }

    private fun exportCsv() {
        val builder = StringBuilder("Модель;Деталь;Производитель;Цвет;Количество\n")

        rows.forEach { row ->
            builder.append(csv(row.model))
                .append(';')
                .append(csv(row.detail))
                .append(';')
                .append(csv(row.manufacturer))
                .append(';')
                .append(csv(row.color))
                .append(';')
                .append(row.quantity)
                .append('\n')
        }

        val file = File(
            getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
            "avtozapchasti_${System.currentTimeMillis()}.csv"
        )

        file.parentFile?.mkdirs()
        file.writeText(builder.toString(), Charsets.UTF_8)
        Toast.makeText(this@MainActivity, "CSV сохранён: ${file.name}", Toast.LENGTH_LONG).show()
    }

    private fun csv(value: String): String {
        return "\"" + value.replace("\"", "\"\"") + "\""
    }

    private fun saveThreePdfs() {
        if (rows.isEmpty()) {
            Toast.makeText(this@MainActivity, "Сначала сформируйте заявку", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            val base = FileStore.baseName()
            val paths = FileStore.saveThreePdfs(this@MainActivity, rows)
            val json = JSONArray().apply {
                rows.forEach { r ->
                    put(JSONObject().apply {
                        put("model", r.model)
                        put("detail", r.detail)
                        put("manufacturer", r.manufacturer)
                        put("color", r.color)
                        put("quantity", r.quantity)
                        put("done", r.done)
                    })
                }
            }.toString(2)
            FileStore.saveJson(this@MainActivity, json, base)
            Toast.makeText(
                this@MainActivity,
                "Созданы 3 PDF в Documents/AvtoZapchasti",
                Toast.LENGTH_LONG
            ).show()
        }.onFailure {
            Toast.makeText(this@MainActivity, "Ошибка PDF: ${it.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showAiSettings() {
        val openAi = EditText(this@MainActivity).apply {
            hint = "OpenAI API key"
            setSingleLine(true)
            setText(AiProviderManager.getOpenAiKey(this@MainActivity))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val gemini = EditText(this@MainActivity).apply {
            hint = "Gemini API key"
            setSingleLine(true)
            setText(AiProviderManager.getGeminiKey(this@MainActivity))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val web = CheckBox(this@MainActivity).apply {
            text = "Разрешить AI искать информацию в интернете"
            setTextColor(Color.WHITE)
            isChecked = AiProviderManager.webSearchEnabled(this@MainActivity)
        }
        val box = LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 0, 24, 0)
        }
        box.addView(openAi); box.addView(gemini); box.addView(web)
        AlertDialog.Builder(this@MainActivity)
            .setTitle("AI")
            .setMessage("При недоступности одного провайдера приложение автоматически попробует другой, затем локальный анализ.")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                AiProviderManager.setOpenAiKey(this, openAi.text.toString())
                AiProviderManager.setGeminiKey(this, gemini.text.toString())
                AiProviderManager.setWebSearch(this, web.isChecked)
                Toast.makeText(this, "Настройки AI сохранены", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == recordRequest &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            startVoiceFlow()
        } else if (requestCode == recordRequest) {
            Toast.makeText(
                this@MainActivity,
                "Нужен доступ к микрофону для диктовки",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
