package com.example.avtozapchasti

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small on-device memory of manually corrected positions. */
object LearnedStore {
    private const val PREFS = "learned_orders"
    private const val KEY = "rows"

    fun add(context: Context, row: OrderRow) {
        if (row.detail.isBlank() || row.detail == "???") return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        val key = key(row)
        for (i in 0 until arr.length()) if (key(arr.optJSONObject(i)) == key) return
        arr.put(JSONObject().apply {
            put("model", row.model); put("detail", row.detail)
            put("manufacturer", row.manufacturer); put("color", row.color)
            put("quantity", row.quantity)
        })
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun all(context: Context): List<OrderRow> {
        val arr = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { o ->
                OrderRow(o.optString("model"), o.optString("detail"), o.optString("manufacturer"), o.optString("color"), o.optInt("quantity", 1).coerceAtLeast(1))
            }
        }
    }

    fun clear(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()

    private fun key(r: OrderRow) = listOf(r.model, r.detail, r.manufacturer, r.color).joinToString("|").lowercase()
    private fun key(o: JSONObject?) = if (o == null) "" else listOf(o.optString("model"), o.optString("detail"), o.optString("manufacturer"), o.optString("color")).joinToString("|").lowercase()
}
