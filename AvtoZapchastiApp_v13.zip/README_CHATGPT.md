# AvtoZapchasti — ChatGPT v11

Вариант с OpenAI для онлайн-расшифровки, AI-разбора и Web Search.
- GPT-4o Transcribe для аудио
- Responses API для анализа заявки
- Web Search для проверки автомобильных терминов
- API-ключ хранится локально на телефоне

Доступность OpenAI API зависит от страны/территории.
