# AI + online speech version

- Local Android speech recognition remains available for live feedback.
- When a call session is stopped, the microphone recording can be uploaded to OpenAI Speech-to-Text (`gpt-4o-transcribe`) for a second, higher-quality transcript.
- The final transcript is then passed to the AI order analyzer.
- Optional web search can be used by the Responses API to verify unknown automotive terms and build a reusable catalog.
- API key is stored locally in app preferences and is not bundled into the APK.
- For option A, use speakerphone so the microphone can hear the customer.
