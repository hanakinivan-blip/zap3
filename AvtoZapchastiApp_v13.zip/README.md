# AvtoZapchastiApp

Android app for turning Russian phone conversations into auto-parts orders.

## v8 changes
- Standard Android speech recognizer is preferred for better Russian automotive vocabulary recognition; local parser remains offline.
- Parser accepts fragmented speech, common Samsung ASR distortions, model aliases, part aliases, colors, manufacturers and quantities.
- A stop with no parsed rows now distinguishes "no speech" from "speech heard but part not identified".
- Three order sections: METAL, PLASTIC, UNPAINTED.
- Three PDF exports are saved together under Documents/AvtoZapchasti.

For phone-call mode use speakerphone so the microphone can hear the other party.
