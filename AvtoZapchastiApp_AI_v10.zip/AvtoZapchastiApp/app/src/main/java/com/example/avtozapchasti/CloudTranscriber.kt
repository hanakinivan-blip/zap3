package com.example.avtozapchasti

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.Executors

object CloudTranscriber {
    private const val PREFS = "ai_settings"
    private const val KEY_CLOUD = "cloud_transcription"
    private const val ENDPOINT = "https://api.openai.com/v1/audio/transcriptions"
    private val executor = Executors.newCachedThreadPool()

    fun enabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_CLOUD, true)
    fun setEnabled(context: Context, value: Boolean) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_CLOUD, value).apply()

    fun transcribeAsync(context: Context, audioFile: File, callback: (String?, String?) -> Unit) {
        val key = AiOrderAnalyzer.getKey(context)
        if (key.isBlank()) { callback(null, "Добавьте API-ключ OpenAI в настройках AI"); return }
        executor.execute {
            try {
                val text = request(key, audioFile)
                Handler(Looper.getMainLooper()).post { callback(text, null) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { callback(null, e.message ?: "Ошибка онлайн-расшифровки") }
            }
        }
    }

    private fun request(key: String, file: File): String {
        val boundary = "----AvtoZapchasti${UUID.randomUUID()}"
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        conn.outputStream.use { out ->
            writeField(out, boundary, "model", "gpt-4o-transcribe")
            writeField(out, boundary, "language", "ru")
            writeField(out, boundary, "temperature", "0")
            writeField(out, boundary, "prompt", "Автозапчасти: Веста, Ларгус, Датсун, Дадсун, Datsun, X-Ray, Калина, 2114, 724. Детали: переднее левое крыло, переднее правое крыло, двери, дверь задка, капот, лючок бензобака, петля капота, решётка нижняя, ПТФ. Производители: Тайвань, Китай, ВАЗ, Челны, ABS, NG, Sport. Цвета LADA/VАЗ и их коды.")
            val name = file.name
            out.write("--$boundary\r\n".toByteArray())
            out.write("Content-Disposition: form-data; name=\"file\"; filename=\"$name\"\r\n".toByteArray())
            out.write("Content-Type: audio/mp4\r\n\r\n".toByteArray())
            FileInputStream(file).use { it.copyTo(out) }
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw IllegalStateException("Онлайн-распознавание HTTP $code: ${body.take(500)}")
        return JSONObject(body).optString("text").trim()
    }

    private fun writeField(out: OutputStream, boundary: String, name: String, value: String) {
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
        out.write(value.toByteArray(Charsets.UTF_8))
        out.write("\r\n".toByteArray())
    }
}
