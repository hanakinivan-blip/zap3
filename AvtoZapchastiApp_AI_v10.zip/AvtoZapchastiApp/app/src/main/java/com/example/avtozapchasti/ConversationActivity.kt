package com.example.avtozapchasti

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.util.Locale

class ConversationActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var orderContainer: LinearLayout
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private val handler = Handler(Looper.getMainLooper())
    private val requestMic = 3001
    private val transcriptLines = mutableListOf<String>()
    private val rows = mutableListOf<OrderRow>()
    private var aiPending = false
    private var aiLastTranscript = ""
    private val aiRunnable = Runnable { runAiAnalysis(false) }
    private var audioRecorder: CallAudioRecorder? = null
    private var cloudTranscriptionPending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversation)
        status = findViewById(R.id.status)
        transcript = findViewById(R.id.transcript)
        orderContainer = findViewById(R.id.orderContainer)

        findViewById<Button>(R.id.startButton).setOnClickListener { startSession() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopSession() }
        findViewById<Button>(R.id.clearButton).setOnClickListener { transcriptLines.clear(); rows.clear(); renderAll() }
        findViewById<Button>(R.id.orderButton).setOnClickListener { buildOrder() }
                findViewById<Button>(R.id.aiButton).setOnClickListener { runAiAnalysis(true) }
        findViewById<Button>(R.id.aiSettingsButton).setOnClickListener { showAiSettings() }
        findViewById<Button>(R.id.cloudButton).setOnClickListener { runCloudTranscription() }
        styleButtons()

        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) audio.isSpeakerphoneOn = true
        status.text = when {
            Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this) -> "Готово. Офлайн-распознавание доступно. Включите громкую связь и нажмите «Начать»."
            SpeechRecognizer.isRecognitionAvailable(this) -> "Готово. Встроенное распознавание доступно, но офлайн-модель не установлена. Для автономной работы установите русский офлайн-язык в службе распознавания Samsung/Google."
            else -> "На телефоне нет службы распознавания речи."
        }
    }

    private fun styleButtons() {
        val ids = intArrayOf(R.id.startButton, R.id.stopButton, R.id.clearButton, R.id.orderButton, R.id.savePdfButton, R.id.aiButton, R.id.aiSettingsButton, R.id.cloudButton)
        ids.forEach { id ->
            findViewById<Button>(id).apply {
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 28f
                    setColor(Color.rgb(35, 35, 35))
                    setStroke(1, Color.rgb(80, 80, 80))
                }
                minHeight = 52
                elevation = 3f
            }
        }
    }

    private fun startSession() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestMic)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Распознавание речи недоступно"
            return
        }
        listening = true
        startService(Intent(this, CallAwareForegroundService::class.java))
        audioRecorder = CallAudioRecorder(cacheDir)
        val recordingStarted = audioRecorder?.start() == true
        if (!recordingStarted) status.text = "⚠ Не удалось начать запись для онлайн-расшифровки; локальное распознавание продолжится."
        status.text = "🎙 Слушаю звонок…"
        listenOnce()
    }

    private fun listenOnce() {
        if (!listening) return
        recognizer?.destroy()
        // Prefer the standard Android recognizer: on Samsung it can use the
        // installed network/cloud language model, which is often substantially
        // more accurate for automotive terms than the small offline model.
        // The parser itself remains fully local and does not require internet.
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "🎙 Слушаю…" }
            override fun onBeginningOfSpeech() { status.text = "Речь распознаётся…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                if (listening) handler.postDelayed({ listenOnce() }, 400)
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (text.isNotBlank()) addTranscript(text)
                if (listening) handler.postDelayed({ listenOnce() }, 120)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (text.isNotBlank()) status.text = "🎙 $text"
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(intent)
    }

    private fun addTranscript(text: String) {
        if (text.isBlank()) return
        if (transcriptLines.lastOrNull()?.equals(text, ignoreCase = true) != true) transcriptLines += text
        transcript.text = transcriptLines.joinToString("\n\n")
        buildOrder()
        scheduleAiAnalysis()
    }

    private fun scheduleAiAnalysis() {
        if (!AiOrderAnalyzer.hasKey(this)) return
        val full = transcriptLines.joinToString(" ").trim()
        if (full.length < 4 || full == aiLastTranscript) return
        handler.removeCallbacks(aiRunnable)
        handler.postDelayed(aiRunnable, 1200)
    }

    private fun runAiAnalysis(manual: Boolean) {
        val full = transcriptLines.joinToString(" ").trim()
        if (full.isBlank()) { if (manual) Toast.makeText(this, "Сначала нужна расшифровка", Toast.LENGTH_SHORT).show(); return }
        if (!AiOrderAnalyzer.hasKey(this)) { if (manual) showAiSettings(); else status.text = "AI не настроен — работает локальный анализ"; return }
        if (aiPending) return
        aiPending = true; aiLastTranscript = full
        status.text = "🤖 AI анализирует заявку…"
        AiOrderAnalyzer.analyzeAsync(this, full) { result, error ->
            aiPending = false
            if (error != null) { status.text = "AI: $error"; if (manual) Toast.makeText(this, error, Toast.LENGTH_LONG).show(); return@analyzeAsync }
            val aiRows = result?.rows.orEmpty()
            if (aiRows.isNotEmpty()) {
                rows.clear(); rows.addAll(aiRows); renderOrder(); status.text = "🤖 AI: позиций ${rows.size}"
            } else status.text = "🤖 AI: позиций пока не найдено"
        }
    }

    private fun runCloudTranscription() {
        val file = audioRecorder?.currentFile
        if (file != null) { Toast.makeText(this, "Сначала нажмите Стоп", Toast.LENGTH_SHORT).show(); return }
        Toast.makeText(this, "Онлайн-расшифровка выполняется автоматически после остановки записи", Toast.LENGTH_LONG).show()
    }

    private fun showAiSettings() {
        val key = EditText(this).apply { hint = "sk-..."; setSingleLine(true); setText(AiOrderAnalyzer.getKey(this@ConversationActivity)); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val web = CheckBox(this).apply { text = "Разрешить AI искать информацию в интернете"; setTextColor(Color.WHITE); isChecked = AiOrderAnalyzer.webSearchEnabled(this@ConversationActivity) }
        val cloud = CheckBox(this).apply { text = "После звонка делать онлайн-расшифровку аудио"; setTextColor(Color.WHITE); isChecked = CloudTranscriber.enabled(this@ConversationActivity) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 24, 0) }; box.addView(key); box.addView(web); box.addView(cloud)
        AlertDialog.Builder(this).setTitle("Настройка AI").setMessage("Нужен ваш API-ключ OpenAI. Ключ хранится локально на телефоне и не входит в APK.").setView(box).setPositiveButton("Сохранить") { _, _ -> AiOrderAnalyzer.setKey(this, key.text.toString()); AiOrderAnalyzer.setWebSearch(this, web.isChecked); CloudTranscriber.setEnabled(this, cloud.isChecked); Toast.makeText(this, "Настройки AI сохранены", Toast.LENGTH_SHORT).show() }.setNegativeButton("Отмена", null).show()
    }

    private fun stopSession() {
        listening = false
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        val recordedFile = audioRecorder?.stop()
        audioRecorder = null
        stopService(Intent(this, CallAwareForegroundService::class.java))
        if (recordedFile != null && AiOrderAnalyzer.hasKey(this) && CloudTranscriber.enabled(this)) {
            cloudTranscriptionPending = true
            status.text = "☁ Онлайн-расшифровка разговора…"
            CloudTranscriber.transcribeAsync(this, recordedFile) { text, error ->
                cloudTranscriptionPending = false
                recordedFile.delete()
                if (error != null) { status.text = "Онлайн-расшифровка: $error"; return@transcribeAsync }
                if (!text.isNullOrBlank()) {
                    addTranscript(text)
                    runAiAnalysis(true)
                } else {
                    status.text = "Онлайн-расшифровка не вернула текст."
                }
            }
        } else {
            status.text = if (rows.isEmpty()) {
                if (transcriptLines.isEmpty()) "Остановлено. Речь не была распознана."
                else "Речь распознана, но деталь не определена. Проверьте расшифровку или добавьте позицию вручную."
            } else "Остановлено. Позиций: ${rows.size}. Заявку можно редактировать и сохранить."
        }
    }

    private fun buildOrder() {
        val parsed = OrderParser.parse(transcriptLines.joinToString(" "))
        rows.clear()
        rows.addAll(parsed)
        renderOrder()
        status.text = if (rows.isEmpty()) "Позиции пока не найдены. Продолжайте разговор или проверьте расшифровку." else "Позиций: ${rows.size}"
    }

    private fun renderAll() {
        transcript.text = transcriptLines.joinToString("\n\n")
        renderOrder()
    }

    private fun renderOrder() {
        orderContainer.removeAllViews()
        val sorted = OrderParser.sortRows(rows)
        for (section in Section.values()) {
            val heading = TextView(this).apply { text = section.title; textSize = 17f; setPadding(0, 14, 0, 6) }
            orderContainer.addView(heading)
            sorted.filter { OrderParser.section(it) == section }.forEach { row -> orderContainer.addView(rowView(row)) }
        }
    }

    private fun rowView(row: OrderRow): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4, 4, 4, 4) }
        val text = TextView(this).apply { text = "${row.model} | ${row.detail} | ${row.manufacturer.ifBlank { "—" }} | ${row.color.ifBlank { "—" }} | ${row.quantity}"; textSize = 14f }
        val edit = Button(this).apply { setText("✎"); setOnClickListener { editRow(row) } }
        box.addView(text, LinearLayout.LayoutParams(0, -2, 1f)); box.addView(edit)
        return box
    }

    private fun editRow(row: OrderRow) {
        val fields = listOf("Модель", "Деталь", "Производитель", "Цвет", "Количество").map { EditText(this).apply { hint = it } }
        fields[0].setText(row.model); fields[1].setText(row.detail); fields[2].setText(row.manufacturer); fields[3].setText(row.color); fields[4].setText(row.quantity.toString())
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 24, 0) }; fields.forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("Редактирование позиции").setView(box).setPositiveButton("Сохранить") { _, _ ->
            row.model = fields[0].text.toString().trim(); row.detail = fields[1].text.toString().trim(); row.manufacturer = fields[2].text.toString().trim(); row.color = fields[3].text.toString().trim(); row.quantity = fields[4].text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1; renderOrder()
        }.setNegativeButton("Отмена", null).show()
    }

    private fun savePdf() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "Сначала сформируйте заявку", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            val base = FileStore.baseName()
            val paths = FileStore.saveThreePdfs(this, rows)
            val json = JSONArray().apply {
                rows.forEach { r ->
                    put(org.json.JSONObject().apply {
                        put("model", r.model)
                        put("detail", r.detail)
                        put("manufacturer", r.manufacturer)
                        put("color", r.color)
                        put("quantity", r.quantity)
                        put("done", r.done)
                    })
                }
            }.toString(2)
            FileStore.saveJson(this, json, base)
            Toast.makeText(this, "Созданы 3 PDF в Documents/AvtoZapchasti", Toast.LENGTH_LONG).show()
        }.onFailure {
            Toast.makeText(this, "Ошибка сохранения: ${it.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() { listening = false; recognizer?.destroy(); recognizer = null; audioRecorder?.stop()?.delete(); audioRecorder = null; handler.removeCallbacksAndMessages(null); super.onDestroy() }
}
