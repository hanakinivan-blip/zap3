package com.example.avtozapchasti

/**
 * Speech-to-order parser for Russian automotive phone orders.
 * It deliberately tolerates ASR mistakes, word order, inflections and separate phrases.
 */
object OrderParser {
    private val colors = linkedMapOf(
        "снежная королева" to "Снежная королева 690", "снежка" to "Снежная королева 690", "снежку" to "Снежная королева 690", "снег" to "Снежная королева 690", "снежн" to "Снежная королева 690",
        "млечка" to "Млечка 606", "млечный путь" to "Млечка 606", "млеч" to "Млечка 606",
        "ледяной" to "Ледяной 413", "ледяная" to "Ледяной 413", "ледян" to "Ледяной 413",
        "техно" to "Техно 618", "белое облако" to "Белое облако 240", "бел облак" to "Белое облако 240",
        "плутон" to "Плутон 608", "рислинг" to "Рислинг 610", "космос" to "Космос 665", "баклажан" to "Баклажан 107",
        "золото инков" to "Золото инков 347", "золотo инков" to "Золото инков 347", "золотынков" to "Золото инков 347", "золотой инков" to "Золото инков 347",
        "боровница" to "Боровница 451", "портвейн" to "Портвейн 192", "кварц" to "Кварц 630", "ницца" to "Ницца 328", "ница" to "Ницца 328",
        "пантера" to "Пантера 672", "борнео" to "Борнео 633", "барнео" to "Борнео 633", "кориандр" to "Кориандр 790", "платина" to "Платина 691",
        "одиссей" to "Одиссей 497", "булат" to "Булат 619", "ледниковый" to "Ледниковый 221", "мускари" to "Мускари 426", "персей" to "Персей 429",
        "калифорнийский мак" to "Калифорнийский мак 190", "черника" to "Черника 482", "чёрная жемчужина" to "Чёрная жемчужина 676", "черная жемчужина" to "Чёрная жемчужина 676",
        "b66" to "B66", "би шестьдесят шесть" to "B66",
        "690" to "Снежная королева 690", "606" to "Млечка 606", "413" to "Ледяной 413", "618" to "Техно 618", "240" to "Белое облако 240",
        "608" to "Плутон 608", "610" to "Рислинг 610", "665" to "Космос 665", "107" to "Баклажан 107", "347" to "Золото инков 347",
        "451" to "Боровница 451", "192" to "Портвейн 192", "630" to "Кварц 630", "328" to "Ницца 328", "672" to "Пантера 672", "633" to "Борнео 633",
        "790" to "Кориандр 790", "691" to "Платина 691", "497" to "Одиссей 497", "619" to "Булат 619", "221" to "Ледниковый 221",
        "426" to "Мускари 426", "429" to "Персей 429", "190" to "Калифорнийский мак 190", "482" to "Черника 482", "676" to "Чёрная жемчужина 676", "693" to "693"
    )

    private val numberWords = mapOf(
        "ноль" to 0, "один" to 1, "одна" to 1, "одно" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4,
        "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10,
        "одиннадцать" to 11, "двенадцать" to 12, "тринадцать" to 13, "четырнадцать" to 14, "пятнадцать" to 15,
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50
    )

    private data class Context(var model: String = "", var manufacturer: String = "", var color: String = "", var lastDetail: String = "", var lastQuantity: Int = 1)

    fun parse(text: String): List<OrderRow> {
        val low = normalizeSpeech(text)
        if (low.isBlank()) return emptyList()
        val context = Context(normalizeModel(low).orEmpty(), normalizeManufacturer(low), normalizeColor(low))
        val result = mutableListOf<OrderRow>()

        splitSpeech(low).forEach { chunk ->
            normalizeModel(chunk)?.let { context.model = it }
            normalizeManufacturer(chunk).takeIf { it.isNotBlank() }?.let { context.manufacturer = mergeManufacturer(context.manufacturer, it) }
            normalizeColor(chunk).takeIf { it.isNotBlank() }?.let { context.color = it }
            val details = detectDetails(chunk)
            if (details.isNotEmpty()) {
                if (isFenderSet(chunk)) {
                    val q = quantityForSet(chunk)
                    addUnique(result, row(context, "КПЛ", q)); addUnique(result, row(context, "КПП", q))
                    context.lastDetail = "КПП"; context.lastQuantity = q
                } else details.forEach { d ->
                    val q = quantityNearDetail(chunk, d, quantity(chunk, 1))
                    addUnique(result, row(context, d, q)); context.lastDetail = d; context.lastQuantity = q
                }
            } else {
                inheritedDetail(chunk, context.lastDetail)?.let { d ->
                    val q = quantity(chunk, context.lastQuantity)
                    addUnique(result, row(context, d, q)); context.lastDetail = d; context.lastQuantity = q
                }
            }
        }

        // Whole-transcript pass catches punctuation and fragments from the recognizer.
        if (isFenderSet(low)) {
            val q = quantityForSet(low); addUnique(result, row(context, "КПЛ", q)); addUnique(result, row(context, "КПП", q))
        } else detectDetails(low).forEach { d -> addUnique(result, row(context, d, quantityNearDetail(low, d, quantity(low, 1)))) }

        result.forEach { r ->
            if (r.model.isBlank()) r.model = context.model
            if (r.manufacturer.isBlank()) r.manufacturer = context.manufacturer
            if (r.color.isBlank()) r.color = context.color
        }
        return result.distinctBy { listOf(it.model, it.detail, it.manufacturer, it.color, it.quantity) }
    }

    private fun addUnique(list: MutableList<OrderRow>, item: OrderRow) {
        if (item.detail.isBlank()) return
        if (list.none { it.model == item.model && it.detail == item.detail && it.manufacturer == item.manufacturer && it.color == item.color && it.quantity == item.quantity }) list += item
    }
    private fun row(c: Context, d: String, q: Int) = OrderRow(c.model, d, c.manufacturer, c.color, q.coerceIn(1, 99))
    private fun clean(s: String) = s.lowercase().replace('ё','е').replace(Regex("[^\\p{L}\\p{N}]+"), " ").replace(Regex("\\s+"), " ").trim()
    private fun normalizeSpeech(s: String): String = clean(s)
        .replace("тайваньский", "тайвань").replace("тайваньская", "тайвань").replace("тайваньское", "тайвань").replace("тайваньские", "тайвань")
        .replace("тайван", "тайвань").replace("снежку", "снежка").replace("снежке", "снежка").replace("снежкой", "снежка")
        .replace("заводской", "завод").replace("заводское", "завод")
        // Common speech-recognition distortions seen on Russian Samsung devices.
        .replace(Regex("\\bларгу(с|за|су|са|сe|з)?\\b"), "largus")
        .replace(Regex("\\bларгусе\\b"), "largus")
        .replace(Regex("\\bларг\\b"), "largus")
        .replace(Regex("\\bдaтсун\\b"), "датсун")
        .replace(Regex("\\bдадсун\\b"), "датсун")
        .replace(Regex("\\bдесятый\\b"), "датсун")
        .replace(Regex("\\bдесятая\\b"), "датсун")

    private fun splitSpeech(s: String): List<String> = s.split(Regex("\\b(?:и еще|еще|потом|также|тоже|далее|следом)\\b"))
        .flatMap { it.split(Regex("[.!?;,]+")) }.map { it.trim() }.filter { it.isNotBlank() }

    private fun detectDetails(s: String): List<String> {
        val low = normalizeSpeech(s); val out = mutableListOf<String>()
        val hasLeft = hasAny(low, "лев", "лева")
        val hasRight = hasAny(low, "прав", "справа")
        if (hasAny(low, "крыл", "крыль")) {
            if (hasLeft) out += withSuffix("КПЛ", low)
            if (hasRight) out += withSuffix("КПП", low)
            if (!hasLeft && !hasRight && hasAny(low, "передн", "перед")) {
                // Do not guess a side; a front wing without a side is still a useful candidate.
                out += withSuffix("Крыло переднее", low)
            }
        }
        if (hasAny(low, "двер", "дверц")) {
            val rear = hasAny(low, "задн", "задка", "багажник")
            val front = hasAny(low, "передн", "перед")
            if (rear) { if (hasLeft) out += withSuffix("ДЗЛ", low); if (hasRight) out += withSuffix("ДЗП", low) }
            else if (front) { if (hasLeft) out += withSuffix("ДПЛ", low); if (hasRight) out += withSuffix("ДПП", low) }
            else if (hasLeft) out += withSuffix("Дверь левая", low)
            else if (hasRight) out += withSuffix("Дверь правая", low)
        }
        if (hasAny(low, "дверь задка левая глух", "двер задка лев глух", "дверь задка левая глухая")) out += "Дверь задка левая глухая"
        else if (hasAny(low, "дверь задка", "двер задка", "дверь багажника", "двер багажника")) out += "Дверь задка"
        if (hasAny(low, "решетк", "решеткa", "решотк")) {
            when { hasAny(low, "ниж") -> out += "Решётка нижняя"; hasAny(low, "верх") -> out += "Решётка верхняя"; else -> out += "Решётка" }
        }
        if (hasAny(low, "лючок", "лючек") && hasAny(low, "бенз", "бак")) out += "Лючок бензобака"
        if (hasAny(low, "петл") && hasAny(low, "капот")) out += "Петля капота" else if (hasAny(low, "капот")) out += "Капот"
        if (hasAny(low, "птф", "противотуман", "туманк")) out += "ПТФ"
        if (hasAny(low, "порог")) out += "Пороги"
        if (hasAny(low, "реснич")) out += "Реснички"
        if (hasAny(low, "крышк", "крышу") && hasAny(low, "багажник")) out += "Крышка багажника"
        return out.distinct()
    }

    private fun hasAny(s: String, vararg terms: String) = terms.any { s.contains(it) }
    private fun withSuffix(base: String, s: String): String {
        val suffix = when { hasAny(s, "без поворотник", "без поворота") -> "без поворотника"; hasAny(s, "с поворотник", "с поворотом") -> "с поворотником"; else -> "" }
        val cheap = if (hasAny(s, "дешев", "подешевле", "дешман")) "дешёвый" else ""
        val extras = listOf(suffix, cheap).filter { it.isNotBlank() }
        return if (extras.isEmpty()) base else "$base, ${extras.joinToString(", ") }"
    }
    private fun inheritedDetail(chunk: String, last: String): String? {
        if (last.isBlank()) return null
        val left = hasAny(chunk, "лев", "слева"); val right = hasAny(chunk, "прав", "справа")
        if (!left && !right) return null
        val suffix = when { hasAny(chunk, "без поворотник") -> ", без поворотника"; hasAny(chunk, "с поворотник") -> ", с поворотником"; else -> "" }
        val side = if (left) "лев" else "прав"
        return when {
            last.startsWith("КПЛ") || last.startsWith("КПП") -> (if (side == "лев") "КПЛ" else "КПП") + suffix
            last.startsWith("ДПЛ") || last.startsWith("ДПП") -> (if (side == "лев") "ДПЛ" else "ДПП") + suffix
            last.startsWith("ДЗЛ") || last.startsWith("ДЗП") -> (if (side == "лев") "ДЗЛ" else "ДЗП") + suffix
            else -> null
        }
    }

    private fun normalizeManufacturer(s: String): String {
        val low = normalizeSpeech(s); val found = mutableListOf<String>()
        if (Regex("\\babs\\b").containsMatchIn(low) || low.contains("абс")) found += "ABS"
        if (low.contains("тайвань")) found += "Тайвань"
        if (Regex("\\bng\\b").containsMatchIn(low) || low.contains("эн джи") || low.contains("н джи")) found += "NG"
        if (low.contains("завод") || low.contains("заводск")) found += "ВАЗ"
        if (Regex("\\bsport\\b").containsMatchIn(low) || low.contains("спорт")) found += "Sport"
        if (low.contains("китай")) found += "Китай"
        if (Regex("\\bваз\\b").containsMatchIn(low)) found += "ВАЗ"
        return found.distinct().joinToString(", ")
    }
    private fun mergeManufacturer(a: String, b: String) = (a.split(", ").filter { it.isNotBlank() } + b.split(", ").filter { it.isNotBlank() }).distinct().joinToString(", ")

    private fun normalizeModel(s: String): String? {
        val low = normalizeSpeech(s)
        if (Regex("\\b720\\b.*\\b4\\s*й\\b|\\b4\\s*й\\b.*\\b720\\b").containsMatchIn(low) || low.contains("четвертый 720")) return "724"
        if (Regex("\\b(датсун|datsun)\\b").containsMatchIn(low) || low.contains("дат сун")) return "95"
        if ((low.contains("2113") && low.contains("2114") && low.contains("2115")) || low.contains("ваз 2114")) return "2114"
        if (hasAny(low, "веста", "весту", "вестой")) return "Vesta"
        if (hasAny(low, "ларгус", "largus")) return "Largus"
        if (hasAny(low, "икс рей", "иксрей", "x ray", "xray", "x рей")) return "X-Ray"
        if (low.contains("калина") && low.contains("118")) return "118"
        if (low.contains("урбан") && hasAny(low, "птф", "противотуман")) return "Урбан ПТФ"
        Regex("\\b(08|09|14|15|18|19|23|70|80|90|91|92|118|704|724)\\b").find(low)?.groupValues?.get(1)?.let { return it }
        return null
    }
    private fun normalizeColor(s: String): String {
        val low = normalizeSpeech(s)
        for ((k,v) in colors.entries.sortedByDescending { it.key.length }) if (low.contains(k)) return v
        return if (hasAny(low, "неокраш", "без цвета", "не крашен", "не крашенн", "не окрашен")) "Неокрашенный" else ""
    }
    private fun quantity(s: String, fallback: Int): Int {
        val low = normalizeSpeech(s)
        Regex("\\b(\\d+)\\s*(шт|штук|штуки|штука)\\b").find(low)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(1,99) }
        for ((w,v) in numberWords) if (Regex("\\b${Regex.escape(w)}\\b").containsMatchIn(low)) return v
        Regex("\\b(\\d+)\\b").findAll(low).mapNotNull { it.groupValues[1].toIntOrNull() }.firstOrNull { it in 1..99 && !isColorCode(it) }?.let { return it }
        return fallback.coerceAtLeast(1)
    }
    private fun quantityForSet(s: String): Int {
        Regex("\\b(\\d+)\\s*комплект").find(s)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(1,99) }
        for ((word,value) in numberWords.entries.sortedByDescending { it.value }) if (Regex("комплект(?:а|ы)?\\s+$word\\b").containsMatchIn(s)) return value
        return if (s.contains("комплект")) 1 else quantity(s,1)
    }
    private fun isFenderSet(s: String) = hasAny(s,"комплект","комплекта","комплекты") && hasAny(s,"крыл","крыль") && hasAny(s,"перед","передн")
    private fun quantityNearDetail(s: String, detail: String, fallback: Int): Int {
        val needle = when { detail.startsWith("КП") -> "крыл"; detail.startsWith("ДП") || detail.startsWith("ДЗ") -> "двер"; else -> detail.lowercase().take(7) }
        val idx = s.indexOf(needle)
        if (idx >= 0) return quantity(s.substring(idx, minOf(s.length, idx+100)), fallback)
        return fallback.coerceAtLeast(1)
    }
    private fun isColorCode(n: Int) = n in setOf(107,190,192,221,240,328,347,413,426,429,451,482,497,606,608,610,618,619,630,633,665,672,676,690,691,790)

    fun section(row: OrderRow): Section {
        if (row.color.isBlank() || row.color.equals("Неокрашенный",true)) return Section.UNPAINTED
        if (row.manufacturer.contains("ABS",true)) return Section.PLASTIC
        val d=row.detail.lowercase()
        val metal=listOf("капот","кпл","кпп","дпл","дпп","дзл","дзп","крышка багажника","крыло","крылья").any { d.contains(it) }
        return if (metal) Section.METAL else Section.PLASTIC
    }
    fun sortRows(rows: List<OrderRow>): List<OrderRow> = rows.filter { section(it)==Section.UNPAINTED } + rows.filter { section(it)==Section.METAL } + rows.filter { section(it)==Section.PLASTIC && !it.manufacturer.contains("ABS",true) } + rows.filter { section(it)==Section.PLASTIC && it.manufacturer.contains("ABS",true) }
}
