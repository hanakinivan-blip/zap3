package com.example.avtozapchasti

/**
 * Conversational parser for Russian spare-parts orders.
 * It deliberately uses tolerant phrase matching because Android speech recognition
 * often changes word endings and word order.
 */
object OrderParser {
    private val colors = linkedMapOf(
        "снежная королева" to "Снежная королева 690", "снежку" to "Снежная королева 690", "снежка" to "Снежная королева 690", "снег" to "Снежная королева 690", "снежный" to "Снежная королева 690", "690" to "Снежная королева 690",
        "млечка" to "Млечка 606", "млечный путь" to "Млечка 606", "606" to "Млечка 606",
        "ледяной" to "Ледяной 413", "ледяная" to "Ледяной 413", "413" to "Ледяной 413",
        "техно" to "Техно 618", "618" to "Техно 618",
        "белое облако" to "Белое облако 240", "240" to "Белое облако 240",
        "плутон" to "Плутон 608", "608" to "Плутон 608",
        "рислинг" to "Рислинг 610", "610" to "Рислинг 610",
        "космос" to "Космос 665", "665" to "Космос 665",
        "баклажан" to "Баклажан 107", "107" to "Баклажан 107",
        "золото инков" to "Золото инков 347", "золотo инков" to "Золото инков 347", "золотынков" to "Золото инков 347", "золотой инков" to "Золото инков 347", "347" to "Золото инков 347",
        "боровница" to "Боровница 451", "451" to "Боровница 451",
        "портвейн" to "Портвейн 192", "192" to "Портвейн 192",
        "кварц" to "Кварц 630", "630" to "Кварц 630",
        "ницца" to "Ницца 328", "ница" to "Ницца 328", "328" to "Ницца 328",
        "пантера" to "Пантера 672", "672" to "Пантера 672",
        "борнео" to "Борнео 633", "барнео" to "Борнео 633", "633" to "Борнео 633",
        "кориандр" to "Кориандр 790", "790" to "Кориандр 790",
        "платина" to "Платина 691", "691" to "Платина 691",
        "одиссей" to "Одиссей 497", "497" to "Одиссей 497",
        "булат" to "Булат 619", "619" to "Булат 619",
        "ледниковый" to "Ледниковый 221", "221" to "Ледниковый 221",
        "мускари" to "Мускари 426", "426" to "Мускари 426",
        "персей" to "Персей 429", "429" to "Персей 429",
        "калифорнийский мак" to "Калифорнийский мак 190", "190" to "Калифорнийский мак 190",
        "черника" to "Черника 482", "482" to "Черника 482",
        "чёрная жемчужина" to "Чёрная жемчужина 676", "черная жемчужина" to "Чёрная жемчужина 676", "676" to "Чёрная жемчужина 676",
        "b66" to "B66", "би шестьдесят шесть" to "B66",
        "693" to "693"
    )

    private val ones = mapOf("один" to 1, "одна" to 1, "одно" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9)
    private val tens = mapOf("двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50, "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90)

    private data class Context(
        var model: String = "",
        var manufacturer: String = "",
        var color: String = "",
        var lastDetail: String = "",
        var lastQuantity: Int = 1
    )

    fun parse(text: String): List<OrderRow> {
        val low = normalizeSpeech(text)
        if (low.isBlank()) return emptyList()

        val context = Context(
            model = normalizeModel(low).orEmpty(),
            manufacturer = normalizeManufacturer(low),
            color = normalizeColor(low)
        )
        val result = mutableListOf<OrderRow>()

        // First pass: explicitly named details anywhere in the whole transcript.
        val details = detectDetails(low)
        if (details.isNotEmpty()) {
            val globalQty = quantity(low, 1)
            val isFrontFenderSet = (low.contains("комплект") || low.contains("комплекта") || low.contains("комплекты")) &&
                (low.contains("передн") && low.contains("крыл"))

            if (isFrontFenderSet) {
                val q = quantityAfterSet(low)
                result += row(context, "КПЛ", q)
                result += row(context, "КПП", q)
            } else {
                // If both left and right are explicitly present, create both.
                val sides = details.filter { it == "КПЛ" || it == "КПП" || it == "ДПЛ" || it == "ДПП" || it == "ДЗЛ" || it == "ДЗП" }
                if (sides.size >= 2 && sides.distinct().size >= 2) {
                    sides.distinct().forEach { d -> result += row(context, d, quantityNearDetail(low, d, globalQty)) }
                } else {
                    details.distinct().forEach { d -> result += row(context, d, quantityNearDetail(low, d, globalQty)) }
                }
            }
        }

        // Second pass: conversational fragments. This covers phrases like
        // "Веста", then "левое", then "два", then "Тайвань".
        val chunks = low.split(Regex("[\\n.!?;,]+|\\b(?:и ещё|еще|потом|также|тоже)\\b"))
            .map { it.trim(' ', ':', '-', '—') }.filter { it.isNotBlank() }
        for (chunk in chunks) {
            normalizeModel(chunk)?.let { context.model = it }
            normalizeManufacturer(chunk).takeIf { it.isNotBlank() }?.let { context.manufacturer = mergeManufacturer(context.manufacturer, it) }
            normalizeColor(chunk).takeIf { it.isNotBlank() }?.let { context.color = it }

            val detail = normalizeDetail(chunk)
            if (detail != null && result.none { it.detail == detail && it.model == context.model }) {
                val q = quantity(chunk, 1)
                result += row(context, detail, q)
                context.lastDetail = detail
                context.lastQuantity = q
            } else {
                val inherited = inheritedDetail(chunk, context.lastDetail)
                if (inherited != null) {
                    val q = quantity(chunk, context.lastQuantity)
                    result += row(context, inherited, q)
                    context.lastDetail = inherited
                    context.lastQuantity = q
                }
            }
        }

        // Fill missing context after the whole conversation has been processed.
        result.forEach { r ->
            if (r.model.isBlank()) r.model = context.model
            if (r.manufacturer.isBlank()) r.manufacturer = context.manufacturer
            if (r.color.isBlank()) r.color = context.color
        }
        return result.distinctBy { listOf(it.model, it.detail, it.manufacturer, it.color, it.quantity) }
    }

    private fun row(c: Context, detail: String, qty: Int): OrderRow =
        OrderRow(c.model, detail, c.manufacturer, c.color, qty.coerceIn(1, 99))

    private fun clean(s: String): String = s.replace('Ё', 'Е').replace('ё', 'е').trim()

    private fun normalizeSpeech(s: String): String = clean(s.lowercase())
        .replace("тайваньский", "тайвань")
        .replace("тайваньская", "тайвань")
        .replace("тайваньское", "тайвань")
        .replace("тайваньские", "тайвань")
        .replace("снежку", "снежка")
        .replace("снежке", "снежка")
        .replace("снежкой", "снежка")
        .replace("заводской", "завод")

    private fun detectDetails(s: String): List<String> {
        val low = normalizeSpeech(s)
        val out = mutableListOf<String>()
        if (frontSide(low, "лев")) out += "КПЛ"
        if (frontSide(low, "прав")) out += "КПП"
        if (rearSide(low, "лев")) out += "ДЗЛ"
        if (rearSide(low, "прав")) out += "ДЗП"
        if (frontDoor(low, "лев")) out += "ДПЛ"
        if (frontDoor(low, "прав")) out += "ДПП"
        if (out.isNotEmpty()) return out
        when {
            low.contains("передн") && low.contains("крыл") -> out += "Крылья передние"
            low.contains("дверь задка левая глухая") || low.contains("дверь задка левая глух") -> out += "Дверь задка левая глухая"
            low.contains("дверь задка") || low.contains("дверь багажника") -> out += "Дверь задка"
            low.contains("решетк") && low.contains("ниж") -> out += "Решётка нижняя"
            low.contains("решетк") && low.contains("верх") -> out += "Решётка верхняя"
            low.contains("решетк") -> out += "Решётка"
            low.contains("лючок") && (low.contains("бенз") || low.contains("бак")) -> out += "Лючок бензобака"
            low.contains("петл") && low.contains("капот") -> out += "Петля капота"
            low.contains("капот") -> out += "Капот"
            low.contains("порог") -> out += "Пороги"
            low.contains("реснич") -> out += "Реснички"
        }
        return out
    }

    private fun frontSide(s: String, side: String): Boolean {
        if (!s.contains("крыл")) return false
        if (!s.contains("передн") && !s.contains("перед")) return false
        return when (side) {
            "лев" -> Regex("\\b(лев|левая|левое|левый)\\b").containsMatchIn(s)
            else -> Regex("\\b(прав|правая|правое|правый)\\b").containsMatchIn(s)
        }
    }

    private fun frontDoor(s: String, side: String): Boolean {
        if (!s.contains("двер")) return false
        if (!s.contains("передн") && !s.contains("перед")) return false
        return when (side) {
            "лев" -> Regex("\\b(лев|левая|левое|левый)\\b").containsMatchIn(s)
            else -> Regex("\\b(прав|правая|правое|правый)\\b").containsMatchIn(s)
        }
    }

    private fun rearSide(s: String, side: String): Boolean {
        if (!s.contains("двер")) return false
        if (!s.contains("задн") && !s.contains("зад")) return false
        return when (side) {
            "лев" -> Regex("\\b(лев|левая|левое|левый)\\b").containsMatchIn(s)
            else -> Regex("\\b(прав|правая|правое|правый)\\b").containsMatchIn(s)
        }
    }

    private fun normalizeDetail(s: String): String? {
        val low = normalizeSpeech(s)
        return when {
            frontDoor(low, "лев") -> withSuffix("ДПЛ", low)
            frontDoor(low, "прав") -> withSuffix("ДПП", low)
            rearSide(low, "лев") -> withSuffix("ДЗЛ", low)
            rearSide(low, "прав") -> withSuffix("ДЗП", low)
            frontSide(low, "лев") -> withSuffix("КПЛ", low)
            frontSide(low, "прав") -> withSuffix("КПП", low)
            low.contains("передн") && low.contains("крыл") -> withSuffix("Крылья передние", low)
            low.contains("дверь задка левая глух") -> withSuffix("Дверь задка левая глухая", low)
            low.contains("дверь задка") || low.contains("дверь багажника") -> withSuffix("Дверь задка", low)
            low.contains("решетк") && low.contains("ниж") -> withSuffix("Решётка нижняя", low)
            low.contains("решетк") && low.contains("верх") -> withSuffix("Решётка верхняя", low)
            low.contains("решетк") -> withSuffix("Решётка", low)
            low.contains("лючок") && (low.contains("бенз") || low.contains("бак")) -> withSuffix("Лючок бензобака", low)
            low.contains("петл") && low.contains("капот") -> withSuffix("Петля капота", low)
            low.contains("капот") -> withSuffix("Капот", low)
            low.contains("порог") -> withSuffix("Пороги", low)
            low.contains("реснич") -> withSuffix("Реснички", low)
            else -> null
        }
    }

    private fun withSuffix(base: String, s: String): String {
        val parts = mutableListOf<String>()
        if (s.contains("без поворотник")) parts += "без поворотника"
        else if (s.contains("с поворотник")) parts += "с поворотником"
        if (s.contains("дешев")) parts += "дешёвый"
        return if (parts.isEmpty()) base else base + ", " + parts.joinToString(", ")
    }

    private fun inheritedDetail(chunk: String, last: String): String? {
        if (last.isBlank()) return null
        val left = Regex("\\b(лев|левая|левое|левый)\\b").containsMatchIn(chunk)
        val right = Regex("\\b(прав|правая|правое|правый)\\b").containsMatchIn(chunk)
        if (!left && !right) return null
        val suffix = if (chunk.contains("без поворотник")) ", без поворотника" else if (chunk.contains("с поворотник")) ", с поворотником" else ""
        val side = if (left) "лев" else "прав"
        return when {
            last.startsWith("КПЛ") || last.startsWith("КПП") -> (if (side == "лев") "КПЛ" else "КПП") + suffix
            last.startsWith("ДПЛ") || last.startsWith("ДПП") -> (if (side == "лев") "ДПЛ" else "ДПП") + suffix
            last.startsWith("ДЗЛ") || last.startsWith("ДЗП") -> (if (side == "лев") "ДЗЛ" else "ДЗП") + suffix
            else -> last
        }
    }

    private fun normalizeManufacturer(s: String): String {
        val found = mutableListOf<String>()
        if (Regex("\\babs\\b").containsMatchIn(s)) found += "ABS"
        if (s.contains("тайван")) found += "Тайвань"
        if (Regex("\\bng\\b").containsMatchIn(s)) found += "NG"
        if (s.contains("завод")) found += "ВАЗ"
        if (Regex("\\bsport\\b").containsMatchIn(s)) found += "Sport"
        if (s.contains("китай")) found += "Китай"
        return found.distinct().joinToString(", ")
    }

    private fun mergeManufacturer(a: String, b: String): String =
        (a.split(", ").filter { it.isNotBlank() } + b.split(", ").filter { it.isNotBlank() }).distinct().joinToString(", ")

    private fun normalizeModel(s: String): String? {
        val low = normalizeSpeech(s)
        if (Regex("\\b720\\b.*\\b4[- ]?й\\b|\\b4[- ]?й\\b.*\\b720\\b|четверт(ый|ая)\\s+ряд").containsMatchIn(low)) return "724"
        if (Regex("\\b(датсун|дадсун|datsun)\\b").containsMatchIn(low)) return "95"
        if (Regex("\\bvaz\\s*2113\\s*[, ]*2114\\s*[, ]*2115\\b").containsMatchIn(low) || (low.contains("2113") && low.contains("2114") && low.contains("2115"))) return "2114"
        if (low.contains("веста")) return "Vesta"
        if (low.contains("калина") && low.contains("118")) return "118"
        if (low.contains("урбан") && (low.contains("ptf") || low.contains("птф"))) return "Урбан ПТФ"
        if (low.contains("x-ray") || low.contains("x ray") || low.contains("xray") || low.contains("икс рей")) return "X-Ray"
        if (low.contains("largus") || low.contains("ларгус")) return "Largus"
        Regex("\\b(08|09|14|15|18|19|23|70|80|90|91|92|118|704|724)\\b").find(low)?.groupValues?.get(1)?.let { return it }
        return null
    }

    private fun normalizeColor(s: String): String {
        val low = normalizeSpeech(s)
        for ((k, v) in colors.entries.sortedByDescending { it.key.length }) {
            if (low.contains(k)) return v
        }
        return if (low.contains("неокраш") || low.contains("без цвета") || low.contains("не крашен") || low.contains("не крашенн")) "Неокрашенный" else ""
    }

    private fun quantity(s: String, fallback: Int): Int {
        val low = normalizeSpeech(s)
        Regex("\\b(\\d+)\\s*(шт|штук|штуки)\\b").find(low)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(1, 99) }
        Regex("\\b(\\d+)\\s*(комплект|комплекта|комплекты)\\b").find(low)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(1, 99) }
        for ((w, v) in ones) if (Regex("\\b${Regex.escape(w)}\\b").containsMatchIn(low)) return v
        for ((w, v) in tens) if (Regex("\\b${Regex.escape(w)}\\b").containsMatchIn(low)) return v
        Regex("\\b(\\d+)\\b").findAll(low).mapNotNull { it.groupValues[1].toIntOrNull() }.firstOrNull { it in 1..99 && !isColorCode(it) }?.let { return it }
        return if (low.contains("комплект")) fallback else 1
    }

    private fun quantityAfterSet(s: String): Int {
        val m = Regex("(комплект|комплекта|комплекты)(?:\\s+из)?\\s+(один|два|две|три|четыре|пять|\\d+)?").find(s)
        if (m != null) {
            val token = m.groupValues.getOrNull(2).orEmpty()
            if (token.isNotBlank()) return quantity(token, 1)
        }
        Regex("\\b(\\d+)\\s+комплект").find(s)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(1,99) }
        return 1
    }

    private fun quantityNearDetail(s: String, detail: String, fallback: Int): Int {
        val idx = s.indexOf(detail.lowercase())
        if (idx >= 0) {
            val window = s.substring(idx, minOf(s.length, idx + 80))
            return quantity(window, fallback)
        }
        return quantity(s, fallback)
    }

    private fun isColorCode(n: Int): Boolean = n in setOf(107,190,192,221,240,328,347,413,426,429,451,482,497,606,608,610,618,619,630,633,665,672,676,690,691,693,790)

    fun section(row: OrderRow): Section {
        if (row.color.isBlank() || row.color.equals("Неокрашенный", true)) return Section.UNPAINTED
        if (row.manufacturer.contains("ABS", true)) return Section.PLASTIC
        val d = row.detail.lowercase()
        val metal = listOf("капот", "кпл", "кпп", "дпл", "дпп", "дзл", "дзп", "крышка багажника", "крыло", "крылья").any { d.contains(it) }
        return if (metal) Section.METAL else Section.PLASTIC
    }

    fun sortRows(rows: List<OrderRow>): List<OrderRow> {
        val unpainted = rows.filter { section(it) == Section.UNPAINTED }
        val metal = rows.filter { section(it) == Section.METAL }
        val plastic = rows.filter { section(it) == Section.PLASTIC && !it.manufacturer.contains("ABS", true) }
        val abs = rows.filter { section(it) == Section.PLASTIC && it.manufacturer.contains("ABS", true) }
        return unpainted + metal + plastic + abs
    }
}
