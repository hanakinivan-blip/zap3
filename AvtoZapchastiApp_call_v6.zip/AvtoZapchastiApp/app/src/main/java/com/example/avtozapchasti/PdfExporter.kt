package com.example.avtozapchasti

import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExporter {
    fun createSection(section: Section, rows: List<OrderRow>): ByteArray {
        val doc = PdfDocument()
        val width = 842
        val height = 595
        var pageNumber = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNumber).create())
        var canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF111111.toInt() }
        var y = 32f

        fun newPage() {
            doc.finishPage(page)
            pageNumber++
            page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNumber).create())
            canvas = page.canvas
            y = 32f
        }

        fun text(value: String, size: Float, bold: Boolean = false) {
            if (y > height - 30) newPage()
            paint.textSize = size
            paint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            canvas.drawText(value, 28f, y, paint)
            y += size + 8f
        }

        text("ЗАЯВКА НА АВТОЗАПЧАСТИ", 19f, true)
        text(section.title, 16f, true)
        text(SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()), 10f)
        y += 5f

        // Column positions: model, detail, manufacturer, color, quantity.
        val x = floatArrayOf(28f, 145f, 310f, 455f, 700f)
        val headers = arrayOf("Модель", "Деталь", "Производитель", "Цвет", "Количество")
        paint.textSize = 10f
        paint.typeface = Typeface.DEFAULT_BOLD
        headers.forEachIndexed { i, h -> canvas.drawText(h, x[i], y, paint) }
        y += 7f
        canvas.drawLine(28f, y, 814f, y, paint)
        y += 18f

        if (rows.isEmpty()) {
            text("Нет позиций", 11f)
        } else {
            rows.forEach { row ->
                if (y > height - 35) newPage()
                paint.textSize = 9.5f
                paint.typeface = Typeface.DEFAULT
                canvas.drawText(row.model.take(18), x[0], y, paint)
                canvas.drawText(row.detail.take(27), x[1], y, paint)
                canvas.drawText(row.manufacturer.ifBlank { "—" }.take(22), x[2], y, paint)
                canvas.drawText(row.color.ifBlank { "—" }.take(32), x[3], y, paint)
                canvas.drawText(row.quantity.toString(), x[4], y, paint)
                y += 20f
                canvas.drawLine(28f, y - 8f, 814f, y - 8f, paint)
            }
        }
        doc.finishPage(page)
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    fun create(rows: List<OrderRow>): ByteArray {
        // Kept for compatibility; creates the metal table when called directly.
        return createSection(Section.METAL, rows.filter { OrderParser.section(it) == Section.METAL })
    }
}
