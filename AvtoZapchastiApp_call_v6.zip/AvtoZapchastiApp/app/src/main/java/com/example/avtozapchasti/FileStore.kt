package com.example.avtozapchasti

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileStore {
    private const val FOLDER = "Documents/AvtoZapchasti"

    fun savePdf(context: Context, pdf: ByteArray, baseName: String): String {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$baseName.pdf")
            put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, FOLDER)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Не удалось создать файл PDF")
        resolver.openOutputStream(uri)?.use { it.write(pdf) }
            ?: error("Не удалось записать PDF")
        return "$FOLDER/$baseName.pdf"
    }

    fun saveThreePdfs(context: Context, rows: List<OrderRow>): List<String> {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val result = mutableListOf<String>()
        Section.values().forEach { section ->
            val sectionRows = OrderParser.sortRows(rows).filter { OrderParser.section(it) == section }
            val safe = when (section) {
                Section.METAL -> "METALL"
                Section.PLASTIC -> "PLASTIK"
                Section.UNPAINTED -> "NEOKRASHENNYE"
            }
            val path = savePdf(context, PdfExporter.createSection(section, sectionRows), "zayavka_${stamp}_$safe")
            result += path
        }
        return result
    }

    fun saveJson(context: Context, json: String, baseName: String): String {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$baseName.json")
            put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, FOLDER)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Не удалось создать файл заявки")
        resolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            ?: error("Не удалось записать заявку")
        return "$FOLDER/$baseName.json"
    }

    fun baseName(): String = "zayavka_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
}
