package com.example.avtozapchasti

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("orders", MODE_PRIVATE) }
    private val kb by lazy { KnowledgeBase(this) }
    private val api by lazy { OpenAiGateway(this) }
    private val rows = mutableListOf<OrderRow>()
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var container: LinearLayout
    private lateinit var status: TextView
    private val recorder by lazy { VoiceRecorder(this) }
    private var activeVoiceFile: File? = null
    private var voiceDialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.tablesContainer)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.voiceButton).setOnClickListener { startVoiceFlow() }
        findViewById<Button>(R.id.manualButton).setOnClickListener { showEditor(null) }
        findViewById<Button>(R.id.newButton).setOnClickListener { newOrder() }
        findViewById<Button>(R.id.baseButton).setOnClickListener { showBase() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.exportButton).setOnClickListener { exportCsv() }
        findViewById<Button>(R.id.pdfButton).setOnClickListener { printPdf() }
        load(); render()
    }

    override fun onDestroy() { recorder.stop(); executor.shutdownNow(); super.onDestroy() }

    private fun newOrder() { rows.clear(); save(); render(); Toast.makeText(this, "Новая заявка", Toast.LENGTH_SHORT).show() }

    private fun startVoiceFlow() {
        if (!hasMic()) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1001); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val info = TextView(this).apply { text = "Говорите заявку обычным голосом.\nАудио → ChatGPT-расшифровка → ChatGPT-разбор по правилам → таблица."; setPadding(0,0,0,10) }
        val start = Button(this).apply { text = "🎙 Начать" }
        val stop = Button(this).apply { text = "■ Остановить"; isEnabled = false }
        val transcript = EditText(this).apply { hint = "Здесь появится расшифровка"; minLines = 6; gravity = Gravity.TOP }
        box.addView(info); box.addView(start); box.addView(stop); box.addView(transcript)
        val dialog = AlertDialog.Builder(this).setTitle("Голосовая заявка").setView(box)
            .setPositiveButton("Добавить в заявку", null).setNegativeButton("Закрыть", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val t = transcript.text.toString().trim()
                if (t.isBlank()) { Toast.makeText(this, "Нет текста для разбора", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                status.text = "ChatGPT формирует позиции…"
                parseTranscript(t) { dialog.dismiss() }
            }
        }
        start.setOnClickListener {
            try {
                activeVoiceFile = recorder.start(); start.isEnabled = false; stop.isEnabled = true
                status.text = "Идёт запись…"
            } catch (e: Exception) { status.text = "Ошибка записи: ${e.message}" }
        }
        stop.setOnClickListener {
            val f = recorder.stop(); activeVoiceFile = null; start.isEnabled = true; stop.isEnabled = false
            if (f != null) transcribeFile(f, transcript) else status.text = "Запись отсутствует"
        }
        voiceDialog = dialog
        dialog.show()
    }

    private fun transcribeFile(file: File, target: EditText) {
        status.text = "ChatGPT расшифровывает голос…"
        executor.execute {
            try {
                val text = api.transcribe(file)
                main.post { target.setText(text); target.setSelection(target.text.length); status.text = "Расшифровка готова"; file.delete() }
            } catch (e: Exception) { main.post { status.text = "Ошибка расшифровки: ${e.message}"; file.delete() } }
        }
    }

    private fun parseTranscript(text: String, after: () -> Unit = {}) {
        executor.execute {
            try {
                val parsed = api.parseOrder(text, kb.toJsonArray())
                main.post {
                    rows.addAll(parsed.rows); normalizeAndSave(); render()
                    val q = parsed.questions
                    status.text = if (q.isEmpty()) "Заявка сформирована ChatGPT" else "Нужно уточнить: ${q.size} поз."
                    if (q.isNotEmpty()) AlertDialog.Builder(this).setTitle("Нужно уточнить").setMessage(q.joinToString("\n\n")).setPositiveButton("Понятно", null).show()
                    after()
                }
            } catch (e: Exception) {
                main.post { status.text = "Ошибка ChatGPT: ${e.message}"; Toast.makeText(this, "Не удалось обработать заявку", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun showEditor(index: Int?) {
        val old = index?.let { rows[it] }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,0,20,0) }
        val names = listOf("Модель", "Деталь", "Производитель", "Цвет", "Количество")
        val fields = names.map { EditText(this).apply { hint = it } }
        old?.let { r -> fields[0].setText(r.model); fields[1].setText(r.detail); fields[2].setText(r.manufacturer); fields[3].setText(r.color); fields[4].setText(r.quantity.toString()) }
        fields.forEach { layout.addView(it) }
        val saveBase = CheckBox(this).apply { text = "Сохранить эту расшифровку в базу"; isChecked = old?.unknown == true }
        if (old?.sourcePhrase?.isBlank() != false) saveBase.isEnabled = false
        layout.addView(saveBase)
        AlertDialog.Builder(this).setTitle(if (old == null) "Новая позиция" else "Исправление позиции")
            .setView(layout).setPositiveButton("Сохранить") { _, _ ->
                val r = OrderRow(fields[0].text.toString().trim().ifBlank { "?" }, fields[1].text.toString().trim().ifBlank { "?" }, fields[2].text.toString().trim(), fields[3].text.toString().trim(), fields[4].text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1, old?.done ?: false, false, old?.sourcePhrase.orEmpty(), "")
                if (saveBase.isChecked) kb.add(r.sourcePhrase, r, section(r))
                if (index == null) rows.add(r) else rows[index] = r
                normalizeAndSave(); render()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showBase() {
        val entries = kb.entries()
        val text = if (entries.isEmpty()) "База пока пустая." else entries.takeLast(100).joinToString("\n\n") { "${it.phrase}\n→ ${it.model} | ${it.detail} | ${it.manufacturer.ifBlank { "—" }} | ${it.color.ifBlank { "—" }}" }
        AlertDialog.Builder(this).setTitle("База расшифровок (${entries.size})").setMessage(text).setPositiveButton("Закрыть", null)
            .setNeutralButton("Очистить", null).show().apply { getButton(AlertDialog.BUTTON_NEUTRAL)?.setOnClickListener { kb.clear(); dismiss(); showBase() } }
    }

    private fun showSettings() {
        val input = EditText(this).apply { setText(api.backendUrl()); hint = "https://ваш-сервер" }
        AlertDialog.Builder(this).setTitle("Адрес сервера ChatGPT").setMessage("API-ключ хранится на сервере, не в APK.").setView(input)
            .setPositiveButton("Сохранить") { _, _ -> api.saveBackendUrl(input.text.toString()); status.text = "Сервер сохранён" }
            .setNegativeButton("Отмена", null).show()
    }

    private fun normalizeAndSave() { rows.sortWith(compareBy({ section(it).ordinal }, { it.model }, { it.detail }, { it.color })); save() }
    private fun section(row: OrderRow): Section {
        val c = row.color.trim().lowercase()
        if (c.isBlank() || c == "неокрашенный" || c == "неокрашенная" || c == "без цвета") return Section.UNPAINTED
        if (row.model == "14" && row.detail.equals("Пороги", true)) return Section.PLASTIC
        if (row.manufacturer.contains("ABS", true)) return Section.PLASTIC
        val d = row.detail.lowercase()
        return if (listOf("капот", "крыло переднее", "крышка багажника").any { d.contains(it) }) Section.METAL else Section.PLASTIC
    }

    private fun render() {
        container.removeAllViews()
        for (section in Section.values()) {
            val sectionRows = rows.filter { section(it) == section }
            val qty = sectionRows.sumOf { it.quantity }
            val title = TextView(this).apply { text = "${section.title}   $qty"; textSize = 19f; setTypeface(typeface, Typeface.BOLD); setPadding(4,18,4,8) }
            container.addView(title)
            if (sectionRows.isEmpty()) container.addView(TextView(this).apply { text = "Нет позиций"; setPadding(8,6,8,12) })
            else sectionRows.forEach { container.addView(rowView(it)) }
        }
        val total = rows.sumOf { it.quantity }
        status.text = "Общее количество деталей: $total"
    }

    private fun rowView(row: OrderRow): View {
        val idx = rows.indexOf(row)
        val outer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,8,8,8); setBackgroundColor(if (row.unknown) 0xFFFFF3CD.toInt() else 0xFFFFFFFF.toInt()) }
        val text = TextView(this).apply {
            val prefix = if (row.unknown) "? " else ""
            text = prefix + "${row.model} | ${row.detail} | ${row.manufacturer.ifBlank { "—" }} | ${row.color.ifBlank { "—" }} | ${row.quantity}"
            textSize = 15f; setPadding(4,2,4,2)
            if (row.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        }
        val edit = Button(this).apply { setText("✎"); setOnClickListener { showEditor(idx) } }
        val check = CheckBox(this).apply { isChecked = row.done; setOnCheckedChangeListener { _, b -> row.done = b; save(); render() } }
        outer.addView(check, LinearLayout.LayoutParams(48,-2)); outer.addView(text, LinearLayout.LayoutParams(0,-2,1f)); outer.addView(edit, LinearLayout.LayoutParams(52,-2))
        return outer
    }

    private fun save() { val a=JSONArray(); rows.forEach { a.put(it.toJson()) }; prefs.edit().putString("rows", a.toString()).apply() }
    private fun load() {
        rows.clear()
        val saved = JSONArray(prefs.getString("rows", "[]"))
        if (saved.length() > 0) {
            for (i in 0 until saved.length()) saved.optJSONObject(i)?.let { rows.add(OrderRow.fromJson(it)) }
        } else {
            try {
                assets.open("initial_rows.json").bufferedReader().use { reader ->
                    val a = JSONArray(reader.readText())
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { rows.add(OrderRow.fromJson(it)) }
                }
            } catch (_: Exception) { }
        }
        normalizeAndSave()
    }

    private fun exportCsv() {
        val csv = buildString { append("Модель;Деталь;Производитель;Цвет;Количество\n"); rows.forEach { append("${it.model};${it.detail};${it.manufacturer};${it.color};${it.quantity}\n") } }
        val file = File(getExternalFilesDir(null), "Заявка.csv"); file.writeText(csv, Charsets.UTF_8)
        Toast.makeText(this, "CSV сохранён: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    private fun printPdf() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("Заявка", object : PrintDocumentAdapter() {
            override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes, cancellationSignal: android.os.CancellationSignal?, callback: LayoutResultCallback, extras: Bundle?) { callback.onLayoutFinished(PrintDocumentInfo.Builder("Заявка.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true) }
            override fun onWrite(pages: Array<android.print.PageRange>, destination: android.os.ParcelFileDescriptor, cancellationSignal: android.os.CancellationSignal, callback: WriteResultCallback) {
                val doc=PdfDocument(); val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val c=page.canvas; val p=android.graphics.Paint().apply { textSize=10f }
                var y=30f; c.drawText("Заявка",24f,y,p); y+=22f
                for (s in Section.values()) {
                    val rs = rows.filter { section(it) == s }
                    c.drawText("${s.title} — ${rs.sumOf { it.quantity }}", 24f, y, p)
                    y += 16f
                    for (r in rs) {
                        val manufacturer = r.manufacturer.ifBlank { "—" }
                        val color = r.color.ifBlank { "—" }
                        c.drawText(
                            "${r.model} | ${r.detail} | $manufacturer | $color | ${r.quantity}",
                            24f,
                            y,
                            p
                        )
                        y += 13f
                        if (y > 810f) break
                    }
                    y += 8f
                }
                doc.finishPage(page); FileOutputStream(destination.fileDescriptor).use { doc.writeTo(it) }; doc.close(); callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            }
        }, null)
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
}
