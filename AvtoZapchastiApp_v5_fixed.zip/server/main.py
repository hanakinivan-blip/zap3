import json
import os
from typing import Any

import requests
from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel, Field

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_BASE = "https://api.openai.com/v1"
TRANSCRIBE_MODEL = os.environ.get("OPENAI_TRANSCRIBE_MODEL", "gpt-4o-transcribe")
ORDER_MODEL = os.environ.get("OPENAI_ORDER_MODEL", "gpt-5.6-luna")

app = FastAPI(title="Автозапчасти ChatGPT Gateway", version="1.0")

SYSTEM_PROMPT = r'''
Ты — единственный модуль расшифровки и разбора заказов приложения «Автозапчасти».
Никогда не придумывай отсутствующие данные. Любое неясное, нерасшифрованное или неоднозначное значение помечай символом ? и добавляй поле в unknown_fields.
Все входные заявки на русском языке; сохраняй русские названия в нормализованном виде.

Правила таблиц:
1) Комплект передних крыльев всегда разворачивается в две строки: «Крыло переднее левое» и «Крыло переднее правое». Количество каждой стороны равно количеству комплектов.
2) Если явно сказано «неокрашенный», «неокрашенная», «без цвета» или цвет отсутствует, раздел НЕОКРАШЕННЫЕ.
3) Если модель 14 и деталь «Пороги», раздел ПЛАСТИК.
4) Если производитель ABS, раздел ПЛАСТИК, кроме правила 2: явно неокрашенный ABS остаётся в НЕОКРАШЕННЫЕ.
5) Для цветных позиций детали «Капот», «Крыло переднее левое/правое», «Крышка багажника» относятся к МЕТАЛЛ. Остальное — ПЛАСТИК.
6) Синонимы и разговорные формы нормализуй с учётом базы знаний. Например: «Снег»/«Снежка» часто означает «Снежная королева 690», «Барнео» — «Борнео 633», «Золотынков» — «Золото инков 347», «Техно» — «Техно 618», «Рислинг» — «Рислинг 610», «Пантера» — «Пантера 672», «221-й» — «Ледниковый 221», «691-й» — «Платина 691», «665-й» — «Космос 665», «610-й» — «Рислинг 610», «4-й» после моделей 720 — «724». Если смысл не подтверждается контекстом, ставь ?.
7) Слова «левое/правое» сохраняй явно. Если сказано только «крыло переднее», но не «комплект» и сторона не определена — сторона = ?.
8) Количество — целое число >= 1. Для «два комплекта» у каждой из двух сторон quantity=2.
9) Если неясна только одна часть позиции, не удаляй позицию: пометь ? только в соответствующем поле.
10) source_phrase должен содержать исходный фрагмент речи, по которому создана строка.
11) questions — короткие вопросы по позициям с ?, пригодные для показа пользователю.
12) Не используй старую локальную логику приложения: именно твой JSON является источником истины.
'''

SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "rows": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "model": {"type": "string"},
                    "detail": {"type": "string"},
                    "manufacturer": {"type": "string"},
                    "color": {"type": "string"},
                    "quantity": {"type": "integer", "minimum": 1},
                    "unknown_fields": {"type": "array", "items": {"type": "string"}},
                    "source_phrase": {"type": "string"},
                    "clarification_question": {"type": "string"}
                },
                "required": ["model","detail","manufacturer","color","quantity","unknown_fields","source_phrase","clarification_question"]
            }
        },
        "questions": {"type": "array", "items": {"type": "string"}}
    },
    "required": ["rows","questions"]
}

class ParseRequest(BaseModel):
    transcript: str = Field(min_length=1)
    knowledge_base: list[dict[str, Any]] = []


def auth_headers() -> dict[str, str]:
    if not OPENAI_API_KEY:
        raise HTTPException(500, "На сервере не задан OPENAI_API_KEY")
    return {"Authorization": f"Bearer {OPENAI_API_KEY}"}


def extract_output_text(data: dict) -> str:
    parts = []
    for item in data.get("output", []):
        for content in item.get("content", []):
            if content.get("type") == "output_text" and isinstance(content.get("text"), str):
                parts.append(content["text"])
    if parts:
        return "".join(parts)
    raise ValueError("OpenAI не вернул output_text")


@app.get("/health")
def health():
    return {"ok": True, "order_model": ORDER_MODEL, "transcribe_model": TRANSCRIBE_MODEL}


@app.post("/transcribe")
def transcribe(file: UploadFile = File(...)):
    headers = auth_headers()
    raw = file.file.read()
    files = {"file": (file.filename or "order.m4a", raw, file.content_type or "audio/mp4")}
    data = {"model": TRANSCRIBE_MODEL, "language": "ru", "response_format": "json"}
    r = requests.post(f"{OPENAI_BASE}/audio/transcriptions", headers=headers, files=files, data=data, timeout=180)
    if not r.ok:
        raise HTTPException(r.status_code, r.text[:2000])
    return {"text": r.json().get("text", "")}


@app.post("/parse-order")
def parse_order(req: ParseRequest):
    headers = {**auth_headers(), "Content-Type": "application/json"}
    kb = json.dumps(req.knowledge_base[:500], ensure_ascii=False)
    prompt = f"База уже подтверждённых расшифровок (может быть пустой):\n{kb}\n\nТекст новой заявки:\n{req.transcript}"
    payload = {
        "model": ORDER_MODEL,
        "input": [
            {"role": "system", "content": [{"type": "input_text", "text": SYSTEM_PROMPT}]},
            {"role": "user", "content": [{"type": "input_text", "text": prompt}]}
        ],
        "text": {"format": {"type": "json_schema", "name": "order_parse", "strict": True, "schema": SCHEMA}}
    }
    r = requests.post(f"{OPENAI_BASE}/responses", headers=headers, json=payload, timeout=180)
    if not r.ok:
        raise HTTPException(r.status_code, r.text[:3000])
    data = r.json()
    try:
        out = json.loads(extract_output_text(data))
    except Exception as e:
        raise HTTPException(502, f"Неверный ответ модели: {e}")
    return out
