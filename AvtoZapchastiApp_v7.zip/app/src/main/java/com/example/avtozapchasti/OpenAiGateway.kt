package com.example.avtozapchasti

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class OpenAiGateway(private val context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    fun backendUrl(): String = prefs.getString("backend_url", "http://10.0.2.2:8787")!!.trimEnd('/')
    fun saveBackendUrl(url: String) = prefs.edit().putString("backend_url", url.trim().trimEnd('/')).apply()

    fun healthCheck(): String? {
        return try {
            val req = Request.Builder().url("${backendUrl()}/health").get().build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return null
                r.body?.string()
            }
        } catch (_: Exception) {
            null
        }
    }

    fun transcribe(file: File): String {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", file.name, file.asRequestBody("audio/mp4".toMediaType()))
            .build()
        val req = Request.Builder().url("${backendUrl()}/transcribe").post(body).build()
        client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(text.ifBlank { "HTTP ${r.code}" })
            return JSONObject(text).optString("text")
        }
    }

    fun parseOrder(transcript: String, knowledge: JSONArray): ParsedOrder {
        val payload = JSONObject().apply {
            put("transcript", transcript)
            put("knowledge_base", knowledge)
        }
        val req = Request.Builder().url("${backendUrl()}/parse-order")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(body.ifBlank { "HTTP ${r.code}" })
            val o = JSONObject(body)
            val rowsArray = o.optJSONArray("rows") ?: JSONArray()
            val rows = (0 until rowsArray.length()).mapNotNull { i ->
                val x = rowsArray.optJSONObject(i) ?: return@mapNotNull null
                val model = x.optString("model", "?")
                val detail = x.optString("detail", "?")
                val manufacturer = x.optString("manufacturer", "")
                val color = x.optString("color", "")
                val qty = x.optInt("quantity", 1).coerceAtLeast(1)
                val unknownFields = x.optJSONArray("unknown_fields") ?: JSONArray()
                val unknown = unknownFields.length() > 0 || listOf(model, detail).any { it == "?" }
                OrderRow(model, detail, manufacturer, color, qty, false, unknown,
                    x.optString("source_phrase"), x.optString("clarification_question"))
            }
            val q = o.optJSONArray("questions") ?: JSONArray()
            val questions = (0 until q.length()).map { q.optString(it) }.filter { it.isNotBlank() }
            return ParsedOrder(transcript, rows, questions)
        }
    }
}
