package com.example.avtozapchasti

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    companion object {
        const val ACTION_CALL_ASSISTANT = "com.example.avtozapchasti.ACTION_CALL_ASSISTANT"
    }
    private val prefs by lazy { getSharedPreferences("orders", MODE_PRIVATE) }
    private val kb by lazy { KnowledgeBase(this) }
    private val api by lazy { OpenAiGateway(this) }
    private val rows = mutableListOf<OrderRow>()
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var container: LinearLayout
    private lateinit var status: TextView
    private val recorder by lazy { VoiceRecorder(this) }
    private var activeVoiceFile: File? = null
    private var voiceDialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.tablesContainer)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.voiceButton).setOnClickListener { startVoiceFlow() }
        findViewById<Button>(R.id.conversationButton).setOnClickListener { showConversationRecorder() }
        findViewById<Button>(R.id.historyButton).setOnClickListener { showConversationHistory() }
        findViewById<Button>(R.id.manualButton).setOnClickListener { showEditor(null) }
        findViewById<Button>(R.id.newButton).setOnClickListener { newOrder() }
        findViewById<Button>(R.id.baseButton).setOnClickListener { showBase() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.exportButton).setOnClickListener { exportCsv() }
        findViewById<Button>(R.id.pdfButton).setOnClickListener { printPdf() }
        load(); render()
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: android.content.Intent?) {
        if (intent?.action == ACTION_CALL_ASSISTANT) {
            intent.action = null
            main.postDelayed({
                showConversationRecorder(autoStartRecording = true)
            }, 250)
        }
    }

    override fun onDestroy() { recorder.stop(); executor.shutdownNow(); super.onDestroy() }

    private fun newOrder() { rows.clear(); save(); render(); Toast.makeText(this, "Новая заявка", Toast.LENGTH_SHORT).show() }

    private fun startVoiceFlow() {
        if (!hasMic()) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1001); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 10, 24, 0) }
        val info = TextView(this).apply { text = "Говорите заявку обычным голосом.\nАудио → ChatGPT-расшифровка → ChatGPT-разбор по правилам → таблица."; setPadding(0,0,0,10) }
        val start = Button(this).apply { text = "🎙 Начать" }
        val stop = Button(this).apply { text = "■ Остановить"; isEnabled = false }
        val transcript = EditText(this).apply { hint = "Здесь появится расшифровка"; minLines = 6; gravity = Gravity.TOP }
        box.addView(info); box.addView(start); box.addView(stop); box.addView(transcript)
        val dialog = AlertDialog.Builder(this).setTitle("Голосовая заявка").setView(box)
            .setPositiveButton("Добавить в заявку", null).setNegativeButton("Закрыть", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val t = transcript.text.toString().trim()
                if (t.isBlank()) { Toast.makeText(this, "Нет текста для разбора", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                status.text = "ChatGPT формирует позиции…"
                parseTranscript(t) { dialog.dismiss() }
            }
        }
        start.setOnClickListener {
            try {
                activeVoiceFile = recorder.start(); start.isEnabled = false; stop.isEnabled = true
                status.text = "Идёт запись…"
            } catch (e: Exception) { status.text = "Ошибка записи: ${e.message}" }
        }
        stop.setOnClickListener {
            val f = recorder.stop(); activeVoiceFile = null; start.isEnabled = true; stop.isEnabled = false
            if (f != null) transcribeFile(f, transcript) else status.text = "Запись отсутствует"
        }
        voiceDialog = dialog
        dialog.show()
    }

    private fun transcribeFile(file: File, target: EditText) {
        status.text = "ChatGPT расшифровывает голос…"
        executor.execute {
            try {
                val text = api.transcribe(file)
                main.post { target.setText(text); target.setSelection(target.text.length); status.text = "Расшифровка готова"; file.delete() }
            } catch (e: Exception) { main.post { status.text = "Ошибка расшифровки: ${e.message}"; file.delete() } }
        }
    }

    private fun showConversationRecorder(autoStartRecording: Boolean = false) {
        if (!hasMic()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 10, 24, 0)
        }
        val info = TextView(this).apply {
            text = "Запишите весь разговор с клиентом. После остановки аудио отправляется на OpenAI для расшифровки, затем из текста можно сразу сформировать заявку."
            setPadding(0, 0, 0, 10)
        }
        val start = Button(this).apply { text = "🎙 Начать разговор" }
        val stop = Button(this).apply { text = "■ Остановить"; isEnabled = false }
        val transcript = EditText(this).apply {
            hint = "Здесь появится полная расшифровка разговора"
            minLines = 10
            gravity = Gravity.TOP
        }
        val saveHistory = CheckBox(this).apply {
            text = "Сохранить расшифровку в историю"
            isChecked = true
        }
        box.addView(info)
        box.addView(start)
        box.addView(stop)
        box.addView(transcript)
        box.addView(saveHistory)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Запись разговора с клиентом")
            .setView(box)
            .setPositiveButton("Сформировать заявку", null)
            .setNeutralButton("Только сохранить", null)
            .setNegativeButton("Закрыть", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val t = transcript.text.toString().trim()
                if (t.isBlank()) {
                    Toast.makeText(this, "Сначала запишите или вставьте расшифровку", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (saveHistory.isChecked) saveConversation(t)
                status.text = "ChatGPT формирует заявку из разговора…"
                parseTranscript(t) { dialog.dismiss() }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val t = transcript.text.toString().trim()
                if (t.isBlank()) {
                    Toast.makeText(this, "Нет текста для сохранения", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                saveConversation(t)
                status.text = "Расшифровка разговора сохранена"
                dialog.dismiss()
            }
        }

        start.setOnClickListener {
            try {
                activeVoiceFile = recorder.start()
                start.isEnabled = false
                stop.isEnabled = true
                status.text = "Идёт запись разговора…"
            } catch (e: Exception) {
                status.text = "Ошибка записи: ${e.message}"
            }
        }
        stop.setOnClickListener {
            val f = recorder.stop()
            activeVoiceFile = null
            start.isEnabled = true
            stop.isEnabled = false
            if (f != null) {
                transcribeFile(f, transcript)
            } else {
                status.text = "Запись отсутствует"
            }
        }
        dialog.show()
        if (autoStartRecording) {
            main.postDelayed({
                if (hasMic()) {
                    start.performClick()
                } else {
                    Toast.makeText(this, "Разрешите доступ к микрофону, чтобы начать запись.", Toast.LENGTH_LONG).show()
                }
            }, 350)
        }
    }

    private fun saveConversation(text: String) {
        val prefsHistory = getSharedPreferences("conversation_history", MODE_PRIVATE)
        val current = JSONArray(prefsHistory.getString("items", "[]"))
        val item = JSONObject().apply {
            put("time", SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()))
            put("text", text)
        }
        current.put(item)
        val trimmed = JSONArray()
        val start = maxOf(0, current.length() - 50)
        for (i in start until current.length()) trimmed.put(current.getJSONObject(i))
        prefsHistory.edit().putString("items", trimmed.toString()).apply()
    }

    private fun showConversationHistory() {
        val prefsHistory = getSharedPreferences("conversation_history", MODE_PRIVATE)
        val arr = JSONArray(prefsHistory.getString("items", "[]"))
        if (arr.length() == 0) {
            AlertDialog.Builder(this).setTitle("Разговоры").setMessage("Сохранённых расшифровок пока нет.").setPositiveButton("Закрыть", null).show()
            return
        }
        val titles = Array(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            o.optString("time")
        }
        AlertDialog.Builder(this)
            .setTitle("Сохранённые разговоры")
            .setItems(titles) { _, which ->
                val o = arr.getJSONObject(which)
                val text = o.optString("text")
                AlertDialog.Builder(this)
                    .setTitle(o.optString("time"))
                    .setMessage(text)
                    .setNeutralButton("В заявку") { _, _ ->
                        status.text = "ChatGPT формирует заявку из сохранённой расшифровки…"
                        parseTranscript(text)
                    }
                    .setPositiveButton("Закрыть", null)
                    .show()
            }
            .setNeutralButton("Очистить") { _, _ -> prefsHistory.edit().remove("items").apply(); status.text = "История разговоров очищена" }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun parseTranscript(text: String, after: () -> Unit = {}) {
        executor.execute {
            try {
                val parsed = api.parseOrder(text, kb.toJsonArray())
                main.post {
                    rows.addAll(parsed.rows); normalizeAndSave(); render()
                    val q = parsed.questions
                    status.text = if (q.isEmpty()) "Заявка сформирована ChatGPT" else "Нужно уточнить: ${q.size} поз."
                    if (q.isNotEmpty()) AlertDialog.Builder(this).setTitle("Нужно уточнить").setMessage(q.joinToString("\n\n")).setPositiveButton("Понятно", null).show()
                    after()
                }
            } catch (e: Exception) {
                main.post { status.text = "Ошибка ChatGPT: ${e.message}"; Toast.makeText(this, "Не удалось обработать заявку", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun showEditor(index: Int?) {
        val old = index?.let { rows[it] }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,0,20,0) }
        val names = listOf("Модель", "Деталь", "Производитель", "Цвет", "Количество")
        val fields = names.map { EditText(this).apply { hint = it } }
        old?.let { r -> fields[0].setText(r.model); fields[1].setText(r.detail); fields[2].setText(r.manufacturer); fields[3].setText(r.color); fields[4].setText(r.quantity.toString()) }
        fields.forEach { layout.addView(it) }
        val saveBase = CheckBox(this).apply { text = "Сохранить эту расшифровку в базу"; isChecked = old?.unknown == true }
        if (old?.sourcePhrase?.isBlank() != false) saveBase.isEnabled = false
        layout.addView(saveBase)
        AlertDialog.Builder(this).setTitle(if (old == null) "Новая позиция" else "Исправление позиции")
            .setView(layout).setPositiveButton("Сохранить") { _, _ ->
                val r = OrderRow(fields[0].text.toString().trim().ifBlank { "?" }, fields[1].text.toString().trim().ifBlank { "?" }, fields[2].text.toString().trim(), fields[3].text.toString().trim(), fields[4].text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1, old?.done ?: false, false, old?.sourcePhrase.orEmpty(), "")
                if (saveBase.isChecked) kb.add(r.sourcePhrase, r, section(r))
                if (index == null) rows.add(r) else rows[index] = r
                normalizeAndSave(); render()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun showBase() {
        val entries = kb.entries()
        val text = if (entries.isEmpty()) "База пока пустая." else entries.takeLast(100).joinToString("\n\n") { "${it.phrase}\n→ ${it.model} | ${it.detail} | ${it.manufacturer.ifBlank { "—" }} | ${it.color.ifBlank { "—" }}" }
        AlertDialog.Builder(this).setTitle("База расшифровок (${entries.size})").setMessage(text).setPositiveButton("Закрыть", null)
            .setNeutralButton("Очистить", null).show().apply { getButton(AlertDialog.BUTTON_NEUTRAL)?.setOnClickListener { kb.clear(); dismiss(); showBase() } }
    }

    private fun showSettings() {
        val input = EditText(this).apply { setText(api.backendUrl()); hint = "http://192.168.1.100:8787" }
        val callAssistant = CheckBox(this).apply {
            text = "Помощник при входящем/исходящем звонке"
            isChecked = prefs.getBoolean("call_assistant_enabled", true)
            setPadding(0, 12, 0, 0)
        }
        val info = TextView(this).apply {
            text = "Если это реальный телефон, 10.0.2.2 обычно не подходит. Укажите локальный IP компьютера, где запущен сервер, например http://192.168.1.100:8787. Телефон и компьютер должны быть в одной Wi‑Fi сети; порт 8787 должен быть разрешён в брандмауэре."
            setPadding(0, 0, 0, 10)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(info)
            addView(input)
            addView(callAssistant)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Адрес сервера ChatGPT")
            .setMessage("API-ключ хранится на сервере, не в APK.")
            .setView(box)
            .setPositiveButton("Сохранить", null)
            .setNeutralButton("Проверить")
            .setNegativeButton("Отмена", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                api.saveBackendUrl(input.text.toString())
                prefs.edit().putBoolean("call_assistant_enabled", callAssistant.isChecked).apply()
                status.text = if (callAssistant.isChecked) "Сервер сохранён. Помощник при звонках включён." else "Сервер сохранён. Помощник при звонках выключен."
                if (callAssistant.isChecked) requestCallAssistantPermissions()
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                api.saveBackendUrl(input.text.toString())
                prefs.edit().putBoolean("call_assistant_enabled", callAssistant.isChecked).apply()
                if (callAssistant.isChecked) requestCallAssistantPermissions()
                status.text = "Проверяем сервер…"
                executor.execute {
                    val result = api.healthCheck()
                    main.post {
                        status.text = if (result == null) "Сервер недоступен" else "Сервер доступен: $result"
                        Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        dialog.show()
    }

    private fun normalizeAndSave() { rows.sortWith(compareBy({ section(it).ordinal }, { it.model }, { it.detail }, { it.color })); save() }
    private fun section(row: OrderRow): Section {
        val c = row.color.trim().lowercase()
        if (c.isBlank() || c == "неокрашенный" || c == "неокрашенная" || c == "без цвета") return Section.UNPAINTED
        if (row.model == "14" && row.detail.equals("Пороги", true)) return Section.PLASTIC
        if (row.manufacturer.contains("ABS", true)) return Section.PLASTIC
        val d = row.detail.lowercase()
        return if (listOf("капот", "крыло переднее", "крышка багажника").any { d.contains(it) }) Section.METAL else Section.PLASTIC
    }

    private fun render() {
        container.removeAllViews()
        for (section in Section.values()) {
            val sectionRows = rows.filter { section(it) == section }
            val qty = sectionRows.sumOf { it.quantity }
            val title = TextView(this).apply { text = "${section.title}   $qty"; textSize = 19f; setTypeface(typeface, Typeface.BOLD); setPadding(4,18,4,8) }
            container.addView(title)
            if (sectionRows.isEmpty()) container.addView(TextView(this).apply { text = "Нет позиций"; setPadding(8,6,8,12) })
            else sectionRows.forEach { container.addView(rowView(it)) }
        }
        val total = rows.sumOf { it.quantity }
        status.text = "Общее количество деталей: $total"
    }

    private fun rowView(row: OrderRow): View {
        val idx = rows.indexOf(row)
        val outer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,8,8,8); setBackgroundColor(if (row.unknown) 0xFFFFF3CD.toInt() else 0xFFFFFFFF.toInt()) }
        val text = TextView(this).apply {
            val prefix = if (row.unknown) "? " else ""
            text = prefix + "${row.model} | ${row.detail} | ${row.manufacturer.ifBlank { "—" }} | ${row.color.ifBlank { "—" }} | ${row.quantity}"
            textSize = 15f; setPadding(4,2,4,2)
            if (row.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        }
        val edit = Button(this).apply { setText("✎"); setOnClickListener { showEditor(idx) } }
        val check = CheckBox(this).apply { isChecked = row.done; setOnCheckedChangeListener { _, b -> row.done = b; save(); render() } }
        outer.addView(check, LinearLayout.LayoutParams(48,-2)); outer.addView(text, LinearLayout.LayoutParams(0,-2,1f)); outer.addView(edit, LinearLayout.LayoutParams(52,-2))
        return outer
    }

    private fun save() { val a=JSONArray(); rows.forEach { a.put(it.toJson()) }; prefs.edit().putString("rows", a.toString()).apply() }
    private fun load() {
        rows.clear()
        val saved = JSONArray(prefs.getString("rows", "[]"))
        if (saved.length() > 0) {
            for (i in 0 until saved.length()) saved.optJSONObject(i)?.let { rows.add(OrderRow.fromJson(it)) }
        } else {
            try {
                assets.open("initial_rows.json").bufferedReader().use { reader ->
                    val a = JSONArray(reader.readText())
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { rows.add(OrderRow.fromJson(it)) }
                }
            } catch (_: Exception) { }
        }
        normalizeAndSave()
    }

    private fun exportCsv() {
        val csv = buildString { append("Модель;Деталь;Производитель;Цвет;Количество\n"); rows.forEach { append("${it.model};${it.detail};${it.manufacturer};${it.color};${it.quantity}\n") } }
        val file = File(getExternalFilesDir(null), "Заявка.csv"); file.writeText(csv, Charsets.UTF_8)
        Toast.makeText(this, "CSV сохранён: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    private fun printPdf() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("Заявка", object : PrintDocumentAdapter() {
            override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes, cancellationSignal: android.os.CancellationSignal?, callback: LayoutResultCallback, extras: Bundle?) { callback.onLayoutFinished(PrintDocumentInfo.Builder("Заявка.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true) }
            override fun onWrite(pages: Array<android.print.PageRange>, destination: android.os.ParcelFileDescriptor, cancellationSignal: android.os.CancellationSignal, callback: WriteResultCallback) {
                val doc=PdfDocument(); val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create()); val c=page.canvas; val p=android.graphics.Paint().apply { textSize=10f }
                var y=30f; c.drawText("Заявка",24f,y,p); y+=22f
                for (s in Section.values()) {
                    val rs = rows.filter { section(it) == s }
                    c.drawText("${s.title} — ${rs.sumOf { it.quantity }}", 24f, y, p)
                    y += 16f
                    for (r in rs) {
                        val manufacturer = r.manufacturer.ifBlank { "—" }
                        val color = r.color.ifBlank { "—" }
                        c.drawText(
                            "${r.model} | ${r.detail} | $manufacturer | $color | ${r.quantity}",
                            24f,
                            y,
                            p
                        )
                        y += 13f
                        if (y > 810f) break
                    }
                    y += 8f
                }
                doc.finishPage(page); FileOutputStream(destination.fileDescriptor).use { doc.writeTo(it) }; doc.close(); callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            }
        }, null)
    }

    private fun requestCallAssistantPermissions() {
        val permissions = mutableListOf(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 2007)
        }
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
}
