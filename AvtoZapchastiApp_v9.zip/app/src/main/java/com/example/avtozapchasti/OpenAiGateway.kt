package com.example.avtozapchasti

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class OpenAiGateway(private val context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val secretStore = SecretStore(context)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    fun connectionMode(): String = prefs.getString("connection_mode", "direct") ?: "direct"
    fun saveConnectionMode(mode: String) = prefs.edit().putString("connection_mode", mode).apply()

    fun backendUrl(): String = prefs.getString("backend_url", "")!!.trimEnd('/')
    fun saveBackendUrl(url: String) = prefs.edit().putString("backend_url", url.trim().trimEnd('/')).apply()

    fun hasApiKey(): Boolean = secretStore.hasValue()
    fun saveApiKey(value: String) = secretStore.save(value.trim())
    fun clearApiKey() = secretStore.clear()

    fun healthCheck(): String? {
        return try {
            if (connectionMode() == "direct") {
                val key = requireApiKey()
                val req = Request.Builder()
                    .url("https://api.openai.com/v1/models")
                    .header("Authorization", "Bearer $key")
                    .get()
                    .build()
                client.newCall(req).execute().use { r ->
                    val body = r.body?.string().orEmpty()
                    if (!r.isSuccessful) error(openAiError(body, r.code))
                    "OpenAI доступен"
                }
            } else {
                val url = backendUrl().ifBlank { return null }
                val req = Request.Builder().url("$url/health").get().build()
                client.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return null
                    r.body?.string()
                }
            }
        } catch (_: Exception) { null }
    }

    fun transcribe(file: File): String {
        return if (connectionMode() == "direct") transcribeDirect(file) else transcribeBackend(file)
    }

    private fun transcribeBackend(file: File): String {
        val base = backendUrl().ifBlank { error("Не задан адрес сервера") }
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", file.name, file.asRequestBody("audio/mp4".toMediaType()))
            .build()
        val req = Request.Builder().url("$base/transcribe").post(body).build()
        client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(text.ifBlank { "HTTP ${r.code}" })
            return JSONObject(text).optString("text")
        }
    }

    private fun transcribeDirect(file: File): String {
        val key = requireApiKey()
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", file.name, file.asRequestBody("audio/mp4".toMediaType()))
            .addFormDataPart("model", "gpt-4o-transcribe")
            .addFormDataPart("language", "ru")
            .addFormDataPart("response_format", "json")
            .build()
        val req = Request.Builder()
            .url("https://api.openai.com/v1/audio/transcriptions")
            .header("Authorization", "Bearer $key")
            .post(body)
            .build()
        client.newCall(req).execute().use { r ->
            val bodyText = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(openAiError(bodyText, r.code))
            return JSONObject(bodyText).optString("text")
        }
    }

    fun parseOrder(transcript: String, knowledge: JSONArray): ParsedOrder {
        return if (connectionMode() == "direct") parseDirect(transcript, knowledge) else parseBackend(transcript, knowledge)
    }

    private fun parseBackend(transcript: String, knowledge: JSONArray): ParsedOrder {
        val base = backendUrl().ifBlank { error("Не задан адрес сервера") }
        val payload = JSONObject().apply {
            put("transcript", transcript)
            put("knowledge_base", knowledge)
        }
        val req = Request.Builder().url("$base/parse-order")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(body.ifBlank { "HTTP ${r.code}" })
            return parseResponse(JSONObject(body), transcript)
        }
    }

    private fun parseDirect(transcript: String, knowledge: JSONArray): ParsedOrder {
        val key = requireApiKey()
        val schema = JSONObject().apply {
            put("type", "object")
            put("additionalProperties", false)
            put("properties", JSONObject().apply {
                put("rows", JSONObject().apply {
                    put("type", "array")
                    put("items", JSONObject().apply {
                        put("type", "object")
                        put("additionalProperties", false)
                        put("properties", JSONObject().apply {
                            put("model", JSONObject().put("type", "string"))
                            put("detail", JSONObject().put("type", "string"))
                            put("manufacturer", JSONObject().put("type", "string"))
                            put("color", JSONObject().put("type", "string"))
                            put("quantity", JSONObject().put("type", "integer").put("minimum", 1))
                            put("unknown_fields", JSONObject().apply { put("type", "array"); put("items", JSONObject().put("type", "string")) })
                            put("source_phrase", JSONObject().put("type", "string"))
                            put("clarification_question", JSONObject().put("type", "string"))
                        })
                        put("required", JSONArray(listOf("model", "detail", "manufacturer", "color", "quantity", "unknown_fields", "source_phrase", "clarification_question")))
                    })
                })
                put("questions", JSONObject().apply { put("type", "array"); put("items", JSONObject().put("type", "string")) })
            })
            put("required", JSONArray(listOf("rows", "questions")))
        }

        val system = """
Ты — модуль расшифровки и разбора заказов приложения «Автозапчасти».
Никогда не придумывай отсутствующие данные. Любое неясное, нерасшифрованное или неоднозначное значение помечай символом ? и добавляй поле в unknown_fields.
Все входные заявки на русском языке.
Правила:
1) «Крылья передние, комплект» всегда разворачивай в две строки: «Крыло переднее левое» и «Крыло переднее правое». Количество каждой стороны равно количеству комплектов.
2) Если явно сказано «неокрашенный», «неокрашенная», «без цвета» или цвет отсутствует — НЕОКРАШЕННЫЕ.
3) Если модель 14 и деталь «Пороги» — ПЛАСТИК.
4) Если производитель ABS — ПЛАСТИК, кроме явно неокрашенного ABS: он остаётся в НЕОКРАШЕННЫЕ.
5) Для цветных позиций «Капот», «Крыло переднее левое/правое», «Крышка багажника» — МЕТАЛЛ. Остальное — ПЛАСТИК.
6) Нормализуй разговорные названия по базе знаний. Не подтверждённые варианты не угадывай.
7) Если сказано только «крыло переднее» без стороны и без комплекта — сторона = ?.
8) Количество — целое >= 1.
9) Если непонятна только часть позиции, ставь ? только в этом поле.
10) source_phrase — исходный фрагмент речи.
11) questions — короткие вопросы по позициям с ?.
""".trimIndent()
        val kb = knowledge.toString()
        val userPrompt = "База подтверждённых исправлений:\n$kb\n\nНовая заявка:\n$transcript"

        val payload = JSONObject().apply {
            put("model", "gpt-5.6-luna")
            put("input", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", JSONArray().put(JSONObject().put("type", "input_text").put("text", system)))
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().put(JSONObject().put("type", "input_text").put("text", userPrompt)))
                })
            })
            put("text", JSONObject().apply {
                put("format", JSONObject().apply {
                    put("type", "json_schema")
                    put("name", "order_parse")
                    put("strict", true)
                    put("schema", schema)
                })
            })
        }

        val req = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(openAiError(body, r.code))
            val outText = extractResponsesOutputText(JSONObject(body))
            return parseResponse(JSONObject(outText), transcript)
        }
    }

    private fun parseResponse(o: JSONObject, transcript: String): ParsedOrder {
        val rowsArray = o.optJSONArray("rows") ?: JSONArray()
        val rows = (0 until rowsArray.length()).mapNotNull { i ->
            val x = rowsArray.optJSONObject(i) ?: return@mapNotNull null
            val model = x.optString("model", "?").ifBlank { "?" }
            val detail = x.optString("detail", "?").ifBlank { "?" }
            val manufacturer = x.optString("manufacturer", "")
            val color = x.optString("color", "")
            val qty = x.optInt("quantity", 1).coerceAtLeast(1)
            val unknownFields = x.optJSONArray("unknown_fields") ?: JSONArray()
            val unknown = unknownFields.length() > 0 || listOf(model, detail, manufacturer, color).any { it == "?" }
            OrderRow(model, detail, manufacturer, color, qty, false, unknown,
                x.optString("source_phrase"), x.optString("clarification_question"))
        }
        val q = o.optJSONArray("questions") ?: JSONArray()
        val questions = (0 until q.length()).map { q.optString(it) }.filter { it.isNotBlank() }
        return ParsedOrder(transcript, rows, questions)
    }

    private fun extractResponsesOutputText(data: JSONObject): String {
        val output = data.optJSONArray("output") ?: JSONArray()
        val pieces = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                if (part.optString("type") == "output_text") {
                    pieces.append(part.optString("text"))
                }
            }
        }
        if (pieces.isNotEmpty()) return pieces.toString()
        error("OpenAI не вернул структурированный ответ")
    }

    private fun requireApiKey(): String = secretStore.read().ifBlank {
        error("Не задан OpenAI API-ключ. Откройте Настройки и сохраните ключ.")
    }

    private fun openAiError(body: String, code: Int): String {
        return try {
            val o = JSONObject(body)
            o.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() } ?: "HTTP $code"
        } catch (_: Exception) { "HTTP $code: ${body.take(300)}" }
    }
}
