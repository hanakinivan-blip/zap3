package com.example.avtozapchasti

/**
 * Turns conversational Russian speech into order rows.
 * The parser keeps context (last model/color/manufacturer/detail) so a customer
 * can spread one item over several phrases during a call.
 */
object OrderParser {
    private val colors = linkedMapOf(
        "снежная королева" to "Снежная королева (690)", "снежка" to "Снежная королева (690)", "снег" to "Снежная королева (690)", "690" to "Снежная королева (690)",
        "млечка" to "Млечка (606)", "млечный путь" to "Млечка (606)", "606" to "Млечка (606)",
        "ледяной" to "Ледяной (413)", "413" to "Ледяной (413)", "техно" to "Техно (618)", "618" to "Техно (618)",
        "белое облако" to "Белое облако (240)", "240" to "Белое облако (240)", "плутон" to "Плутон (608)", "608" to "Плутон (608)",
        "рислинг" to "Рислинг (610)", "610" to "Рислинг (610)", "космос" to "Космос (665)", "665" to "Космос (665)",
        "баклажан" to "Баклажан (107)", "107" to "Баклажан (107)", "золото инков" to "Золото инков (347)", "золото инковский" to "Золото инков (347)", "золотынков" to "Золото инков (347)", "347" to "Золото инков (347)",
        "боровница" to "Боровница (451)", "451" to "Боровница (451)", "портвейн" to "Портвейн (192)", "192" to "Портвейн (192)",
        "кварц" to "Кварц (630)", "630" to "Кварц (630)", "ницца" to "Ницца (328)", "328" to "Ницца (328)",
        "пантера" to "Пантера (672)", "672" to "Пантера (672)", "борнео" to "Борнео (633)", "барнео" to "Борнео (633)", "633" to "Борнео (633)",
        "кориандр" to "Кориандр (790)", "790" to "Кориандр (790)", "платина" to "Платина (691)", "691" to "Платина (691)",
        "одиссей" to "Одиссей (497)", "497" to "Одиссей (497)", "булат" to "Булат (619)", "619" to "Булат (619)",
        "ледниковый" to "Ледниковый (221)", "221" to "Ледниковый (221)", "калифорнийский мак" to "Калифорнийский мак (190)", "190" to "Калифорнийский мак (190)",
        "черника" to "Черника (482)", "482" to "Черника (482)", "чёрная жемчужина" to "Чёрная жемчужина (676)", "черная жемчужина" to "Чёрная жемчужина (676)", "676" to "Чёрная жемчужина (676)",
        "b66" to "B66", "693" to "693"
    )

    private val tens = mapOf("двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50, "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90)
    private val ones = mapOf("один" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9)

    private data class Context(
        var model: String = "",
        var manufacturer: String = "",
        var color: String = "",
        var lastDetail: String = "",
        var lastQuantity: Int = 1
    )

    fun parse(text: String): List<OrderRow> {
        val source = clean(text)
        if (source.isBlank()) return emptyList()
        val context = Context()
        val result = mutableListOf<OrderRow>()

        // SpeechRecognizer returns separate phrases. Process them in order so
        // "Веста..." followed by "левое крыло..." becomes one logical request.
        val utterances = source.split(Regex("[\\n.!?]+|(?i)(?<=\\b(?:ладно|хорошо))[,;]"))
            .map { it.trim(' ', ',', ';', ':') }
            .filter { it.isNotBlank() }

        for (utterance in utterances) {
            val low = utterance.lowercase()
            normalizeModel(low)?.let { newModel ->
                context.model = newModel
                // If the model was spoken after the part, complete those rows.
                result.filter { it.model.isBlank() }.forEach { it.model = newModel }
            }
            normalizeManufacturer(low).takeIf { it.isNotBlank() }?.let { context.manufacturer = it }
            normalizeColor(low).takeIf { it.isNotBlank() }?.let { context.color = it }

            val chunks = splitIntoDetailChunks(low)
            if (chunks.isEmpty()) continue

            for (chunk in chunks) {
                val explicitDetail = normalizeDetail(chunk)
                val detail = explicitDetail ?: inheritedDetail(chunk, context.lastDetail)
                if (detail.isNullOrBlank()) continue

                val manufacturer = normalizeManufacturer(chunk).ifBlank { context.manufacturer }
                val color = normalizeColor(chunk).ifBlank { context.color }
                val qty = quantity(chunk, context.lastQuantity)
                context.manufacturer = manufacturer
                context.color = color
                context.lastDetail = detail
                context.lastQuantity = qty

                val baseDetail = detail.substringBefore(",").trim()
                if (baseDetail == "Крылья передние" && chunk.contains("комплект")) {
                    result += OrderRow(context.model, "КПЛ" + suffixes(chunk), manufacturer, color, qty)
                    result += OrderRow(context.model, "КПП" + suffixes(chunk), manufacturer, color, qty)
                } else {
                    result += OrderRow(context.model, detail, manufacturer, color, qty)
                }
            }
        }

        // Remove only exact duplicates created by recognition retries; quantities
        // for intentionally repeated positions can still be edited by the user.
        return result.distinctBy { listOf(it.model, it.detail, it.manufacturer, it.color, it.quantity) }
    }

    private fun clean(s: String): String = s.trim().replace('Ё', 'Е').replace('ё', 'е')

    private fun splitIntoDetailChunks(s: String): List<String> {
        val detailWord = "(?:решет|крыл|капот|передн|задн|двер|люч|петл|порог|реснич)"
        val starts = Regex("(?i)\\b$detailWord\\w*").findAll(s).map { it.range.first }.toList()
        if (starts.isEmpty()) {
            // Direction-only phrases such as "правое тоже два" are handled by context.
            if (Regex("(?i)\\b(лев|левое|левая|прав|правое|правая)\\b").containsMatchIn(s)) return listOf(s)
            return emptyList()
        }
        return starts.mapIndexed { i, start ->
            val end = if (i + 1 < starts.size) starts[i + 1] else s.length
            s.substring(start, end).trim(' ', ',', ';', ':', '-', '—')
        }
    }

    private fun inheritedDetail(chunk: String, last: String): String? {
        if (last.isBlank()) return null
        val low = chunk.lowercase()
        if (!Regex("(?i)\\b(лев|левое|левая|прав|правое|правая)\\b").containsMatchIn(low)) return null
        val side = when {
            Regex("(?i)\\b(лев|левое|левая)\\b").containsMatchIn(low) -> "лев"
            else -> "прав"
        }
        return when {
            last.startsWith("КПЛ") || last.startsWith("КПП") -> if (side == "лев") "КПЛ" + suffixes(low) else "КПП" + suffixes(low)
            last.startsWith("ДПЛ") || last.startsWith("ДПП") -> if (side == "лев") "ДПЛ" + suffixes(low) else "ДПП" + suffixes(low)
            last.startsWith("ДЗЛ") || last.startsWith("ДЗП") -> if (side == "лев") "ДЗЛ" + suffixes(low) else "ДЗП" + suffixes(low)
            else -> last
        }
    }

    private fun suffixes(low: String): String {
        val parts = mutableListOf<String>()
        if (low.contains("без поворотника")) parts += ", без поворотника"
        else if (low.contains("с поворотником")) parts += ", с поворотником"
        if (low.contains("дешев") || low.contains("дешёв")) parts += ", дешёвый"
        return parts.joinToString("")
    }

    fun section(row: OrderRow): Section {
        if (row.color.isBlank() || row.color.equals("Неокрашенный", true)) return Section.UNPAINTED
        if (row.manufacturer.contains("ABS", true)) return Section.PLASTIC
        val d = row.detail.lowercase()
        val metal = listOf("капот", "кпл", "кпп", "дпл", "дпп", "дзл", "дзп", "крышка багажника", "крыло").any { d.contains(it) }
        return if (metal) Section.METAL else Section.PLASTIC
    }

    fun sortRows(rows: List<OrderRow>): List<OrderRow> {
        val unpainted = rows.filter { section(it) == Section.UNPAINTED }
        val metal = rows.filter { section(it) == Section.METAL }
        val plastic = rows.filter { section(it) == Section.PLASTIC && !it.manufacturer.contains("ABS", true) }
        val abs = rows.filter { section(it) == Section.PLASTIC && it.manufacturer.contains("ABS", true) }
        return unpainted + metal + plastic + abs
    }

    private fun normalizeManufacturer(s: String): String {
        val found = mutableListOf<String>()
        if (Regex("\\babs\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)) found += "ABS"
        if (s.contains("тайвань")) found += "Тайвань"
        if (Regex("\\bng\\b").containsMatchIn(s)) found += "NG"
        if (s.contains("завод") || s.contains("заводской")) found += "ВАЗ"
        if (s.contains("sport")) found += "Sport"
        return found.distinct().joinToString(", ")
    }

    private fun normalizeModel(s: String): String? {
        if (Regex("720\\s*[/ -]?\\s*4|четвертый\\s*ряд|4[- ]й", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "724"
        if (Regex("датсун|дадсун|datsun", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "95"
        if (Regex("vaz\\s*2113.*2114.*2115", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "2114"
        if (Regex("веста(?:\\s+седан)?").containsMatchIn(s)) return "Vesta"
        if (Regex("калина\\s*118").containsMatchIn(s)) return "118"
        if (Regex("урбан\\s*(ptf|птф)").containsMatchIn(s)) return "Урбан ПТФ"
        if (Regex("x[- ]?ray", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "X-Ray"
        if (s.contains("largus", true) || s.contains("ларгус")) return "Largus"
        Regex("\\b(08|09|14|15|18|19|23|70|80|90|91|92|118|704|724)\\b").find(s)?.let { return it.groupValues[1] }
        return null
    }

    private fun normalizeDetail(s: String): String? {
        var d = when {
            Regex("дверь\\s+передн.*лев").containsMatchIn(s) -> "ДПЛ"
            Regex("дверь\\s+передн.*прав").containsMatchIn(s) -> "ДПП"
            Regex("дверь\\s+задн.*лев").containsMatchIn(s) -> "ДЗЛ"
            Regex("дверь\\s+задн.*прав").containsMatchIn(s) -> "ДЗП"
            Regex("крыл(о|ья)\\s+передн.*лев").containsMatchIn(s) -> "КПЛ"
            Regex("крыл(о|ья)\\s+передн.*прав").containsMatchIn(s) -> "КПП"
            Regex("крыл(о|ья)\\s+передн").containsMatchIn(s) -> "Крылья передние"
            Regex("решет.*ниж").containsMatchIn(s) -> "Решётка нижняя"
            Regex("решет.*верх").containsMatchIn(s) -> "Решётка верхняя"
            s.contains("лючок бензобака") -> "Лючок бензобака"
            s.contains("петл") && s.contains("капот") -> "Петля капота"
            s.contains("дверь задка левая глухая") -> "Дверь задка левая глухая"
            s.contains("дверь задка") -> "Дверь задка"
            s.contains("капот") -> "Капот"
            s.contains("пороги") -> "Пороги"
            s.contains("реснички") -> "Реснички"
            s.contains("решет") -> "Решётка"
            else -> null
        } ?: return null
        if (s.contains("без поворотника")) d += ", без поворотника" else if (s.contains("с поворотником")) d += ", с поворотником"
        if (s.contains("дешев") || s.contains("дешёв")) d += ", дешёвый"
        return d
    }

    private fun normalizeColor(s: String): String {
        for ((k, v) in colors.entries.sortedByDescending { it.key.length }) if (s.contains(k)) return v
        return if (s.contains("неокраш")) "Неокрашенный" else ""
    }

    private fun quantity(s: String, fallback: Int): Int {
        Regex("\\b(\\d+)\\s*(шт|штук|штуки|комплект|комплекта)\\b").find(s)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(1, 99) }
        Regex("\\b(\\d+)\\b").find(s)?.groupValues?.get(1)?.toIntOrNull()?.let { n -> if (n in 1..99 && !isColorCode(s, n)) return n }
        for ((w, v) in ones) if (Regex("\\b${Regex.escape(w)}\\b").containsMatchIn(s)) return v
        for ((w, v) in tens) if (Regex("\\b${Regex.escape(w)}\\b").containsMatchIn(s)) return v
        return if (s.contains("комплект")) fallback else 1
    }

    private fun isColorCode(s: String, n: Int): Boolean = n in listOf(190,192,221,240,328,347,413,426,429,451,482,497,606,608,610,618,619,630,633,665,672,676,690,691,693,790)
}
