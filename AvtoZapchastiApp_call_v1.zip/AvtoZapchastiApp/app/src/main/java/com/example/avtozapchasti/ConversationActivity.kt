package com.example.avtozapchasti

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.util.Locale

class ConversationActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var orderContainer: LinearLayout
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private val handler = Handler(Looper.getMainLooper())
    private val requestMic = 3001
    private val transcriptLines = mutableListOf<String>()
    private val rows = mutableListOf<OrderRow>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversation)
        status = findViewById(R.id.status)
        transcript = findViewById(R.id.transcript)
        orderContainer = findViewById(R.id.orderContainer)

        findViewById<Button>(R.id.startButton).setOnClickListener { startSession() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopSession() }
        findViewById<Button>(R.id.clearButton).setOnClickListener { transcriptLines.clear(); rows.clear(); renderAll() }
        findViewById<Button>(R.id.orderButton).setOnClickListener { buildOrder() }
        findViewById<Button>(R.id.savePdfButton).setOnClickListener { savePdf() }

        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) audio.isSpeakerphoneOn = true
        status.text = if (SpeechRecognizer.isRecognitionAvailable(this))
            "Готово. Для звонка включите громкую связь и нажмите «Начать»."
        else "На телефоне нет службы распознавания речи."
    }

    private fun startSession() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestMic)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Распознавание речи недоступно"
            return
        }
        listening = true
        startService(Intent(this, CallAwareForegroundService::class.java))
        status.text = "🎙 Слушаю звонок…"
        listenOnce()
    }

    private fun listenOnce() {
        if (!listening) return
        recognizer?.destroy()
        recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "🎙 Слушаю…" }
            override fun onBeginningOfSpeech() { status.text = "Речь распознаётся…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                if (listening) handler.postDelayed({ listenOnce() }, 250)
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (text.isNotBlank()) addTranscript(text)
                if (listening) handler.postDelayed({ listenOnce() }, 120)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (text.isNotBlank()) status.text = "🎙 $text"
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(intent)
    }

    private fun addTranscript(text: String) {
        transcriptLines += text
        transcript.text = transcriptLines.joinToString("\n\n")
        buildOrder()
    }

    private fun stopSession() {
        listening = false
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        stopService(Intent(this, CallAwareForegroundService::class.java))
        status.text = "Остановлено. Заявку можно редактировать и сохранить."
    }

    private fun buildOrder() {
        val parsed = OrderParser.parse(transcriptLines.joinToString(" "))
        rows.clear(); rows.addAll(parsed)
        renderOrder()
    }

    private fun renderAll() {
        transcript.text = transcriptLines.joinToString("\n\n")
        renderOrder()
    }

    private fun renderOrder() {
        orderContainer.removeAllViews()
        val sorted = OrderParser.sortRows(rows)
        for (section in Section.values()) {
            val heading = TextView(this).apply { text = section.title; textSize = 17f; setPadding(0, 14, 0, 6) }
            orderContainer.addView(heading)
            sorted.filter { OrderParser.section(it) == section }.forEach { row -> orderContainer.addView(rowView(row)) }
        }
    }

    private fun rowView(row: OrderRow): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4, 4, 4, 4) }
        val text = TextView(this).apply { text = "${row.model} | ${row.detail} | ${row.manufacturer.ifBlank { "—" }} | ${row.color.ifBlank { "—" }} | ${row.quantity}"; textSize = 14f }
        val edit = Button(this).apply { text = "✎"; setOnClickListener { editRow(row) } }
        box.addView(text, LinearLayout.LayoutParams(0, -2, 1f)); box.addView(edit)
        return box
    }

    private fun editRow(row: OrderRow) {
        val fields = listOf("Модель", "Деталь", "Производитель", "Цвет", "Количество").map { EditText(this).apply { hint = it } }
        fields[0].setText(row.model); fields[1].setText(row.detail); fields[2].setText(row.manufacturer); fields[3].setText(row.color); fields[4].setText(row.quantity.toString())
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 24, 0) }; fields.forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("Редактирование позиции").setView(box).setPositiveButton("Сохранить") { _, _ ->
            row.model = fields[0].text.toString().trim(); row.detail = fields[1].text.toString().trim(); row.manufacturer = fields[2].text.toString().trim(); row.color = fields[3].text.toString().trim(); row.quantity = fields[4].text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1; renderOrder()
        }.setNegativeButton("Отмена", null).show()
    }

    private fun savePdf() {
        if (rows.isEmpty()) { Toast.makeText(this, "Сначала сформируйте заявку", Toast.LENGTH_SHORT).show(); return }
        runCatching {
            val base = FileStore.baseName()
            val pdfPath = FileStore.savePdf(this, PdfExporter.create(rows), base)
            val json = JSONArray().apply { rows.forEach { r -> put(org.json.JSONObject().apply { put("model", r.model); put("detail", r.detail); put("manufacturer", r.manufacturer); put("color", r.color); put("quantity", r.quantity) }) } }.toString(2)
            FileStore.saveJson(this, json, base)
            Toast.makeText(this, "Сохранено в $pdfPath", Toast.LENGTH_LONG).show()
        }.onFailure { Toast.makeText(this, "Ошибка сохранения: ${it.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() { listening = false; recognizer?.destroy(); recognizer = null; handler.removeCallbacksAndMessages(null); super.onDestroy() }
}
