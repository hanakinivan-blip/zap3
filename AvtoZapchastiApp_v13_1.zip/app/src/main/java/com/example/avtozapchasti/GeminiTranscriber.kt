package com.example.avtozapchasti

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object GeminiTranscriber {
    private const val PREFS = "ai_settings"
    private const val KEY_API = "gemini_api_key"
    private const val KEY_CLOUD = "cloud_transcription"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"
    private val executor = Executors.newCachedThreadPool()

    fun enabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_CLOUD, true)
    fun setEnabled(context: Context, value: Boolean) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_CLOUD, value).apply()
    fun getKey(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_API, "").orEmpty()

    fun transcribeAsync(context: Context, audioFile: File, callback: (String?, String?) -> Unit) {
        val key = getKey(context)
        if (key.isBlank()) { callback(null, "Добавьте API-ключ Gemini в настройках AI"); return }
        executor.execute {
            try {
                val text = request(key, audioFile)
                Handler(Looper.getMainLooper()).post { callback(text, null) }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { callback(null, e.message ?: "Ошибка онлайн-расшифровки Gemini") }
            }
        }
    }

    fun requestSync(context: Context, file: File): String {
        val key = getKey(context)
        if (key.isBlank()) throw IllegalStateException("Gemini API-ключ не задан")
        return request(key, file)
    }

    private fun request(key: String, file: File): String {
        val bytes = FileInputStream(file).use { it.readBytes() }
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val prompt = """
Точно расшифруй русскую речь из аудиозаписи телефонного разговора. Это заявка на автозапчасти. Сохраняй автомобильные названия и термины даже если они необычные. Используй контекст всего разговора. Особенно внимательно распознавай: Веста, Ларгус/Largus, Датсун/Дадсун/Datsun, X-Ray, Калина, 2114, 724, крыло, дверь, дверь задка, капот, лючок бензобака, петля капота, решётка, ПТФ, Тайвань, Китай, ВАЗ, Челны, ABS, NG, Sport и цвета LADA/VАЗ.
Верни только текст полной расшифровки на русском языке без комментариев.
        """.trimIndent()
        val inlineData = JSONObject().apply {
            put("mime_type", "audio/mp4")
            put("data", b64)
        }
        val parts = JSONArray()
        parts.put(JSONObject().apply { put("text", prompt) })
        parts.put(JSONObject().apply { put("inline_data", inlineData) })

        val content = JSONObject()
        content.put("parts", parts)

        val contents = JSONArray()
        contents.put(content)

        val generationConfig = JSONObject()
        generationConfig.put("temperature", 0.0)

        val body = JSONObject()
        body.put("contents", contents)
        body.put("generationConfig", generationConfig)
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 30000; readTimeout = 180000; doOutput = true
            setRequestProperty("x-goog-api-key", key); setRequestProperty("Content-Type", "application/json")
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw IllegalStateException("Gemini онлайн-расшифровка HTTP $code: ${response.take(600)}")
        val json = JSONObject(response)
        return extractText(json).trim()
    }

    private fun extractText(json: JSONObject): String {
        val candidates = json.optJSONArray("candidates") ?: return ""
        val b = StringBuilder()
        for (i in 0 until candidates.length()) {
            val content = candidates.optJSONObject(i)?.optJSONObject("content") ?: continue
            val parts = content.optJSONArray("parts") ?: continue
            for (j in 0 until parts.length()) b.append(parts.optJSONObject(j)?.optString("text").orEmpty())
        }
        return b.toString()
    }
}
