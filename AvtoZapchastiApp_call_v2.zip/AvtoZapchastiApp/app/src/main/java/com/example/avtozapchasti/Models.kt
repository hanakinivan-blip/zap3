package com.example.avtozapchasti

data class OrderRow(
    var model: String,
    var detail: String,
    var manufacturer: String,
    var color: String,
    var quantity: Int = 1,
    var done: Boolean = false
)

enum class Section(val title: String) {
    UNPAINTED("БЕЗ ЦВЕТА / НЕОКРАШЕННЫЕ"),
    METAL("МЕТАЛЛ"),
    PLASTIC("ПЛАСТИК")
}
