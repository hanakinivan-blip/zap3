package com.example.avtozapchasti

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import android.app.NotificationChannel
import android.app.NotificationManager

/** Detects call state and surfaces a notification. It never starts recording automatically. */
class PhoneStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state == TelephonyManager.EXTRA_STATE_RINGING || state == TelephonyManager.EXTRA_STATE_OFFHOOK) {
            val channelId = "incoming_call_hint"
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel(channelId, "Подсказки звонков", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            val pi = if (launch != null) {
                androidx.core.app.TaskStackBuilder.create(context).addNextIntentWithParentStack(launch).getPendingIntent(
                    7101,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or if (android.os.Build.VERSION.SDK_INT >= 23) android.app.PendingIntent.FLAG_IMMUTABLE else 0
                )
            } else null
            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle("Звонок обнаружен")
                .setContentText("Откройте Автозапчасти и нажмите «Начать расшифровку»")
                .setAutoCancel(true)
                .apply { if (pi != null) setContentIntent(pi) }
                .build()
            nm.notify(7101, notification)
        }
    }
}
