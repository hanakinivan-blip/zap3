package com.example.avtozapchasti

object OrderParser {
    private val colors = mapOf(
        "690" to "Снежная королева (690)", "снежная королева" to "Снежная королева (690)", "снежка" to "Снежная королева (690)", "снег" to "Снежная королева (690)",
        "606" to "Млечка (606)", "млечка" to "Млечка (606)", "млечный путь" to "Млечка (606)",
        "413" to "Ледяной (413)", "ледяной" to "Ледяной (413)", "618" to "Техно (618)", "техно" to "Техно (618)",
        "240" to "Белое облако (240)", "белое облако" to "Белое облако (240)", "608" to "Плутон (608)", "плутон" to "Плутон (608)",
        "610" to "Рислинг (610)", "рислинг" to "Рислинг (610)", "665" to "Космос (665)", "космос" to "Космос (665)",
        "107" to "Баклажан (107)", "баклажан" to "Баклажан (107)", "347" to "Золото инков (347)", "золото инков" to "Золото инков (347)", "золото инковский" to "Золото инков (347)", "золотынков" to "Золото инков (347)",
        "451" to "Боровница (451)", "боровница" to "Боровница (451)", "192" to "Портвейн (192)", "портвейн" to "Портвейн (192)",
        "630" to "Кварц (630)", "кварц" to "Кварц (630)", "328" to "Ницца (328)", "ницца" to "Ницца (328)",
        "672" to "Пантера (672)", "пантера" to "Пантера (672)", "633" to "Борнео (633)", "борнео" to "Борнео (633)", "барнео" to "Борнео (633)",
        "790" to "Кориандр (790)", "кориандр" to "Кориандр (790)", "691" to "Платина (691)", "платина" to "Платина (691)",
        "497" to "Одиссей (497)", "одиссей" to "Одиссей (497)", "619" to "Булат (619)", "булат" to "Булат (619)",
        "221" to "Ледниковый (221)", "ледниковый" to "Ледниковый (221)",
        "190" to "Калифорнийский мак (190)", "калифорнийский мак" to "Калифорнийский мак (190)",
        "482" to "Черника (482)", "черника" to "Черника (482)",
        "676" to "Чёрная жемчужина (676)", "чёрная жемчужина" to "Чёрная жемчужина (676)", "черная жемчужина" to "Чёрная жемчужина (676)",
        "B66" to "B66", "693" to "693"
    )

    private val tens = mapOf("двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50, "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90)
    private val ones = mapOf("один" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9)

    fun parse(text: String): List<OrderRow> {
        val source = text.trim().replace('Ё', 'Е').replace('ё', 'е')
        if (source.isBlank()) return emptyList()
        val chunks = source.split(Regex("(?i)(?=решет|крыл|капот|перед\\b|зад\\b|пороги|реснички|дверь|лючок|петл)"))
            .map { it.trim(' ', ',', '.', ':', ';') }
            .filter { it.isNotBlank() }
        val rows = mutableListOf<OrderRow>()
        for (chunk in chunks) {
            val parsed = parseChunk(chunk) ?: continue
            rows += parsed
        }
        return rows
    }

    private fun parseChunk(chunk: String): List<OrderRow>? {
        val low = chunk.lowercase()
        val model = normalizeModel(low) ?: return null
        val detail = normalizeDetail(low) ?: return null
        val manufacturer = normalizeManufacturer(low)
        val color = normalizeColor(low)
        val qty = quantity(low)
        val isFrontWings = detail == "Крылья передние"
        if (isFrontWings && low.contains("комплект")) {
            return listOf(
                OrderRow(model, "КПЛ" + suffixes(low), manufacturer, color, qty),
                OrderRow(model, "КПП" + suffixes(low), manufacturer, color, qty)
            )
        }
        return listOf(OrderRow(model, detail, manufacturer, color, qty))
    }

    private fun suffixes(low: String): String {
        val parts = mutableListOf<String>()
        if (low.contains("без поворотника")) parts += ", без поворотника"
        else if (low.contains("с поворотником")) parts += ", с поворотником"
        if (low.contains("дешев") || low.contains("дешёв")) parts += ", дешёвый"
        return parts.joinToString("")
    }

    fun section(row: OrderRow): Section {
        if (row.color.isBlank() || row.color.equals("Неокрашенный", true)) return Section.UNPAINTED
        if (row.manufacturer.contains("ABS", true)) return Section.PLASTIC
        val d = row.detail.lowercase()
        val metal = listOf("капот", "кпл", "кпп", "дпл", "дпп", "дзл", "дзп", "крышка багажника", "крыло").any { d.contains(it) }
        return if (metal) Section.METAL else Section.PLASTIC
    }

    fun sortRows(rows: List<OrderRow>): List<OrderRow> {
        val unpainted = rows.filter { section(it) == Section.UNPAINTED }
        val metal = rows.filter { section(it) == Section.METAL }
        val plastic = rows.filter { section(it) == Section.PLASTIC && !it.manufacturer.contains("ABS", true) }
        val abs = rows.filter { section(it) == Section.PLASTIC && it.manufacturer.contains("ABS", true) }
        return unpainted + metal + plastic + abs
    }

    private fun normalizeManufacturer(s: String): String {
        val found = mutableListOf<String>()
        if (Regex("\\babs\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)) found += "ABS"
        if (s.contains("тайвань")) found += "Тайвань"
        if (Regex("\\bng\\b").containsMatchIn(s)) found += "NG"
        if (s.contains("завод") || s.contains("заводской")) found += "ВАЗ"
        if (s.contains("sport")) found += "Sport"
        return found.distinct().joinToString(", ")
    }

    private fun normalizeModel(s: String): String? {
        if (Regex("720\\s*[/ -]?\\s*4", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "724"
        if (Regex("датсун|дадсун|datsun", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "95"
        if (Regex("vaz\\s*2113.*2114.*2115", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "2114"
        if (Regex("веста\\s+седан").containsMatchIn(s)) return "Vesta"
        if (Regex("калина\\s*118").containsMatchIn(s)) return "118"
        if (Regex("урбан\\s*(ptf|птф)").containsMatchIn(s)) return "Урбан ПТФ"
        if (Regex("x[- ]?ray", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "X-Ray"
        if (s.contains("largus", true)) return "Largus"
        val direct = Regex("\\b(08|09|14|15|18|19|23|70|80|90|91|92|118|704|724)\\b").find(s)
        if (direct != null) return direct.groupValues[1]
        val ordinalMap = mapOf("седьм" to 7,"восьм" to 8,"девяност" to 90,"восемнадцат" to 18,"семнадцат" to 17,"шестнадцат" to 16,"пятнадцат" to 15,"четырнадцат" to 14)
        ordinalMap.entries.firstOrNull { s.contains(it.key) }?.let { return it.value.toString() }
        var total = 0; var found = false
        for ((w, v) in tens) if (s.contains(w)) { total += v; found = true; break }
        for ((w, v) in ones) if (s.contains(w)) { total += v; found = true; break }
        if (found) return total.toString()
        return null
    }

    private fun normalizeDetail(s: String): String? {
        var d = when {
            Regex("дверь\\s+передн.*лев").containsMatchIn(s) -> "ДПЛ"
            Regex("дверь\\s+передн.*прав").containsMatchIn(s) -> "ДПП"
            Regex("дверь\\s+задн.*лев").containsMatchIn(s) -> "ДЗЛ"
            Regex("дверь\\s+задн.*прав").containsMatchIn(s) -> "ДЗП"
            Regex("крыл(о|ья)\\s+передн.*лев").containsMatchIn(s) -> "КПЛ"
            Regex("крыл(о|ья)\\s+передн.*прав").containsMatchIn(s) -> "КПП"
            Regex("крыл(о|ья)\\s+передн").containsMatchIn(s) -> "Крылья передние"
            Regex("решет.*ниж").containsMatchIn(s) -> "Решётка нижняя"
            Regex("решет.*верх").containsMatchIn(s) -> "Решётка верхняя"
            s.contains("лючок бензобака") -> "Лючок бензобака"
            s.contains("петл") && s.contains("капот") -> "Петля капота"
            s.contains("дверь задка") -> "Дверь задка"
            s.contains("капот") -> "Капот"
            s.contains("пороги") -> "Пороги"
            s.contains("реснички") -> "Реснички"
            s.contains("решет") -> "Решётка"
            s.contains("перед") -> "Перед"
            s.contains("зад") -> "Зад"
            else -> null
        } ?: return null
        if (s.contains("без поворотника")) d += ", без поворотника" else if (s.contains("с поворотником")) d += ", с поворотником"
        if (s.contains("дешев") || s.contains("дешёв")) d += ", дешёвый"
        return d
    }

    private fun normalizeColor(s: String): String {
        for ((k, v) in colors.entries.sortedByDescending { it.key.length }) if (s.contains(k.lowercase())) return v
        return if (s.contains("неокраш")) "Неокрашенный" else ""
    }

    private fun quantity(s: String): Int {
        Regex("\\b(\\d+)\\s*(шт|штук|штуки|комплект|комплекта)").find(s)?.groupValues?.get(1)?.toIntOrNull()?.let { return it }
        Regex("\\b(\\d+)\\b").find(s)?.groupValues?.get(1)?.toIntOrNull()?.let { n -> if (n in 1..20) return n }
        return 1
    }
}
