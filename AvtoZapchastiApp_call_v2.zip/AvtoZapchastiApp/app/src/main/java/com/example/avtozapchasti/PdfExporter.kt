package com.example.avtozapchasti

import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream

object PdfExporter {
    fun create(rows: List<OrderRow>): ByteArray {
        val doc = PdfDocument()
        val width = 842
        val height = 595
        var pageNumber = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNumber).create())
        var canvas = page.canvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = 0xFF111111.toInt()
        paint.textSize = 11f
        var y = 28f

        fun title(text: String, size: Float = 18f) {
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = size
            canvas.drawText(text, 28f, y, paint)
            y += size + 8f
            paint.typeface = Typeface.DEFAULT
            paint.textSize = 10f
        }
        fun newPage() {
            doc.finishPage(page)
            pageNumber++
            page = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNumber).create())
            canvas = page.canvas
            y = 28f
        }
        fun line(text: String) {
            if (y > height - 28) newPage()
            canvas.drawText(text.take(130), 28f, y, paint)
            y += 16f
        }

        title("ЗАЯВКА НА АВТОЗАПЧАСТИ")
        line("Дата: ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}")
        y += 8f

        for (section in Section.values()) {
            if (y > height - 90) newPage()
            title(section.title, 14f)
            line("Модель | Деталь | Производитель | Цвет | Количество")
            val sectionRows = OrderParser.sortRows(rows).filter { OrderParser.section(it) == section }
            if (sectionRows.isEmpty()) line("Нет позиций")
            sectionRows.forEach { r ->
                line("${r.model} | ${r.detail} | ${r.manufacturer.ifBlank { "—" }} | ${r.color.ifBlank { "—" }} | ${r.quantity}")
            }
            y += 8f
        }
        doc.finishPage(page)
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
