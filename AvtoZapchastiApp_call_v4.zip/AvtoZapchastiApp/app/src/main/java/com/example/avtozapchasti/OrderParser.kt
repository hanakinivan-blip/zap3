package com.example.avtozapchasti

/**
 * Turns conversational Russian speech into order rows.
 * The parser keeps context (last model/color/manufacturer/detail) so a customer
 * can spread one item over several phrases during a call.
 */
object OrderParser {
    private val colors = linkedMapOf(
        "снежная королева" to "Снежная королева (690)", "снежка" to "Снежная королева (690)", "снег" to "Снежная королева (690)", "690" to "Снежная королева (690)",
        "млечка" to "Млечка (606)", "млечный путь" to "Млечка (606)", "606" to "Млечка (606)",
        "ледяной" to "Ледяной (413)", "413" to "Ледяной (413)", "техно" to "Техно (618)", "618" to "Техно (618)",
        "белое облако" to "Белое облако (240)", "240" to "Белое облако (240)", "плутон" to "Плутон (608)", "608" to "Плутон (608)",
        "рислинг" to "Рислинг (610)", "610" to "Рислинг (610)", "космос" to "Космос (665)", "665" to "Космос (665)",
        "баклажан" to "Баклажан (107)", "107" to "Баклажан (107)", "золото инков" to "Золото инков (347)", "золото инковский" to "Золото инков (347)", "золотынков" to "Золото инков (347)", "347" to "Золото инков (347)",
        "боровница" to "Боровница (451)", "451" to "Боровница (451)", "портвейн" to "Портвейн (192)", "192" to "Портвейн (192)",
        "кварц" to "Кварц (630)", "630" to "Кварц (630)", "ницца" to "Ницца (328)", "328" to "Ницца (328)",
        "пантера" to "Пантера (672)", "672" to "Пантера (672)", "борнео" to "Борнео (633)", "барнео" to "Борнео (633)", "633" to "Борнео (633)",
        "кориандр" to "Кориандр (790)", "790" to "Кориандр (790)", "платина" to "Платина (691)", "691" to "Платина (691)",
        "одиссей" to "Одиссей (497)", "497" to "Одиссей (497)", "булат" to "Булат (619)", "619" to "Булат (619)",
        "ледниковый" to "Ледниковый (221)", "221" to "Ледниковый (221)", "калифорнийский мак" to "Калифорнийский мак (190)", "190" to "Калифорнийский мак (190)",
        "черника" to "Черника (482)", "482" to "Черника (482)", "чёрная жемчужина" to "Чёрная жемчужина (676)", "черная жемчужина" to "Чёрная жемчужина (676)", "676" to "Чёрная жемчужина (676)",
        "b66" to "B66", "693" to "693"
    )

    private val tens = mapOf("двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50, "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90)
    private val ones = mapOf("один" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9)

    private data class Context(
        var model: String = "",
        var manufacturer: String = "",
        var color: String = "",
        var lastDetail: String = "",
        var lastQuantity: Int = 1
    )

    fun parse(text: String): List<OrderRow> {
        val source = clean(text)
        if (source.isBlank()) return emptyList()

        val context = Context()
        val result = mutableListOf<OrderRow>()
        val utterances = source
            .split(Regex("[\\n.!?]+"))
            .flatMap { it.split(Regex("[,;]+")) }
            .map { it.trim(' ', ',', ';', ':', '-', '—') }
            .filter { it.isNotBlank() }

        for (raw in utterances) {
            val low = normalizeSpeech(raw.lowercase())

            // Context can be spoken before or after the part.
            normalizeModel(low)?.let { context.model = it }
            normalizeManufacturer(low).takeIf { it.isNotBlank() }?.let { context.manufacturer = it }
            normalizeColor(low).takeIf { it.isNotBlank() }?.let { context.color = it }

            val detail = normalizeDetail(low)
            if (detail != null) {
                val qty = quantity(low, 1)
                val manufacturer = normalizeManufacturer(low).ifBlank { context.manufacturer }
                val color = normalizeColor(low).ifBlank { context.color }
                context.manufacturer = manufacturer
                context.color = color
                context.lastDetail = detail
                context.lastQuantity = qty

                if (detail == "Крылья передние" && low.contains("комплект")) {
                    result += OrderRow(context.model, "КПЛ" + suffixes(low), manufacturer, color, qty)
                    result += OrderRow(context.model, "КПП" + suffixes(low), manufacturer, color, qty)
                } else {
                    val row = OrderRow(context.model, detail, manufacturer, color, qty)
                    result += row
                }
                continue
            }

            // Phrases such as "левое", "правое тоже", "два" continue the last part.
            val inherited = inheritedDetail(low, context.lastDetail)
            if (inherited != null) {
                val manufacturer = normalizeManufacturer(low).ifBlank { context.manufacturer }
                val color = normalizeColor(low).ifBlank { context.color }
                val qty = quantity(low, context.lastQuantity)
                result += OrderRow(context.model, inherited, manufacturer, color, qty)
                context.lastDetail = inherited
                context.lastQuantity = qty
                continue
            }

            // If a model/color/manufacturer was spoken after a position, fill the
            // most recent rows that are still missing that field.
            result.takeLast(4).forEach { row ->
                if (row.model.isBlank() && context.model.isNotBlank()) row.model = context.model
                if (row.manufacturer.isBlank() && context.manufacturer.isNotBlank()) row.manufacturer = context.manufacturer
                if (row.color.isBlank() && context.color.isNotBlank()) row.color = context.color
            }
        }

        // Final context pass: a customer commonly says the model/color after the parts.
        result.forEach { row ->
            if (row.model.isBlank()) row.model = context.model
            if (row.manufacturer.isBlank()) row.manufacturer = context.manufacturer
            if (row.color.isBlank()) row.color = context.color
        }

        return result.distinctBy { listOf(it.model, it.detail, it.manufacturer, it.color, it.quantity) }
    }

    private fun clean(s: String): String = s.trim().replace('Ё', 'Е').replace('ё', 'е')

    private fun normalizeSpeech(s: String): String {
        return s.lowercase()
            .replace("птф", "птф")
            .replace("тайваньский", "тайвань")
            .replace("тайваньская", "тайвань")
            .replace("тайваньское", "тайвань")
            .replace("снежку", "снежка")
            .replace("снежке", "снежка")
            .replace("снег", "снежка")
    }

    private fun inheritedDetail(chunk: String, last: String): String? {
        if (last.isBlank()) return null
        val low = normalizeSpeech(chunk)
        val side = when {
            Regex("\\b(лев|левая|левое|левый)\\b").containsMatchIn(low) -> "лев"
            Regex("\\b(прав|правая|правое|правый)\\b").containsMatchIn(low) -> "прав"
            else -> return null
        }
        return when {
            last.startsWith("КПЛ") || last.startsWith("КПП") -> if (side == "лев") "КПЛ" + suffixes(low) else "КПП" + suffixes(low)
            last.startsWith("ДПЛ") || last.startsWith("ДПП") -> if (side == "лев") "ДПЛ" + suffixes(low) else "ДПП" + suffixes(low)
            last.startsWith("ДЗЛ") || last.startsWith("ДЗП") -> if (side == "лев") "ДЗЛ" + suffixes(low) else "ДЗП" + suffixes(low)
            else -> last
        }
    }

    private fun suffixes(low: String): String {
        val parts = mutableListOf<String>()
        if (low.contains("без поворотника")) parts += ", без поворотника"
        else if (low.contains("с поворотником")) parts += ", с поворотником"
        if (low.contains("дешев") || low.contains("дешевый")) parts += ", дешёвый"
        return parts.joinToString("")
    }

    private fun normalizeDetail(s: String): String? {
        val low = normalizeSpeech(s)
        var d: String? = when {
            // Doors: accept both "дверь передняя левая" and "левая передняя дверь".
            Regex("двер[ьи]? .*\\b(передн|передняя|переднее).*\\b(лев|левая|левое)").containsMatchIn(low) ||
                Regex("\\b(лев|левая|левое).*\\b(передн|передняя).*двер").containsMatchIn(low) -> "ДПЛ"
            Regex("двер[ьи]? .*\\b(передн|передняя|переднее).*\\b(прав|правая|правое)").containsMatchIn(low) ||
                Regex("\\b(прав|правая|правое).*\\b(передн|передняя).*двер").containsMatchIn(low) -> "ДПП"
            Regex("двер[ьи]? .*\\b(задн|задняя|заднее).*\\b(лев|левая|левое)").containsMatchIn(low) ||
                Regex("\\b(лев|левая|левое).*\\b(задн|задняя).*двер").containsMatchIn(low) -> "ДЗЛ"
            Regex("двер[ьи]? .*\\b(задн|задняя|заднее).*\\b(прав|правая|правое)").containsMatchIn(low) ||
                Regex("\\b(прав|правая|правое).*\\b(задн|задняя).*двер").containsMatchIn(low) -> "ДЗП"

            // Front fenders: most common speech forms.
            Regex("\\b(крыл[оья]*|крыло|крылья)\\b.*\\b(передн|передняя|переднее)\\b.*\\b(лев|левая|левое)").containsMatchIn(low) ||
                Regex("\\b(передн|передняя|переднее)\\b.*\\b(лев|левая|левое)\\b.*\\bкрыл").containsMatchIn(low) ||
                Regex("\\b(лев|левая|левое)\\b.*\\b(передн|передняя|переднее)\\b.*\\bкрыл").containsMatchIn(low) -> "КПЛ"
            Regex("\\b(крыл[оья]*|крыло|крылья)\\b.*\\b(передн|передняя|переднее)\\b.*\\b(прав|правая|правое)").containsMatchIn(low) ||
                Regex("\\b(передн|передняя|переднее)\\b.*\\b(прав|правая|правое)\\b.*\\bкрыл").containsMatchIn(low) ||
                Regex("\\b(прав|правая|правое)\\b.*\\b(передн|передняя|переднее)\\b.*\\bкрыл").containsMatchIn(low) -> "КПП"
            Regex("\\b(передн|передняя|переднее)\\b.*\\bкрыл").containsMatchIn(low) || low.contains("крылья передние") || low.contains("передние крылья") -> "Крылья передние"
            Regex("\\b(лев|левая|левое|левый)\\b.*\\bкрыл").containsMatchIn(low) -> "КПЛ"
            Regex("\\b(прав|правая|правое|правый)\\b.*\\bкрыл").containsMatchIn(low) -> "КПП"

            low.contains("решетка ниж") || low.contains("решётка ниж") -> "Решётка нижняя"
            low.contains("решетка верх") || low.contains("решётка верх") -> "Решётка верхняя"
            low.contains("лючок бензобака") || low.contains("лючок бака") -> "Лючок бензобака"
            low.contains("петля капот") -> "Петля капота"
            low.contains("дверь задка левая глухая") -> "Дверь задка левая глухая"
            low.contains("дверь задка") -> "Дверь задка"
            low.contains("капот") -> "Капот"
            low.contains("пороги") -> "Пороги"
            low.contains("реснички") -> "Реснички"
            low.contains("решетка") || low.contains("решётка") -> "Решётка"
            else -> null
        }
        if (d == null) return null
        if (low.contains("без поворотника")) d += ", без поворотника"
        else if (low.contains("с поворотником")) d += ", с поворотником"
        if (low.contains("дешев") || low.contains("дешевый")) d += ", дешёвый"
        return d
    }

    fun section(row: OrderRow): Section {
        if (row.color.isBlank() || row.color.equals("Неокрашенный", true)) return Section.UNPAINTED
        if (row.manufacturer.contains("ABS", true)) return Section.PLASTIC
        val d = row.detail.lowercase()
        val metal = listOf("капот", "кпл", "кпп", "дпл", "дпп", "дзл", "дзп", "крышка багажника", "крыло").any { d.contains(it) }
        return if (metal) Section.METAL else Section.PLASTIC
    }

    fun sortRows(rows: List<OrderRow>): List<OrderRow> {
        val unpainted = rows.filter { section(it) == Section.UNPAINTED }
        val metal = rows.filter { section(it) == Section.METAL }
        val plastic = rows.filter { section(it) == Section.PLASTIC && !it.manufacturer.contains("ABS", true) }
        val abs = rows.filter { section(it) == Section.PLASTIC && it.manufacturer.contains("ABS", true) }
        return unpainted + metal + plastic + abs
    }

    private fun normalizeManufacturer(s: String): String {
        val found = mutableListOf<String>()
        if (Regex("\\babs\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)) found += "ABS"
        if (s.contains("тайвань")) found += "Тайвань"
        if (Regex("\\bng\\b").containsMatchIn(s)) found += "NG"
        if (s.contains("завод") || s.contains("заводской")) found += "ВАЗ"
        if (s.contains("sport")) found += "Sport"
        return found.distinct().joinToString(", ")
    }

    private fun normalizeModel(s: String): String? {
        if (Regex("720\\s*[/ -]?\\s*4|четвертый\\s*ряд|4[- ]й", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "724"
        if (Regex("датсун|дадсун|datsun", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "95"
        if (Regex("vaz\\s*2113.*2114.*2115", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "2114"
        if (Regex("веста(?:\\s+седан)?").containsMatchIn(s)) return "Vesta"
        if (Regex("калина\\s*118").containsMatchIn(s)) return "118"
        if (Regex("урбан\\s*(ptf|птф)").containsMatchIn(s)) return "Урбан ПТФ"
        if (Regex("x[- ]?ray", RegexOption.IGNORE_CASE).containsMatchIn(s)) return "X-Ray"
        if (s.contains("largus", true) || s.contains("ларгус")) return "Largus"
        Regex("\\b(08|09|14|15|18|19|23|70|80|90|91|92|118|704|724)\\b").find(s)?.let { return it.groupValues[1] }
        return null
    }


    private fun normalizeColor(s: String): String {
        for ((k, v) in colors.entries.sortedByDescending { it.key.length }) if (s.contains(k)) return v
        return if (s.contains("неокраш")) "Неокрашенный" else ""
    }

    private fun quantity(s: String, fallback: Int): Int {
        Regex("\\b(\\d+)\\s*(шт|штук|штуки|комплект|комплекта)\\b").find(s)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(1, 99) }
        Regex("\\b(\\d+)\\b").find(s)?.groupValues?.get(1)?.toIntOrNull()?.let { n -> if (n in 1..99 && !isColorCode(s, n)) return n }
        for ((w, v) in ones) if (Regex("\\b${Regex.escape(w)}\\b").containsMatchIn(s)) return v
        for ((w, v) in tens) if (Regex("\\b${Regex.escape(w)}\\b").containsMatchIn(s)) return v
        return if (s.contains("комплект")) fallback else 1
    }

    private fun isColorCode(s: String, n: Int): Boolean = n in listOf(190,192,221,240,328,347,413,426,429,451,482,497,606,608,610,618,619,630,633,665,672,676,690,691,693,790)
}
