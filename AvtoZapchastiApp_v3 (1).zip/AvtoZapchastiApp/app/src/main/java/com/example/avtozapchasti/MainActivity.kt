package com.example.avtozapchasti

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("orders", MODE_PRIVATE) }
    private val rows = mutableListOf<OrderRow>()
    private lateinit var container: LinearLayout
    private lateinit var status: TextView
    private var speechRecognizer: SpeechRecognizer? = null
    private val recordRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.tablesContainer)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.conversationButton).setOnClickListener { startActivity(Intent(this, ConversationActivity::class.java)) }
        findViewById<Button>(R.id.voiceButton).setOnClickListener { startVoiceFlow() }
        findViewById<Button>(R.id.manualButton).setOnClickListener { showEditor(null) }
        findViewById<Button>(R.id.newButton).setOnClickListener { newOrder() }
        findViewById<Button>(R.id.exportButton).setOnClickListener { exportCsv() }
        findViewById<Button>(R.id.pdfButton).setOnClickListener { printPdf() }

        load()
        render()
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        super.onDestroy()
    }

    private fun newOrder() {
        rows.clear()
        save()
        render()
        Toast.makeText(this, "Новая заявка", Toast.LENGTH_SHORT).show()
    }

    private fun startVoiceFlow() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Распознавание речи недоступно на этом устройстве", Toast.LENGTH_LONG).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), recordRequest)
            return
        }
        val input = EditText(this)
        input.hint = "Распознанный текст"
        input.minLines = 5
        input.gravity = Gravity.TOP
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 10, 30, 0) }
        val start = Button(this).apply { text = "🎙 Начать диктовку" }
        box.addView(start)
        box.addView(input, LinearLayout.LayoutParams(-1, -2))
        val dialog = AlertDialog.Builder(this).setTitle("Голосовая заявка").setView(box)
            .setPositiveButton("Добавить позиции", null).setNegativeButton("Закрыть", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val parsed = OrderParser.parse(input.text.toString())
                if (parsed.isEmpty()) Toast.makeText(this, "Не удалось распознать позиции", Toast.LENGTH_SHORT).show()
                else {
                    rows.addAll(parsed)
                    save(); render(); dialog.dismiss()
                }
            }
        }
        start.setOnClickListener { recognizeInto(input) }
        dialog.show()
    }

    private fun recognizeInto(target: EditText) {
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Слушаю… Нажмите кнопку диктовки только когда готовы говорить." }
            override fun onBeginningOfSpeech() { status.text = "Речь распознаётся…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Распознавание завершено" }
            override fun onError(error: Int) { status.text = "Ошибка распознавания: $error" }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                target.setText(text)
                target.setSelection(target.text.length)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) target.setText(text)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun showEditor(index: Int?) {
        val old = index?.let { rows[it] }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(25, 4, 25, 0) }
        val labels = listOf("Модель", "Деталь", "Производитель", "Цвет", "Количество")
        val fields = labels.map { hint -> EditText(this).apply { this.hint = hint; setSingleLine(false) } }
        old?.let { r ->
            fields[0].setText(r.model); fields[1].setText(r.detail); fields[2].setText(r.manufacturer); fields[3].setText(r.color); fields[4].setText(r.quantity.toString())
        } ?: fields[4].setText("1")
        fields.forEach { layout.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        val title = if (old == null) "Новая позиция" else "Редактирование"
        AlertDialog.Builder(this).setTitle(title).setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                val r = OrderRow(fields[0].text.toString().trim(), fields[1].text.toString().trim(), fields[2].text.toString().trim(), fields[3].text.toString().trim(), fields[4].text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1, old?.done ?: false)
                if (index == null) rows.add(r) else rows[index] = r
                save(); render()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun render() {
        val sorted = OrderParser.sortRows(rows)
        rows.clear(); rows.addAll(sorted)
        container.removeAllViews()
        for (section in Section.values()) {
            val title = TextView(this).apply {
                text = section.title; textSize = 19f; setTypeface(typeface, Typeface.BOLD); setPadding(4, 20, 4, 8)
            }
            container.addView(title)
            val sectionRows = rows.filter { OrderParser.section(it) == section }
            if (sectionRows.isEmpty()) {
                container.addView(TextView(this).apply { text = "Нет позиций"; setPadding(8, 6, 8, 12); setTextColor(0xFF777777.toInt()) })
            } else sectionRows.forEach { row -> container.addView(rowView(row)) }
        }
        status.text = "Позиций: ${rows.size}"
    }

    private fun rowView(row: OrderRow): View {
        val idx = rows.indexOf(row)
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8); setBackgroundColor(0xFFFFFFFF.toInt()) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val check = CheckBox(this).apply { isChecked = row.done }
        check.setOnCheckedChangeListener { _, checked -> row.done = checked; save(); render() }
        val text = TextView(this).apply {
            text = "${row.model} • ${row.detail}\n${row.manufacturer.ifBlank { "—" }} • ${row.color.ifBlank { "—" }} • Кол-во: ${row.quantity}"
            textSize = 15f; setPadding(4, 0, 4, 0); setTextColor(if (row.done) 0xFF999999.toInt() else 0xFF111111.toInt())
            if (row.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        }
        top.addView(check, LinearLayout.LayoutParams(48, -2))
        top.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        val edit = Button(this).apply { text = "✎"; setOnClickListener { showEditor(idx) } }
        val del = Button(this).apply { text = "🗑"; setOnClickListener { rows.remove(row); save(); render() } }
        top.addView(edit); top.addView(del)
        outer.addView(top)
        return outer
    }

    private fun save() {
        val a = JSONArray()
        rows.forEach { r ->
            a.put(JSONObject().apply {
                put("model", r.model); put("detail", r.detail); put("manufacturer", r.manufacturer); put("color", r.color); put("quantity", r.quantity); put("done", r.done)
            })
        }
        prefs.edit().putString("rows", a.toString()).apply()
    }

    private fun load() {
        rows.clear()
        val raw = prefs.getString("rows", null) ?: return
        runCatching {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                rows.add(OrderRow(o.optString("model"), o.optString("detail"), o.optString("manufacturer"), o.optString("color"), o.optInt("quantity",1), o.optBoolean("done")))
            }
        }
    }

    private fun exportCsv() {
        val sb = StringBuilder("Модель;Деталь;Производитель;Цвет;Количество\n")
        rows.forEach { r -> sb.append(csv(r.model)).append(';').append(csv(r.detail)).append(';').append(csv(r.manufacturer)).append(';').append(csv(r.color)).append(';').append(r.quantity).append('\n') }
        val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "avtozapchasti_${System.currentTimeMillis()}.csv")
        file.parentFile?.mkdirs(); file.writeText(sb.toString(), Charsets.UTF_8)
        Toast.makeText(this, "CSV сохранён: ${file.name}", Toast.LENGTH_LONG).show()
    }

    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    private fun printPdf() {
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print("Автозапчасти", object : PrintDocumentAdapter() {
            override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes, cancellationSignal: android.os.CancellationSignal?, callback: LayoutResultCallback, extras: Bundle?) {
                val info = PrintDocumentInfo.Builder("avtozapchasti.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build()
                callback.onLayoutFinished(info, true)
            }
            override fun onWrite(pageRanges: Array<android.print.PageRange>, destination: android.os.ParcelFileDescriptor, cancellationSignal: android.os.CancellationSignal, callback: WriteResultCallback) {
                val doc = PdfDocument(); val pageInfo = PdfDocument.PageInfo.Builder(842, 595, 1).create(); val page = doc.startPage(pageInfo); val c = page.canvas
                val p = Paint().apply { color = 0xFF111111.toInt(); textSize = 13f; typeface = Typeface.DEFAULT }
                var y = 28f; p.textSize = 18f; p.typeface = Typeface.DEFAULT_BOLD; c.drawText("Автозапчасти", 28f, y, p); y += 26f
                p.textSize = 11f; p.typeface = Typeface.DEFAULT
                for (section in Section.values()) {
                    if (y > 555f) break
                    p.typeface = Typeface.DEFAULT_BOLD; c.drawText(section.title, 28f, y, p); y += 17f; p.typeface = Typeface.DEFAULT
                    c.drawText("Модель   Деталь   Производитель   Цвет   Количество", 28f, y, p); y += 15f
                    for (r in rows.filter { OrderParser.section(it) == section }) {
                        val line = "${r.model} | ${r.detail} | ${r.manufacturer.ifBlank { "—" }} | ${r.color.ifBlank { "—" }} | ${r.quantity}"
                        c.drawText(line.take(125), 28f, y, p); y += 14f
                        if (y > 570f) break
                    }
                    y += 8f
                }
                doc.finishPage(page)
                FileOutputStream(destination.fileDescriptor).use { doc.writeTo(it) }
                doc.close(); callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            }
        }, null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == recordRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startVoiceFlow()
        else if (requestCode == recordRequest) Toast.makeText(this, "Нужен доступ к микрофону для диктовки", Toast.LENGTH_LONG).show()
    }
}
