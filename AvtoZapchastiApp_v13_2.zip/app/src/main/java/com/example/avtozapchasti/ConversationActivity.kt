package com.example.avtozapchasti

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import java.util.Locale

class ConversationActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var orderContainer: LinearLayout
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private val handler = Handler(Looper.getMainLooper())
    private val requestMic = 3001
    private val transcriptLines = mutableListOf<String>()
    private val rows = mutableListOf<OrderRow>()
    private var aiPending = false
    private var aiLastTranscript = ""
    private val aiRunnable = Runnable { runAiAnalysis(false) }
    private var audioRecorder: CallAudioRecorder? = null
    private var cloudTranscriptionPending = false
    private var voiceEditMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversation)
        status = findViewById(R.id.status)
        transcript = findViewById(R.id.transcript)
        orderContainer = findViewById(R.id.orderContainer)

        findViewById<Button>(R.id.startButton).setOnClickListener { startSession() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopSession() }
        findViewById<Button>(R.id.clearButton).setOnClickListener { transcriptLines.clear(); rows.clear(); renderAll() }
        findViewById<Button>(R.id.orderButton).setOnClickListener { buildOrder() }
                findViewById<Button>(R.id.aiButton).setOnClickListener { runAiAnalysis(true) }
        findViewById<Button>(R.id.aiSettingsButton).setOnClickListener { showAiSettings() }
        findViewById<Button>(R.id.cloudButton).setOnClickListener { runCloudTranscription() }
        findViewById<Button>(R.id.voiceEditButton).setOnClickListener { startVoiceEdit() }
        styleButtons()

        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) audio.isSpeakerphoneOn = true
        status.text = when {
            Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this) -> "Готово. Офлайн-распознавание доступно. Включите громкую связь и нажмите «Начать»."
            SpeechRecognizer.isRecognitionAvailable(this) -> "Готово. Встроенное распознавание доступно, но офлайн-модель не установлена. Для автономной работы установите русский офлайн-язык в службе распознавания Samsung/Google."
            else -> "На телефоне нет службы распознавания речи."
        }
    }

    private fun styleButtons() {
        val ids = intArrayOf(R.id.startButton, R.id.stopButton, R.id.clearButton, R.id.orderButton, R.id.savePdfButton, R.id.aiButton, R.id.aiSettingsButton, R.id.cloudButton, R.id.voiceEditButton)
        ids.forEach { id ->
            findViewById<Button>(id).apply {
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 28f
                    setColor(Color.rgb(35, 35, 35))
                    setStroke(1, Color.rgb(80, 80, 80))
                }
                minHeight = 52
                elevation = 3f
            }
        }
    }

    private fun startSession() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestMic)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Распознавание речи недоступно"
            return
        }
        listening = true
        startService(Intent(this, CallAwareForegroundService::class.java))
        audioRecorder = CallAudioRecorder(cacheDir)
        val recordingStarted = audioRecorder?.start() == true
        if (!recordingStarted) status.text = "⚠ Не удалось начать запись для онлайн-расшифровки; локальное распознавание продолжится."
        status.text = "🎙 Слушаю звонок…"
        listenOnce()
    }

    private fun listenOnce() {
        if (!listening) return
        recognizer?.destroy()
        // Prefer the standard Android recognizer: on Samsung it can use the
        // installed network/cloud language model, which is often substantially
        // more accurate for automotive terms than the small offline model.
        // The parser itself remains fully local and does not require internet.
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "🎙 Слушаю…" }
            override fun onBeginningOfSpeech() { status.text = "Речь распознаётся…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                if (listening) handler.postDelayed({ listenOnce() }, 400)
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (text.isNotBlank()) {
                    if (voiceEditMode) {
                        applyVoiceEdit(text)
                    } else {
                        addTranscript(text)
                    }
                }
                if (listening && !voiceEditMode) handler.postDelayed({ listenOnce() }, 120)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                if (text.isNotBlank()) status.text = "🎙 $text"
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(intent)
    }

    private fun addTranscript(text: String) {
        if (text.isBlank()) return
        if (transcriptLines.lastOrNull()?.equals(text, ignoreCase = true) != true) transcriptLines += text
        transcript.text = transcriptLines.joinToString("\n\n")
        buildOrder()
        scheduleAiAnalysis()
    }

    private fun scheduleAiAnalysis() {
        if (!AiProviderManager.hasAnyKey(this)) return
        val full = transcriptLines.joinToString(" ").trim()
        if (full.length < 4 || full == aiLastTranscript) return
        handler.removeCallbacks(aiRunnable)
        handler.postDelayed(aiRunnable, 1200)
    }

    private fun runAiAnalysis(manual: Boolean) {
        val full = transcriptLines.joinToString(" ").trim()
        if (full.isBlank()) {
            if (manual) Toast.makeText(this, "Сначала нужна расшифровка", Toast.LENGTH_SHORT).show()
            return
        }
        if (!AiProviderManager.hasAnyKey(this)) {
            if (manual) showAiSettings()
            else {
                buildOrder()
                status.text = "Локальный анализ: ${rows.size} поз."
            }
            return
        }
        if (aiPending) return
        aiPending = true
        aiLastTranscript = full
        status.text = "🤖 AI анализирует…"
        AiProviderManager.analyzeAsync(this, full) { result ->
            aiPending = false
            if (result.rows.isNotEmpty()) {
                val local = OrderParser.parseWithUnknowns(this, full)
                rows.clear()
                rows.addAll(result.rows)
                // Never lose unresolved local positions: keep them visible as ???.
                local.filter { it.detail == "???" }.forEach { unknown ->
                    if (rows.none { it.model == unknown.model && it.detail == "???" && it.color == unknown.color && it.manufacturer == unknown.manufacturer }) rows += unknown
                }
                renderOrder()
                val warning = result.warning?.let { " • $it" }.orEmpty()
                status.text = "🤖 ${result.source}: позиций ${rows.size}$warning"
            } else {
                val local = OrderParser.parseWithUnknowns(this, full)
                rows.clear()
                rows.addAll(local)
                renderOrder()
                status.text = if (local.isEmpty()) {
                    "Расшифровка получена, но позиция не определена. Можно добавить вручную."
                } else {
                    "Локальный анализ: позиций ${rows.size}"
                }
            }
        }
    }

    private fun startVoiceEdit() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "Сначала сформируйте заявку", Toast.LENGTH_SHORT).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestMic)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Распознавание речи недоступно", Toast.LENGTH_SHORT).show()
            return
        }
        voiceEditMode = true
        listening = false
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        status.text = "🎙 Скажите команду: «у второй позиции производитель Тайвань»"
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() { status.text = "🎙 Слушаю команду…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { voiceEditMode = false; recognizer?.destroy(); recognizer = null; status.text = "Команда не распознана. Попробуйте ещё раз." }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) applyVoiceEdit(text) else status.text = "Команда не распознана."
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        })
    }

    private fun applyVoiceEdit(commandText: String) {
        voiceEditMode = false
        recognizer?.destroy(); recognizer = null
        val command = VoiceEditParser.parse(commandText, rows)
        when (command.action) {
            VoiceEditParser.Action.EDIT -> {
                val idx = command.rowIndex
                if (idx !in rows.indices || command.field == null) {
                    status.text = "Не удалось понять, какую позицию изменить: $commandText"
                    return
                }
                val row = rows[idx]
                when (command.field) {
                    VoiceEditParser.Field.MODEL -> row.model = normalizeVoiceValue(command.value)
                    VoiceEditParser.Field.DETAIL -> row.detail = normalizeVoiceValue(command.value)
                    VoiceEditParser.Field.MANUFACTURER -> row.manufacturer = normalizeVoiceValue(command.value)
                    VoiceEditParser.Field.COLOR -> row.color = normalizeVoiceValue(command.value)
                    VoiceEditParser.Field.QUANTITY -> row.quantity = parseVoiceNumber(command.value)
                }
                LearnedStore.add(this, row)
                renderOrder()
                status.text = "✓ Позиция ${idx + 1} исправлена голосом. Новое значение сохранено в базе."
            }
            VoiceEditParser.Action.DELETE -> {
                if (command.rowIndex in rows.indices) {
                    rows.removeAt(command.rowIndex); renderOrder(); status.text = "✓ Позиция удалена голосом."
                } else status.text = "Не удалось определить позицию для удаления."
            }
            VoiceEditParser.Action.ADD -> {
                val parsed = OrderParser.parseWithUnknowns(this, commandText.replace(Regex("^.*?добав(?:ь|ить)\\s*"), ""))
                if (parsed.isNotEmpty()) {
                    parsed.forEach { candidate ->
                        if (rows.none { it.model == candidate.model && it.detail == candidate.detail && it.manufacturer == candidate.manufacturer && it.color == candidate.color && it.quantity == candidate.quantity }) rows += candidate
                    }
                    renderOrder(); status.text = "✓ Позиция добавлена голосом."
                }
                else status.text = "Не удалось распознать новую позицию."
            }
            VoiceEditParser.Action.UNKNOWN -> status.text = "Не понял команду. Пример: «у второй позиции производитель Тайвань»."
        }
    }

    private fun normalizeVoiceValue(value: String): String {
        val v = value.trim()
        return when {
            v == "???" || v.contains("неизвест", true) -> "???"
            else -> v.replace("тайван", "Тайвань", true).replace("завод", "ВАЗ", true)
        }
    }

    private fun parseVoiceNumber(value: String): Int {
        val digits = Regex("\\d+").find(value)?.value?.toIntOrNull()
        if (digits != null) return digits.coerceIn(1, 99)
        val words = mapOf("один" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10)
        return words[value.lowercase().replace('ё','е').trim()]?.coerceIn(1,99) ?: 1
    }

    private fun runCloudTranscription() {
        val file = audioRecorder?.currentFile
        if (file != null) {
            Toast.makeText(this, "Сначала нажмите Стоп", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Онлайн-расшифровка выполняется автоматически после остановки записи.", Toast.LENGTH_LONG).show()
    }

    private fun showAiSettings() {
        val openAi = EditText(this).apply {
            hint = "OpenAI API key"
            setSingleLine(true)
            setText(AiProviderManager.getOpenAiKey(this@ConversationActivity))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val gemini = EditText(this).apply {
            hint = "Gemini API key"
            setSingleLine(true)
            setText(AiProviderManager.getGeminiKey(this@ConversationActivity))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val provider = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
        }
        val choices = listOf(
            "Авто — Gemini → ChatGPT → локально" to AiProviderManager.Provider.AUTO,
            "Gemini → ChatGPT → локально" to AiProviderManager.Provider.GEMINI,
            "ChatGPT → Gemini → локально" to AiProviderManager.Provider.CHATGPT
        )
        choices.forEach { (label, value) ->
            val rb = RadioButton(this).apply { text = label; setTextColor(Color.WHITE); tag = value }
            rb.isChecked = AiProviderManager.getProvider(this@ConversationActivity) == value
            provider.addView(rb)
        }
        val web = CheckBox(this).apply {
            text = "Разрешить AI искать информацию в интернете"
            setTextColor(Color.WHITE)
            isChecked = AiProviderManager.webSearchEnabled(this@ConversationActivity)
        }
        val cloud = CheckBox(this).apply {
            text = "После звонка делать онлайн-расшифровку"
            setTextColor(Color.WHITE)
            isChecked = AiProviderManager.cloudEnabled(this@ConversationActivity)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 0, 24, 0)
        }
        box.addView(TextView(this).apply { text = "OpenAI / ChatGPT"; setTextColor(Color.WHITE) })
        box.addView(openAi)
        box.addView(TextView(this).apply { text = "Google Gemini"; setTextColor(Color.WHITE); setPadding(0, 14, 0, 0) })
        box.addView(gemini)
        box.addView(TextView(this).apply { text = "Порядок AI"; setTextColor(Color.WHITE); setPadding(0, 14, 0, 0) })
        box.addView(provider)
        box.addView(web)
        box.addView(cloud)

        AlertDialog.Builder(this)
            .setTitle("AI и онлайн-распознавание")
            .setMessage("Можно сохранить оба ключа. При ошибке квоты, региона или сети приложение автоматически переключится на другой AI, затем на локальный анализ.")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ ->
                AiProviderManager.setOpenAiKey(this, openAi.text.toString())
                AiProviderManager.setGeminiKey(this, gemini.text.toString())
                val checked = provider.findViewWithTag<RadioButton>(provider.checkedRadioButtonId)
                (checked?.tag as? AiProviderManager.Provider)?.let { AiProviderManager.setProvider(this, it) }
                AiProviderManager.setWebSearch(this, web.isChecked)
                AiProviderManager.setCloudEnabled(this, cloud.isChecked)
                Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun stopSession() {
        listening = false
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        val recordedFile = audioRecorder?.stop()
        audioRecorder = null
        stopService(Intent(this, CallAwareForegroundService::class.java))

        if (recordedFile != null && AiProviderManager.cloudEnabled(this) && AiProviderManager.hasAnyKey(this)) {
            status.text = "☁ Онлайн-расшифровка…"
            AiProviderManager.transcribeAsync(this, recordedFile) { result ->
                recordedFile.delete()
                if (result.text.isNotBlank()) {
                    transcriptLines.clear()
                    transcriptLines += result.text
                    transcript.text = result.text
                    buildOrder()
                    runAiAnalysis(true)
                    status.text = "☁ ${result.source}: онлайн-расшифровка завершена"
                } else {
                    buildOrder()
                    status.text = result.warning ?: "Онлайн недоступен. Продолжаем с локальной расшифровкой."
                    if (rows.isNotEmpty()) status.text = status.text.toString() + " Позиций: ${rows.size}"
                }
            }
        } else {
            buildOrder()
            status.text = if (rows.isEmpty()) {
                if (transcriptLines.isEmpty()) "Остановлено. Речь не была распознана."
                else "Речь распознана. Позиция пока не определена — можно продолжить разговор или добавить вручную."
            } else "Остановлено. Позиций: ${rows.size}. Заявку можно редактировать и сохранить."
        }
    }

    private fun buildOrder() {
        val parsed = OrderParser.parseWithUnknowns(this, transcriptLines.joinToString(" "))
        rows.clear()
        rows.addAll(parsed)
        renderOrder()
        status.text = if (rows.isEmpty()) "Позиции пока не найдены. Продолжайте разговор или проверьте расшифровку." else "Позиций: ${rows.size}"
    }

    private fun renderAll() {
        transcript.text = transcriptLines.joinToString("\n\n")
        renderOrder()
    }

    private fun renderOrder() {
        orderContainer.removeAllViews()
        val sorted = OrderParser.sortRows(rows)
        for (section in Section.values()) {
            val heading = TextView(this).apply { text = section.title; textSize = 17f; setPadding(0, 14, 0, 6) }
            orderContainer.addView(heading)
            sorted.filter { OrderParser.section(it) == section }.forEach { row -> orderContainer.addView(rowView(row)) }
        }
    }

    private fun rowView(row: OrderRow): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4, 4, 4, 4) }
        val text = TextView(this).apply { text = "${row.model} | ${row.detail} | ${row.manufacturer.ifBlank { "—" }} | ${row.color.ifBlank { "—" }} | ${row.quantity}"; textSize = 14f }
        val edit = Button(this).apply { setText("✎"); setOnClickListener { editRow(row) } }
        box.addView(text, LinearLayout.LayoutParams(0, -2, 1f)); box.addView(edit)
        return box
    }

    private fun editRow(row: OrderRow) {
        val fields = listOf("Модель", "Деталь", "Производитель", "Цвет", "Количество").map { EditText(this).apply { hint = it } }
        fields[0].setText(row.model); fields[1].setText(row.detail); fields[2].setText(row.manufacturer); fields[3].setText(row.color); fields[4].setText(row.quantity.toString())
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 24, 0) }; fields.forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle("Редактирование позиции").setView(box).setPositiveButton("Сохранить") { _, _ ->
            row.model = fields[0].text.toString().trim(); row.detail = fields[1].text.toString().trim(); row.manufacturer = fields[2].text.toString().trim(); row.color = fields[3].text.toString().trim(); row.quantity = fields[4].text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1; renderOrder()
        }.setNegativeButton("Отмена", null).show()
    }

    private fun savePdf() {
        if (rows.isEmpty()) {
            Toast.makeText(this, "Сначала сформируйте заявку", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            val base = FileStore.baseName()
            val paths = FileStore.saveThreePdfs(this, rows)
            val json = JSONArray().apply {
                rows.forEach { r ->
                    put(org.json.JSONObject().apply {
                        put("model", r.model)
                        put("detail", r.detail)
                        put("manufacturer", r.manufacturer)
                        put("color", r.color)
                        put("quantity", r.quantity)
                        put("done", r.done)
                    })
                }
            }.toString(2)
            FileStore.saveJson(this, json, base)
            Toast.makeText(this, "Созданы 3 PDF в Documents/AvtoZapchasti", Toast.LENGTH_LONG).show()
        }.onFailure {
            Toast.makeText(this, "Ошибка сохранения: ${it.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() { listening = false; recognizer?.destroy(); recognizer = null; audioRecorder?.stop()?.delete(); audioRecorder = null; handler.removeCallbacksAndMessages(null); super.onDestroy() }
}
