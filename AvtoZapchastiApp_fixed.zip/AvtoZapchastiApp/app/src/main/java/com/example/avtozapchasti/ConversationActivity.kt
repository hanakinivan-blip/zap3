package com.example.avtozapchasti

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.lang.reflect.Method
import java.lang.reflect.Modifier
import java.util.concurrent.Executors
import kotlin.math.sqrt

/**
 * Conversation mode.
 *
 * The app records 16 kHz mono microphone PCM and uses the optional Soniqo on-device
 * speech SDK for transcription + speaker verification. The user's own voice is enrolled
 * once, then each utterance is compared against that voice embedding. This is 1:1 speaker
 * verification ("me" vs "someone else"), which matches the product requirement better than
 * generic multi-speaker clustering.
 *
 * The integration uses reflection around the Soniqo SDK so the rest of the app remains
 * independent of the SDK's internal package layout. If the SDK/model is unavailable,
 * the screen stays usable and asks the user to retry after model download.
 */
class ConversationActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var transcriptContainer: LinearLayout

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var recorder: AudioRecord? = null
    private var recording = false
    private val sampleRate = 16_000
    private var userVoice: FloatArray? = null
    private val turns = mutableListOf<ConversationTurn>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversation)
        status = findViewById<TextView>(R.id.status)
        transcriptContainer = findViewById<LinearLayout>(R.id.transcriptContainer)

        findViewById<Button>(R.id.enrollButton).setOnClickListener { enrollUserVoice() }
        findViewById<Button>(R.id.startButton).setOnClickListener { startConversation() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopConversation() }
        findViewById<Button>(R.id.orderButton).setOnClickListener { makeOrderFromCustomerSpeech() }

        loadProfile()
        updateStatus()
    }

    override fun onDestroy() {
        stopConversation()
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun ensureMic(onGranted: () -> Unit) {
        if (hasMic()) onGranted() else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5001)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 5001 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Микрофон разрешён. Нажмите кнопку ещё раз.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun enrollUserVoice() = ensureMic {
        if (recording) return@ensureMic
        recording = true
        status.text = "Записываю образец голоса… Говорите 4–5 секунд."
        executor.execute {
            val audio = captureForMillis(5000)
            val embedding = runCatching { SoniqoBridge.embed(this, audio) }.getOrNull()
            main.post {
                recording = false
                if (embedding == null || embedding.isEmpty()) {
                    status.text = "Не удалось получить голосовой профиль. Проверьте интернет/скачивание моделей и повторите."
                } else {
                    userVoice = embedding
                    saveProfile()
                    status.text = "Профиль моего голоса сохранён."
                }
            }
        }
    }

    private fun startConversation() = ensureMic {
        if (recording) return@ensureMic
        if (userVoice == null) {
            Toast.makeText(this, "Сначала запишите образец своего голоса.", Toast.LENGTH_LONG).show()
            return@ensureMic
        }
        startForegroundCaptureService()
        recording = true
        turns.clear()
        renderTurns()
        status.text = "Разговор идёт. Приложение определяет: Я / Собеседник."
        executor.execute { conversationLoop() }
    }

    private fun stopConversation() {
        recording = false
        stopForegroundCaptureService()
        recorder?.let {
            try { if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) it.stop() } catch (_: Exception) {}
            it.release()
        }
        recorder = null
        main.post { updateStatus() }
    }


    private fun startForegroundCaptureService() {
        val intent = Intent(this, CallAwareForegroundService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun stopForegroundCaptureService() {
        stopService(Intent(this, CallAwareForegroundService::class.java))
    }

    private fun conversationLoop() {
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufferSize = maxOf(minBuffer, sampleRate / 2)
        val ar = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        recorder = ar
        val buffer = ShortArray(bufferSize / 2)
        val utterance = ArrayList<Float>(sampleRate * 6)
        var silenceMs = 0L
        var lastSpeech = System.currentTimeMillis()
        try {
            ar.startRecording()
            while (recording) {
                val n = ar.read(buffer, 0, buffer.size)
                if (n <= 0) continue
                var energy = 0.0
                for (i in 0 until n) {
                    val x = buffer[i] / 32768.0
                    energy += x * x
                    utterance.add(buffer[i] / 32768f)
                }
                val rms = sqrt(energy / n)
                val speech = rms > 0.012
                if (speech) {
                    lastSpeech = System.currentTimeMillis()
                    silenceMs = 0
                } else {
                    silenceMs = System.currentTimeMillis() - lastSpeech
                }

                val tooLong = utterance.size >= sampleRate * 7
                if (utterance.size >= sampleRate / 2 && (silenceMs >= 700 || tooLong)) {
                    val chunk = utterance.toFloatArray()
                    utterance.clear()
                    processUtterance(chunk)
                }
            }
            if (utterance.size >= sampleRate / 2) processUtterance(utterance.toFloatArray())
        } catch (e: Exception) {
            main.post { status.text = "Ошибка микрофона: ${e.message ?: "неизвестная"}" }
        } finally {
            try { ar.stop() } catch (_: Exception) {}
            ar.release()
            recorder = null
        }
    }

    private fun processUtterance(audio: FloatArray) {
        val profile = userVoice ?: return
        val speaker = runCatching {
            val emb = SoniqoBridge.embed(this, audio)
            val score = cosine(profile, emb)
            if (score >= 0.62f) Speaker.ME else Speaker.CUSTOMER
        }.getOrElse { Speaker.CUSTOMER }

        val text = runCatching { SoniqoBridge.transcribe(this, audio) }.getOrNull().orEmpty()
        if (text.isBlank()) return
        main.post {
            turns.add(ConversationTurn(speaker, text))
            renderTurns()
            status.text = "Распознано: ${if (speaker == Speaker.ME) "Я" else "Собеседник"}"
        }
    }

    private fun renderTurns() {
        transcriptContainer.removeAllViews()

        turns.forEach { turn ->
            val box = LinearLayout(this@ConversationActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(10, 10, 10, 10)
            }

            val speakerButton = Button(this@ConversationActivity).apply {
                text = if (turn.speaker == Speaker.ME) "Я" else "Собеседник"
                setOnClickListener {
                    turn.speaker = if (turn.speaker == Speaker.ME) Speaker.CUSTOMER else Speaker.ME
                    renderTurns()
                }
            }

            val messageView = TextView(this@ConversationActivity).apply {
                text = turn.text
                textSize = 16f
                setPadding(4, 4, 4, 4)
            }

            box.addView(speakerButton)
            box.addView(messageView)
            transcriptContainer.addView(box)
        }

        if (turns.isEmpty()) {
            val emptyView = TextView(this@ConversationActivity).apply {
                text = "Здесь появится расшифровка…"
                setPadding(8, 18, 8, 18)
            }
            transcriptContainer.addView(emptyView)
        }
    }

    private fun makeOrderFromCustomerSpeech() {
        val text = turns.filter { it.speaker == Speaker.CUSTOMER }.joinToString(" ") { it.text }
        if (text.isBlank()) {
            Toast.makeText(this, "Нет реплик собеседника для заявки.", Toast.LENGTH_SHORT).show()
            return
        }
        val parsed = OrderParser.parse(text)
        if (parsed.isEmpty()) {
            AlertDialog.Builder(this).setTitle("Расшифровка клиента").setMessage(text).setPositiveButton("ОК", null).show()
            return
        }
        val summary = parsed.joinToString("\n") { "${it.model} — ${it.detail} — ${it.color.ifBlank { "—" }} × ${it.quantity}" }
        AlertDialog.Builder(this)
            .setTitle("Получились позиции")
            .setMessage(summary)
            .setPositiveButton("Добавить в заявку") { _, _ ->
                // Persist through a tiny shared store compatible with the existing MainActivity.
                getSharedPreferences("orders", MODE_PRIVATE).edit().putString("pendingVoiceOrder", text).apply()
                Toast.makeText(this, "Заявка сформирована. Вернитесь в основное окно и добавьте позиции из диктовки/редактора.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun updateStatus() {
        status.text = if (userVoice == null) "Сначала запишите образец своего голоса." else "Профиль голоса готов. Можно начинать разговор."
    }

    private fun captureForMillis(ms: Long): FloatArray {
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufferSize = maxOf(minBuffer, 4096)
        val ar = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        val buffer = ShortArray(bufferSize / 2)
        val out = ArrayList<Float>(sampleRate * (ms / 1000L).toInt() + sampleRate)
        val end = System.currentTimeMillis() + ms
        ar.startRecording()
        try {
            while (System.currentTimeMillis() < end) {
                val n = ar.read(buffer, 0, buffer.size)
                if (n <= 0) continue
                for (i in 0 until n) out.add(buffer[i] / 32768f)
            }
        } finally {
            try { ar.stop() } catch (_: Exception) {}
            ar.release()
        }
        return out.toFloatArray()
    }

    private fun saveProfile() {
        val p = userVoice ?: return
        val s = p.joinToString(",")
        getSharedPreferences("speaker", MODE_PRIVATE).edit().putString("voice_embedding", s).apply()
    }

    private fun loadProfile() {
        val s = getSharedPreferences("speaker", MODE_PRIVATE).getString("voice_embedding", null) ?: return
        userVoice = s.split(',').mapNotNull { it.toFloatOrNull() }.toFloatArray().takeIf { it.isNotEmpty() }
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        val n = minOf(a.size, b.size)
        var dot = 0f; var aa = 0f; var bb = 0f
        for (i in 0 until n) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i] }
        return if (aa == 0f || bb == 0f) 0f else dot / (sqrt(aa.toDouble() * bb.toDouble()).toFloat())
    }
}

data class ConversationTurn(var speaker: Speaker, val text: String)
enum class Speaker { ME, CUSTOMER }

object SoniqoBridge {
    private var transcriber: Any? = null
    private var embedder: Any? = null

    fun transcribe(context: android.content.Context, audio: FloatArray): String {
        val t = transcriber ?: createTranscriber(context).also { transcriber = it }
        callNoArg(t, "beginStream")
        val r = callOneArg(t, "pushAudio", audio)
        val end = callNoArg(t, "endStream")
        return extractText(end ?: r)
    }

    fun embed(context: android.content.Context, audio: FloatArray): FloatArray {
        val e = embedder ?: createEmbedder(context).also { embedder = it }
        val r = callOneArg(e, "embed", audio) ?: error("SpeakerEmbedder.embed вернул null")
        if (r is FloatArray) return r
        if (r is DoubleArray) return r.map { it.toFloat() }.toFloatArray()
        val arr = java.lang.reflect.Array.get(r, 0)
        if (arr is FloatArray) return arr
        error("Не удалось прочитать embedding")
    }

    private fun createTranscriber(context: android.content.Context): Any {
        val modelDir = ensureModel(context, listOf("ensureTranscriberModels", "ensureModels"))
        val cfg = constructConfig("audio.soniqo.speech.TranscriberConfig", modelDir)
        return constructBest("audio.soniqo.speech.StreamingTranscriber", cfg)
    }

    private fun createEmbedder(context: android.content.Context): Any {
        val modelDir = ensureModel(context, listOf("ensureSpeakerEmbeddingModels", "ensureModels"))
        val cfg = constructConfig("audio.soniqo.speech.SpeakerEmbeddingConfig", modelDir,
            "audio.soniqo.speech.SpeakerEmbedderConfig")
        return constructBest("audio.soniqo.speech.SpeakerEmbedder", cfg)
    }

    private fun ensureModel(context: android.content.Context, names: List<String>): Any? {
        val cls = Class.forName("audio.soniqo.speech.ModelManager")
        for (name in names) {
            val methods = cls.methods.filter { it.name == name }
            for (m in methods) {
                val args = when (m.parameterTypes.size) {
                    1 -> arrayOf(context)
                    else -> null
                } ?: continue
                try {
                    return if (Modifier.isStatic(m.modifiers)) m.invoke(null, *args) else m.invoke(null, *args)
                } catch (_: Throwable) { }
            }
        }
        return null
    }

    private fun constructConfig(primary: String, modelDir: Any?, secondary: String? = null): Any {
        val names = listOfNotNull(primary, secondary)
        for (name in names) {
            try {
                val cls = Class.forName(name)
                cls.constructors.firstOrNull()?.let { c ->
                    val params = c.parameterTypes
                    if (params.isEmpty()) return c.newInstance()
                    if (params.size == 1 && modelDir != null && params[0].isAssignableFrom(modelDir.javaClass)) return c.newInstance(modelDir)
                }
            } catch (_: Throwable) { }
        }
        error("Не найден config-класс Soniqo")
    }

    private fun constructBest(name: String, config: Any): Any {
        val cls = Class.forName(name)
        for (c in cls.constructors) {
            if (c.parameterTypes.size == 1 && c.parameterTypes[0].isAssignableFrom(config.javaClass)) return c.newInstance(config)
        }
        error("Не найден конструктор $name")
    }

    private fun callNoArg(obj: Any?, name: String): Any? {
        if (obj == null) return null
        val m = obj.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.isEmpty() } ?: return null
        return m.invoke(obj)
    }

    private fun callOneArg(obj: Any?, name: String, arg: Any): Any? {
        if (obj == null) return null
        val m = obj.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == 1 } ?: return null
        return m.invoke(obj, arg)
    }

    private fun extractText(obj: Any?): String {
        if (obj == null) return ""
        if (obj is String) return obj
        try {
            val f = obj.javaClass.methods.firstOrNull { it.name.equals("getText", true) && it.parameterTypes.isEmpty() }
            if (f != null) return f.invoke(obj)?.toString().orEmpty()
        } catch (_: Throwable) {}
        return obj.toString()
    }
}
